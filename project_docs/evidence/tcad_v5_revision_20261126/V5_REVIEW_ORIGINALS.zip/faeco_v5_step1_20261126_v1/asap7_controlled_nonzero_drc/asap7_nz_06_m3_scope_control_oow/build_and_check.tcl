read_db "/home/toylog/faeco_tcad_asap7_aes_20261125_v1/asap7/aes/repaired_control_v4/6_final.odb"
set blk [ord::get_db_block]
set tech [[ord::get_db] getTech]
set dbu [$blk getDbUnitsPerMicron]
set rows [$blk getRows]
set rbb [[lindex $rows 0] getBBox]
set row_h [expr {[$rbb yMax] - [$rbb yMin]}]
set inst [$blk findInst u1037]
if { $inst eq "NULL" } { error "inst not found: u1037" }
set obb [$inst getBBox]
set ox1 [$obb xMin]; set oy1 [$obb yMin]
set newm [[ord::get_db] findMaster AOI211xp5_ASAP7_75t_R]
$inst swapMaster $newm
$inst setLocation $ox1 $oy1
set bb [$inst getBBox]
set ix1 [$bb xMin]; set iy1 [$bb yMin]; set ix2 [$bb xMax]; set iy2 [$bb yMax]

set direct_nets {}
foreach it [$inst getITerms] {
  set n [$it getNet]
  if { $n eq "NULL" } { continue }
  if { [$n getSigType] ne "SIGNAL" } { continue }
  lappend direct_nets [$n getName]
}
set direct_nets [lsort -unique $direct_nets]
if { [llength $direct_nets] == 0 } { error "no direct signal net on u1037" }
foreach nm $direct_nets {
  set n [$blk findNet $nm]
  set w [$n getWire]
  if { $w ne "NULL" } { odb::dbWire_destroy $w }
}

# anchor = placed-instance bbox centre (block coordinates, deterministic)
set ax [expr {($ix1 + $ix2) / 2}]
set ay [expr {($iy1 + $iy2) / 2}]

set layer [$tech findLayer M3]
set min_w [$layer getWidth]
set gap [expr {int(round(93 * $dbu / 1000.0))}]
set L [expr {$min_w * 6}]
if { 1 } {
  set cy [expr {$iy2 + int(1.05 * $row_h)}]
} else {
  set cy $ay
}

set dn [$blk findNet [lindex $direct_nets 0]]
if { [$dn getWire] eq "NULL" } { odb::dbWire_create $dn }
set wd [$dn getWire]
set enc [odb::dbWireEncoder]
$enc begin $wd
$enc newPath $layer ROUTED
$enc addPoint [expr {$ax - $L}] $cy
$enc addPoint [expr {$ax + $L}] $cy
$enc end

set nz [odb::dbNet_create $blk "FAECO_NZ_asap7_nz_06_m3_scope_control_oow"]
$nz setSigType SIGNAL
set wnz [odb::dbWire_create $nz]
set enc2 [odb::dbWireEncoder]
$enc2 begin $wnz
$enc2 newPath $layer ROUTED
if { "short" eq "short" } {
  $enc2 addPoint $ax [expr {$cy - $L}]
  $enc2 addPoint $ax [expr {$cy + $L}]
} else {
  set sy [expr {$cy + $min_w + $gap}]
  $enc2 addPoint [expr {$ax - $L}] $sy
  $enc2 addPoint [expr {$ax + $L}] $sy
}
$enc2 end

write_db "/home/toylog/faeco_v5_step1_20261126_v1/asap7_controlled_nonzero_drc/asap7_nz_06_m3_scope_control_oow/perturbed.odb"
set f [open "/home/toylog/faeco_v5_step1_20261126_v1/asap7_controlled_nonzero_drc/asap7_nz_06_m3_scope_control_oow/meta.txt" w]
puts $f "dbu=$dbu row_h=$row_h inst=u1037 nz=FAECO_NZ_asap7_nz_06_m3_scope_control_oow mode=short layer=M3 gap_dbu=$gap min_w=$min_w direct=[join $direct_nets ,] bbox=$ix1,$iy1,$ix2,$iy2 conflict_y=$cy"
close $f
puts PERTURBED_OK
exit

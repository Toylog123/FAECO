read_liberty "/home/toylog/faeco_tcad_asap7_aes_20261125_v1/asap7/aes/matrix_rank_aligned_v1/seed/libraries/TT/asap7sc7p5t_AO_RVT_TT_nldm_211120.lib"
read_liberty "/home/toylog/faeco_tcad_asap7_aes_20261125_v1/asap7/aes/matrix_rank_aligned_v1/seed/libraries/TT/asap7sc7p5t_INVBUF_RVT_TT_nldm_220122.lib"
read_liberty "/home/toylog/faeco_tcad_asap7_aes_20261125_v1/asap7/aes/matrix_rank_aligned_v1/seed/libraries/TT/asap7sc7p5t_OA_RVT_TT_nldm_211120.lib"
read_liberty "/home/toylog/faeco_tcad_asap7_aes_20261125_v1/asap7/aes/matrix_rank_aligned_v1/seed/libraries/TT/asap7sc7p5t_SIMPLE_RVT_TT_nldm_211120.lib"
read_liberty "/home/toylog/faeco_eda/orfs/flow/platforms/asap7/lib/NLDM/asap7sc7p5t_SEQ_RVT_TT_nldm_220123.lib"
read_db "/home/toylog/faeco_tcad_asap7_aes_20261125_v1/asap7/aes/matrix_rank_aligned_v1/cell_03/faeco/02/initial/routed.odb"
read_sdc "/home/toylog/faeco_tcad_asap7_aes_20261125_v1/asap7/aes/repaired_control_v4/6_final.sdc"
read_spef "/home/toylog/faeco_tcad_asap7_aes_20261125_v1/asap7/aes/matrix_rank_aligned_v1/cell_03/faeco/02/initial/routed.spef"
report_power -digits 9 -format json > "/home/toylog/faeco_tcad_asap7_aes_20261125_v1/asap7/aes/native_recover_power_v1/power/faeco_best_power.json"
puts POWER_DONE
exit

read_liberty "/home/toylog/faeco_tcad_uart_online_20261125_matrix_v2/seed/libraries/TT/asap7sc7p5t_AO_RVT_TT_nldm_211120.lib"
read_liberty "/home/toylog/faeco_tcad_uart_online_20261125_matrix_v2/seed/libraries/TT/asap7sc7p5t_INVBUF_RVT_TT_nldm_220122.lib"
read_liberty "/home/toylog/faeco_tcad_uart_online_20261125_matrix_v2/seed/libraries/TT/asap7sc7p5t_OA_RVT_TT_nldm_211120.lib"
read_liberty "/home/toylog/faeco_tcad_uart_online_20261125_matrix_v2/seed/libraries/TT/asap7sc7p5t_SIMPLE_RVT_TT_nldm_211120.lib"
read_liberty "/home/toylog/faeco_eda/orfs/flow/platforms/asap7/lib/NLDM/asap7sc7p5t_SEQ_RVT_TT_nldm_220123.lib"
read_db "/home/toylog/faeco_tcad_holdout_qualification_20261124_v1/asap7/uart/results/asap7/uart/base/6_final.odb"
read_sdc "/home/toylog/faeco_tcad_holdout_qualification_20261124_v1/asap7/uart/results/asap7/uart/base/6_final.sdc"
read_spef "/home/toylog/faeco_tcad_holdout_qualification_20261124_v1/asap7/uart/results/asap7/uart/base/6_final.spef"
report_power -digits 9 -format json > "/home/toylog/faeco_tcad_native_recover_power_20261125_v1/asap7_uart/power/control_power.json"
report_power -digits 6
puts POWER_AUDIT_DONE
exit

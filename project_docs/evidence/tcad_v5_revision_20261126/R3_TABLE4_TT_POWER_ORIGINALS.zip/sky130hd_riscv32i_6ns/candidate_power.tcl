read_liberty "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib"
read_db "/home/toylog/faeco_tcad_anytime_holdouts_20261125_v1/sky130hd/riscv32i/matrix_rank_aligned_v1/cell_03/faeco/03/retry/routed.odb"
read_sdc "/home/toylog/faeco_tcad_anytime_holdouts_20261125_v1/sky130hd/riscv32i/results/sky130hd/riscv32i/base/6_final.sdc"
read_spef "/home/toylog/faeco_tcad_anytime_holdouts_20261125_v1/sky130hd/riscv32i/matrix_rank_aligned_v1/cell_03/faeco/03/retry/routed.spef"
report_power -digits 9 -format json > "/home/toylog/faeco_tcad_native_recover_power_20261125_v1/sky130hd_riscv32i/power/faeco_best_power.json"
report_power -digits 6
puts POWER_AUDIT_DONE
exit

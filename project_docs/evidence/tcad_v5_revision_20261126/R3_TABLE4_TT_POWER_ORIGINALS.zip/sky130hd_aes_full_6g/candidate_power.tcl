read_liberty "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib"
read_db "/home/toylog/faeco_tcad_sky_holdout_20261123/aes_factorial_20261124_v1/forward/faeco_online/faeco/04/initial/routed.odb"
read_sdc "/home/toylog/faeco_tcad_sky_holdout_20261123/aes/ss_hold_targeted_v2b/6_final.sdc"
read_spef "/home/toylog/faeco_tcad_sky_holdout_20261123/aes_factorial_20261124_v1/forward/faeco_online/faeco/04/initial/routed.spef"
report_power -digits 9 -format json > "/home/toylog/faeco_tcad_native_recover_power_20261125_v1/sky130hd_aes/power/faeco_best_power.json"
report_power -digits 6
puts POWER_AUDIT_DONE
exit

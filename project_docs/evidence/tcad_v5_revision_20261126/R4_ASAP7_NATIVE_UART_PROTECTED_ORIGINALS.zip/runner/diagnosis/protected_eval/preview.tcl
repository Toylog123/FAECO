read_liberty "/home/toylog/faeco_tcad_uart_online_20261125_matrix_v2/seed/libraries/TT/asap7sc7p5t_AO_RVT_TT_nldm_211120.lib"
read_liberty "/home/toylog/faeco_tcad_uart_online_20261125_matrix_v2/seed/libraries/TT/asap7sc7p5t_INVBUF_RVT_TT_nldm_220122.lib"
read_liberty "/home/toylog/faeco_tcad_uart_online_20261125_matrix_v2/seed/libraries/TT/asap7sc7p5t_OA_RVT_TT_nldm_211120.lib"
read_liberty "/home/toylog/faeco_tcad_uart_online_20261125_matrix_v2/seed/libraries/TT/asap7sc7p5t_SIMPLE_RVT_TT_nldm_211120.lib"
read_liberty "/home/toylog/faeco_eda/orfs/flow/platforms/asap7/lib/NLDM/asap7sc7p5t_SEQ_RVT_TT_nldm_220123.lib"
read_db "/home/toylog/faeco_tcad_holdout_qualification_20261124_v1/asap7/uart/results/asap7/uart/base/6_final.odb"
read_sdc "/home/toylog/faeco_tcad_holdout_qualification_20261124_v1/asap7/uart/results/asap7/uart/base/6_final.sdc"
if {[llength [all_clocks]] == 0} { error "No clocks in saved SDC" }
source "/home/toylog/faeco_eda/orfs/flow/platforms/asap7/setRC.tcl"
set env(MIN_ROUTING_LAYER) M2
set env(MIN_CLK_ROUTING_LAYER) M4
set env(MAX_ROUTING_LAYER) M7
set env(ROUTING_LAYER_ADJUSTMENT) 0.25
source "/home/toylog/faeco_eda/orfs/flow/platforms/asap7/fastroute.tcl"

set inst [[ord::get_db_block] findInst "output43"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "BUFx3_ASAP7_75t_R"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "HB3xp67_ASAP7_75t_R"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "output43"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "HB3xp67_ASAP7_75t_R"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "output42"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "BUFx3_ASAP7_75t_R"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "HB3xp67_ASAP7_75t_R"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "output42"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "HB3xp67_ASAP7_75t_R"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "output41"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "BUFx3_ASAP7_75t_R"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "HB3xp67_ASAP7_75t_R"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "output41"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "HB3xp67_ASAP7_75t_R"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "output40"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "BUFx3_ASAP7_75t_R"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "HB3xp67_ASAP7_75t_R"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "output40"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "HB3xp67_ASAP7_75t_R"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "output39"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "BUFx3_ASAP7_75t_R"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "HB3xp67_ASAP7_75t_R"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "output39"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "HB3xp67_ASAP7_75t_R"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "output38"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "BUFx3_ASAP7_75t_R"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "HB3xp67_ASAP7_75t_R"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "output38"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "HB3xp67_ASAP7_75t_R"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "output37"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "BUFx3_ASAP7_75t_R"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "HB3xp67_ASAP7_75t_R"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "output37"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "HB3xp67_ASAP7_75t_R"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "output36"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "BUFx3_ASAP7_75t_R"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "HB3xp67_ASAP7_75t_R"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "output36"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "HB3xp67_ASAP7_75t_R"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "output35"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "BUFx3_ASAP7_75t_R"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "HB3xp67_ASAP7_75t_R"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "output35"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "HB3xp67_ASAP7_75t_R"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "output34"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "BUFx3_ASAP7_75t_R"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "HB3xp67_ASAP7_75t_R"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "output34"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "HB3xp67_ASAP7_75t_R"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "output33"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "BUFx3_ASAP7_75t_R"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "HB3xp67_ASAP7_75t_R"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "output33"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "HB3xp67_ASAP7_75t_R"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "output32"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "BUFx3_ASAP7_75t_R"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "HB3xp67_ASAP7_75t_R"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "output32"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "HB3xp67_ASAP7_75t_R"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "output31"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "BUFx3_ASAP7_75t_R"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "HB3xp67_ASAP7_75t_R"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "output31"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "HB3xp67_ASAP7_75t_R"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "output30"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "BUFx3_ASAP7_75t_R"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "HB3xp67_ASAP7_75t_R"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "output30"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "HB3xp67_ASAP7_75t_R"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "output29"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "BUFx3_ASAP7_75t_R"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "HB3xp67_ASAP7_75t_R"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "output29"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "HB3xp67_ASAP7_75t_R"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "place261"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "BUFx3_ASAP7_75t_R"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "HB3xp67_ASAP7_75t_R"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "place261"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "HB3xp67_ASAP7_75t_R"} {
    error "target instance/master mismatch"
}

check_placement -verbose

set nets [dict create]
foreach name [list "output43" "output42" "output41" "output40" "output39" "output38" "output37" "output36" "output35" "output34" "output33" "output32" "output31" "output30" "output29" "place261"] {
    set inst [[ord::get_db_block] findInst $name]
    foreach pin [$inst getITerms] {
        set net [$pin getNet]
        if {$net ne "NULL" && [$net getSigType] ni {POWER GROUND}} {
            dict set nets [$net getName] $net
        }
    }
}

set cleared 0
dict for {name net} $nets {
    if {[$net getSigType] in {POWER GROUND}} { continue }
    puts "IBEX_TOUCHED_NET $name"
    set wire [$net getWire]
    if {$wire ne "NULL"} { odb::dbWire_destroy $wire; incr cleared }
}
puts "IBEX_CLEARED_SIGNAL_WIRES $cleared"
set _blk [ord::get_db_block]
set _dbu [$_blk getDbUnitsPerMicron]
set _die [$_blk getDieArea]
set _dx1 [$_die xMin]; set _dy1 [$_die yMin]; set _dx2 [$_die xMax]; set _dy2 [$_die yMax]
set _rows [$_blk getRows]
if { [llength $_rows] == 0 } { error "no placement rows found for row-height halo" }
set _rbb [[lindex $_rows 0] getBBox]
set _row_h [expr {[$_rbb yMax] - [$_rbb yMin]}]
set _halo [expr {int(round($_row_h * 1.0))}]
set _boxes {}
set _seeds 0
foreach _nm [list "output29" "output30" "output31" "output32" "output33" "output34" "output35" "output36" "output37" "output38" "output39" "output40" "output41" "output42" "output43" "place261"] {
  set _inst [$_blk findInst $_nm]
  if { $_inst eq "NULL" } { error "boxed DRC edited instance not found: $_nm" }
  incr _seeds
  set _bb [$_inst getBBox]
  set _x1 [expr {max($_dx1, [$_bb xMin] - $_halo)}]
  set _y1 [expr {max($_dy1, [$_bb yMin] - $_halo)}]
  set _x2 [expr {min($_dx2, [$_bb xMax] + $_halo)}]
  set _y2 [expr {min($_dy2, [$_bb yMax] + $_halo)}]
  lappend _boxes [list $_x1 $_y1 $_x2 $_y2]
}
set _changed 1
while { $_changed } {
  set _changed 0
  set _n [llength $_boxes]
  set _used [lrepeat $_n 0]
  set _next {}
  for {set _a 0} {$_a < $_n} {incr _a} {
    if { [lindex $_used $_a] } { continue }
    lset _used $_a 1
    lassign [lindex $_boxes $_a] _ax1 _ay1 _ax2 _ay2
    for {set _b [expr {$_a + 1}]} {$_b < $_n} {incr _b} {
      if { [lindex $_used $_b] } { continue }
      lassign [lindex $_boxes $_b] _bx1 _by1 _bx2 _by2
      if { !($_ax2 < $_bx1 || $_bx2 < $_ax1 || $_ay2 < $_by1 || $_by2 < $_ay1) } {
        if { $_bx1 < $_ax1 } { set _ax1 $_bx1 }
        if { $_by1 < $_ay1 } { set _ay1 $_by1 }
        if { $_bx2 > $_ax2 } { set _ax2 $_bx2 }
        if { $_by2 > $_ay2 } { set _ay2 $_by2 }
        lset _used $_b 1
        set _changed 1
      }
    }
    lappend _next [list $_ax1 $_ay1 $_ax2 $_ay2]
  }
  set _boxes $_next
}
puts "FAECO_BOXED_DRC_META dbu=$_dbu row_h=$_row_h halo=$_halo seeds=$_seeds boxes=[llength $_boxes]"
set _idx 0
foreach _b $_boxes {
  lassign $_b _x1 _y1 _x2 _y2
  set _rpt "/var/tmp/faeco_r4_native_uart_protected_20261127_v1/runner/diagnosis/protected_eval/box_${_idx}.rpt"
  drt::check_drc -box [list $_x1 $_y1 $_x2 $_y2] -output_file $_rpt
  incr _idx
}
puts FAECO_PRE_DRT_DRC_COMPLETE
exit

read_db "/var/tmp/faeco_r4_native_uart_protected_20261127_v1/runner/preflight/zero/initial/routed.odb"
read_def -floorplan_initialize "/var/tmp/faeco_r4_native_uart_protected_20261127_v1/runner/preflight/zero/initial/unlocked_drc/normalized_nets.def"
write_def "/var/tmp/faeco_r4_native_uart_protected_20261127_v1/runner/preflight/zero/initial/unlocked_drc/normalized_geometry.def"
if {![design_is_routed]} { error "Unrouted signal nets" }
drt::check_drc -output_file "/var/tmp/faeco_r4_native_uart_protected_20261127_v1/runner/preflight/zero/initial/unlocked_drc/full_drc.rpt"
puts AES_UNLOCKED_DRC_COMPLETE
exit

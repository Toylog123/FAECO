read_db "/var/tmp/faeco_v6_stage5_online_20261127_v1/arms/fixed_boxed/attempt_01/fixed/06/initial/routed.odb"
read_def -floorplan_initialize "/var/tmp/faeco_v6_stage5_online_20261127_v1/arms/fixed_boxed/attempt_01/fixed/06/initial/unlocked_drc/normalized_nets.def"
write_def "/var/tmp/faeco_v6_stage5_online_20261127_v1/arms/fixed_boxed/attempt_01/fixed/06/initial/unlocked_drc/normalized_geometry.def"
if {![design_is_routed]} { error "Unrouted signal nets" }
drt::check_drc -output_file "/var/tmp/faeco_v6_stage5_online_20261127_v1/arms/fixed_boxed/attempt_01/fixed/06/initial/unlocked_drc/full_drc.rpt"
puts AES_UNLOCKED_DRC_COMPLETE
exit

read_liberty "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib"
read_db "/home/toylog/faeco_v5_step5_riscv32i_tc40ns_mmmc_drv_20261127_v1/arms/fixed_boxed/attempt_01/fixed/06/initial/routed.odb"
read_sdc "/home/toylog/faeco_v5_step5_riscv32i_tc40ns_mmmc_drv_20261127_v1/orfs/results/sky130hd/riscv32i/tc40ns_mmmc_drv/6_final.sdc"
read_spef "/home/toylog/faeco_v5_step5_riscv32i_tc40ns_mmmc_drv_20261127_v1/arms/fixed_boxed/attempt_01/fixed/06/initial/routed.spef"
report_power -digits 9 -format json > "/home/toylog/faeco_v5_step5_riscv32i_tc40ns_mmmc_drv_20261127_v1/arms/fixed_boxed/attempt_01/best_pwr_power.json"
puts PWR_OK
exit

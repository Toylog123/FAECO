read_liberty "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib"
read_db "/home/toylog/faeco_v5_step5_riscv32i_tc40ns_mmmc_drv_20261127_v1/orfs/results/sky130hd/riscv32i/tc40ns_mmmc_drv/6_final.odb"
read_sdc "/home/toylog/faeco_v5_step5_riscv32i_tc40ns_mmmc_drv_20261127_v1/orfs/results/sky130hd/riscv32i/tc40ns_mmmc_drv/6_final.sdc"
if {[llength [all_clocks]] == 0} { error "No clocks in saved SDC" }
source "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/setRC.tcl"
set env(MIN_ROUTING_LAYER) met1
set env(MIN_CLK_ROUTING_LAYER) met3
set env(MAX_ROUTING_LAYER) met5
set env(ROUTING_LAYER_ADJUSTMENT) 0.25
source "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/fastroute.tcl"

set inst [[ord::get_db_block] findInst "_3836_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__nor4b_2"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "sky130_fd_sc_hd__nor4b_1"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "_3836_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__nor4b_1"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "_3900_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__a211oi_4"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "sky130_fd_sc_hd__a211oi_2"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "_3900_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__a211oi_2"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "_3964_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__a211oi_4"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "sky130_fd_sc_hd__a211oi_2"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "_3964_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__a211oi_2"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "_4024_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__nor4_4"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "sky130_fd_sc_hd__nor4_2"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "_4024_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__nor4_2"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "_4162_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__nor4_4"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "sky130_fd_sc_hd__nor4_2"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "_4162_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__nor4_2"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "_4696_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__o41ai_2"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "sky130_fd_sc_hd__o41ai_1"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "_4696_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__o41ai_1"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "_4713_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__o2bb2a_4"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "sky130_fd_sc_hd__o2bb2a_2"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "_4713_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__o2bb2a_2"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "_4718_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__o311ai_2"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "sky130_fd_sc_hd__o311ai_0"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "_4718_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__o311ai_0"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "_7128_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__nor4_4"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "sky130_fd_sc_hd__nor4_2"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "_7128_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__nor4_2"} {
    error "target instance/master mismatch"
}

check_placement -verbose

set nets [dict create]
foreach name [list "_3836_" "_3900_" "_3964_" "_4024_" "_4162_" "_4696_" "_4713_" "_4718_" "_7128_"] {
    set inst [[ord::get_db_block] findInst $name]
    foreach pin [$inst getITerms] {
        set net [$pin getNet]
        if {$net ne "NULL" && [$net getSigType] ni {POWER GROUND}} {
            dict set nets [$net getName] $net
        }
    }
}

set cleared 0
dict for {name net} $nets {
    if {[$net getSigType] in {POWER GROUND}} { continue }
    puts "IBEX_TOUCHED_NET $name"
    set wire [$net getWire]
    if {$wire ne "NULL"} { odb::dbWire_destroy $wire; incr cleared }
}
puts "IBEX_CLEARED_SIGNAL_WIRES $cleared"
set _blk [ord::get_db_block]
set _dbu [$_blk getDbUnitsPerMicron]
set _die [$_blk getDieArea]
set _dx1 [$_die xMin]; set _dy1 [$_die yMin]; set _dx2 [$_die xMax]; set _dy2 [$_die yMax]
set _rows [$_blk getRows]
if { [llength $_rows] == 0 } { error "no placement rows found for row-height halo" }
set _rbb [[lindex $_rows 0] getBBox]
set _row_h [expr {[$_rbb yMax] - [$_rbb yMin]}]
set _halo [expr {int(round($_row_h * 1.0))}]
set _boxes {}
set _seeds 0
foreach _nm [list "_3836_" "_3900_" "_3964_" "_4024_" "_4162_" "_4696_" "_4713_" "_4718_" "_7128_"] {
  set _inst [$_blk findInst $_nm]
  if { $_inst eq "NULL" } { error "boxed DRC edited instance not found: $_nm" }
  incr _seeds
  set _bb [$_inst getBBox]
  set _x1 [expr {max($_dx1, [$_bb xMin] - $_halo)}]
  set _y1 [expr {max($_dy1, [$_bb yMin] - $_halo)}]
  set _x2 [expr {min($_dx2, [$_bb xMax] + $_halo)}]
  set _y2 [expr {min($_dy2, [$_bb yMax] + $_halo)}]
  lappend _boxes [list $_x1 $_y1 $_x2 $_y2]
}
set _changed 1
while { $_changed } {
  set _changed 0
  set _n [llength $_boxes]
  set _used [lrepeat $_n 0]
  set _next {}
  for {set _a 0} {$_a < $_n} {incr _a} {
    if { [lindex $_used $_a] } { continue }
    lset _used $_a 1
    lassign [lindex $_boxes $_a] _ax1 _ay1 _ax2 _ay2
    for {set _b [expr {$_a + 1}]} {$_b < $_n} {incr _b} {
      if { [lindex $_used $_b] } { continue }
      lassign [lindex $_boxes $_b] _bx1 _by1 _bx2 _by2
      if { !($_ax2 < $_bx1 || $_bx2 < $_ax1 || $_ay2 < $_by1 || $_by2 < $_ay1) } {
        if { $_bx1 < $_ax1 } { set _ax1 $_bx1 }
        if { $_by1 < $_ay1 } { set _ay1 $_by1 }
        if { $_bx2 > $_ax2 } { set _ax2 $_bx2 }
        if { $_by2 > $_ay2 } { set _ay2 $_by2 }
        lset _used $_b 1
        set _changed 1
      }
    }
    lappend _next [list $_ax1 $_ay1 $_ax2 $_ay2]
  }
  set _boxes $_next
}
puts "FAECO_BOXED_DRC_META dbu=$_dbu row_h=$_row_h halo=$_halo seeds=$_seeds boxes=[llength $_boxes]"
set _idx 0
foreach _b $_boxes {
  lassign $_b _x1 _y1 _x2 _y2
  set _rpt "/home/toylog/faeco_v5_step5_riscv32i_tc40ns_mmmc_drv_20261127_v1/arms/fixed_boxed/attempt_01/fixed/diagnosis/04/box_${_idx}.rpt"
  drt::check_drc -box [list $_x1 $_y1 $_x2 $_y2] -output_file $_rpt
  incr _idx
}
puts FAECO_PRE_DRT_DRC_COMPLETE
exit

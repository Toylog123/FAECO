read_liberty "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib"
read_db "/var/tmp/faeco_v6_stage5_rebuilt_20261127_v2/orfs/results/sky130hd/riscv32i/tc40ns_mmmc_drv/6_final.odb"
read_def -floorplan_initialize "/var/tmp/faeco_v6_stage5_online_sec_fixed_20261127_v1/arms/single_boxed/attempt_01/single/06/initial/fixed_wires.def"
write_def "/var/tmp/faeco_v6_stage5_online_sec_fixed_20261127_v1/arms/single_boxed/attempt_01/single/06/initial/pre_drt.def"
set fp [open "/var/tmp/faeco_v6_stage5_online_sec_fixed_20261127_v1/arms/single_boxed/attempt_01/single/06/initial/pre_drt.def" r]
set snapshot [read $fp]
close $fp
set first [string first "\nNETS " $snapshot]
set last [string first "\nEND NETS" $snapshot]
set observed [regexp -all {[+] FIXED } [string range $snapshot $first $last]]
if {$first < 0 || $last < $first || $observed != 5469} {
    error "Expected 5469 encoded fixed nets, read back $observed"
}
puts "AES_SELECTIVE_FIXED_READBACK $observed"
unset snapshot
read_sdc "/var/tmp/faeco_v6_stage5_rebuilt_20261127_v2/orfs/results/sky130hd/riscv32i/tc40ns_mmmc_drv/6_final.sdc"
if {[llength [all_clocks]] == 0} { error "No clocks in saved SDC" }
source "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/setRC.tcl"
set env(MIN_ROUTING_LAYER) met1
set env(MIN_CLK_ROUTING_LAYER) met3
set env(MAX_ROUTING_LAYER) met5
set env(ROUTING_LAYER_ADJUSTMENT) 0.25
source "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/fastroute.tcl"

set inst [[ord::get_db_block] findInst "_4134_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__nor4_4"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "sky130_fd_sc_hd__nor4_2"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "_4134_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__nor4_2"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "_4598_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__o311ai_2"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "sky130_fd_sc_hd__o311ai_0"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "_4598_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__o311ai_0"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "_4696_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__o41ai_2"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "sky130_fd_sc_hd__o41ai_1"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "_4696_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__o41ai_1"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "_4713_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__o2bb2a_4"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "sky130_fd_sc_hd__o2bb2a_2"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "_4713_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__o2bb2a_2"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "_4718_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__o311ai_2"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "sky130_fd_sc_hd__o311ai_0"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "_4718_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__o311ai_0"} {
    error "target instance/master mismatch"
}

check_placement -verbose

set nets [dict create]
foreach name [list "_4134_" "_4598_" "_4696_" "_4713_" "_4718_"] {
    set inst [[ord::get_db_block] findInst $name]
    foreach pin [$inst getITerms] {
        set net [$pin getNet]
        if {$net ne "NULL" && [$net getSigType] ni {POWER GROUND}} {
            dict set nets [$net getName] $net
        }
    }
}

set cleared 0
dict for {name net} $nets {
    if {[$net getSigType] in {POWER GROUND}} { continue }
    puts "IBEX_TOUCHED_NET $name"
    set wire [$net getWire]
    if {$wire ne "NULL"} { odb::dbWire_destroy $wire; incr cleared }
}
puts "IBEX_CLEARED_SIGNAL_WIRES $cleared"
if {![grt::have_routes]} {error "No embedded route guides"}
detailed_route -output_drc "/var/tmp/faeco_v6_stage5_online_sec_fixed_20261127_v1/arms/single_boxed/attempt_01/single/06/initial/drc.rpt" -verbose 1 -droute_end_iter 64
puts "IBEX_DRT_VIOLATIONS [detailed_route_num_drvs]"
if {![design_is_routed]} { error "Unrouted nets after DRT" }
check_placement -verbose
puts IBEX_DRT_COMPLETE
set antenna [check_antennas -report_file "/var/tmp/faeco_v6_stage5_online_sec_fixed_20261127_v1/arms/single_boxed/attempt_01/single/06/initial/antenna.rpt"]
puts "AES_SELECTIVE_ANTENNA $antenna"
drt::check_drc -output_file "/var/tmp/faeco_v6_stage5_online_sec_fixed_20261127_v1/arms/single_boxed/attempt_01/single/06/initial/full_drc.rpt"
puts AES_SELECTIVE_FULL_DRC_COMPLETE
set ::env(REPORTS_DIR) "/var/tmp/faeco_v6_stage5_online_sec_fixed_20261127_v1/arms/single_boxed/attempt_01/single/06/initial"
source "/home/toylog/faeco_eda/orfs/flow/scripts/util.tcl"
write_verilog "/var/tmp/faeco_v6_stage5_online_sec_fixed_20261127_v1/arms/single_boxed/attempt_01/single/06/initial/routed.v" -remove_cells [find_physical_only_masters]
write_def "/var/tmp/faeco_v6_stage5_online_sec_fixed_20261127_v1/arms/single_boxed/attempt_01/single/06/initial/routed.def"
write_db "/var/tmp/faeco_v6_stage5_online_sec_fixed_20261127_v1/arms/single_boxed/attempt_01/single/06/initial/routed.odb"
define_process_corner -ext_model_index 0 X
extract_parasitics -ext_model_file "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/rcx_patterns.rules"
write_spef "/var/tmp/faeco_v6_stage5_online_sec_fixed_20261127_v1/arms/single_boxed/attempt_01/single/06/initial/routed.spef"
puts IBEX_RCX_COMPLETE
puts IBEX_ROUTE_COMPLETE
exit

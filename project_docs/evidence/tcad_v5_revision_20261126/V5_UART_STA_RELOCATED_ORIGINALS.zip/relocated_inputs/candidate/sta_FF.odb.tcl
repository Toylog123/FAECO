read_liberty "/home/toylog/faeco_v5_review_uart_relocated_inputs_20261127_v1/faeco_tcad_uart_online_20261125_matrix_v2/seed/libraries/FF/asap7sc7p5t_AO_RVT_FF_nldm_211120.lib"
read_liberty "/home/toylog/faeco_v5_review_uart_relocated_inputs_20261127_v1/faeco_tcad_uart_online_20261125_matrix_v2/seed/libraries/FF/asap7sc7p5t_INVBUF_RVT_FF_nldm_220122.lib"
read_liberty "/home/toylog/faeco_v5_review_uart_relocated_inputs_20261127_v1/faeco_tcad_uart_online_20261125_matrix_v2/seed/libraries/FF/asap7sc7p5t_OA_RVT_FF_nldm_211120.lib"
read_liberty "/home/toylog/faeco_v5_review_uart_relocated_inputs_20261127_v1/faeco_tcad_uart_online_20261125_matrix_v2/seed/libraries/FF/asap7sc7p5t_SIMPLE_RVT_FF_nldm_250407.lib"
read_liberty "/home/toylog/faeco_v5_review_uart_relocated_inputs_20261127_v1/faeco_eda/orfs/flow/platforms/asap7/lib/NLDM/asap7sc7p5t_SEQ_RVT_FF_nldm_220123.lib"
read_db "/home/toylog/faeco_v5_review_uart_relocated_inputs_20261127_v1/faeco_v4_tc_drc_sens_20261126_v1/timing_closed_asap7_uart/runner/faeco_boxed/15/initial/routed.odb"
read_sdc "/home/toylog/faeco_v5_review_uart_relocated_results_20261127_v1/uart_470p5ps.sdc"
if {[llength [all_clocks]] == 0} { error "No clocks in saved SDC" }
read_spef "/home/toylog/faeco_v5_review_uart_relocated_inputs_20261127_v1/faeco_v4_tc_drc_sens_20261126_v1/timing_closed_asap7_uart/runner/faeco_boxed/15/initial/routed.spef"
puts "IBEX_SETUP_PS [expr {1e12 * [sta::worst_slack_cmd max]}]"
puts "IBEX_HOLD_PS [expr {1e12 * [sta::worst_slack_cmd min]}]"
puts "IBEX_TNS_PS [expr {1e12 * [sta::total_negative_slack_cmd max]}]"
puts "IBEX_HOLD_TNS_PS [expr {1e12 * [sta::total_negative_slack_cmd min]}]"
puts IBEX_MAX_SLEW_START
report_check_types -max_slew -violators -digits 9
puts IBEX_MAX_SLEW_END
puts IBEX_MAX_CAPACITANCE_START
report_check_types -max_capacitance -violators -digits 9
puts IBEX_MAX_CAPACITANCE_END
foreach port [all_inputs -no_clocks] { puts "IBEX_INPUT [get_name $port]" }
foreach port [all_outputs] { puts "IBEX_OUTPUT [get_name $port]" }
check_setup -verbose
report_parasitic_annotation
report_checks -path_delay max -group_path_count 1
report_checks -path_delay min -group_path_count 1

puts IBEX_SETUP_NEG_BEGIN
set paths [find_timing_paths -path_delay max -slack_max 0 -group_path_count 100000 -endpoint_path_count 1]
if {[llength $paths] >= 100000} { error "setup endpoint inventory hit the path report cap" }
foreach path $paths {
    if {[get_property $path slack] < 0} {
        puts "IBEX_SETUP_NEG [get_full_name [get_property $path endpoint]]"
    }
}
puts IBEX_SETUP_NEG_END

puts IBEX_STA_COMPLETE
exit

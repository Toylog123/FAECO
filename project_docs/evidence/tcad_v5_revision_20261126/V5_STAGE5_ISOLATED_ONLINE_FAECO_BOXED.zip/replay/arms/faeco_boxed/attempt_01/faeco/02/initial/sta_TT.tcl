read_liberty "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib"
read_verilog "/var/tmp/faeco_v6_stage5_online_20261127_v1/arms/faeco_boxed/attempt_01/faeco/02/initial/routed.v"
link_design riscv
read_sdc "/var/tmp/faeco_v6_stage5_rebuilt_20261127_v2/orfs/results/sky130hd/riscv32i/tc40ns_mmmc_drv/6_final.sdc"
if {[llength [all_clocks]] == 0} { error "No clocks in saved SDC" }
read_spef "/var/tmp/faeco_v6_stage5_online_20261127_v1/arms/faeco_boxed/attempt_01/faeco/02/initial/routed.spef"
puts "IBEX_SETUP_PS [expr {1e12 * [sta::worst_slack_cmd max]}]"
puts "IBEX_HOLD_PS [expr {1e12 * [sta::worst_slack_cmd min]}]"
puts "IBEX_TNS_PS [expr {1e12 * [sta::total_negative_slack_cmd max]}]"
puts "IBEX_HOLD_TNS_PS [expr {1e12 * [sta::total_negative_slack_cmd min]}]"
puts IBEX_MAX_SLEW_START
report_check_types -max_slew -violators -digits 9
puts IBEX_MAX_SLEW_END
puts IBEX_MAX_CAPACITANCE_START
report_check_types -max_capacitance -violators -digits 9
puts IBEX_MAX_CAPACITANCE_END
foreach port [all_inputs -no_clocks] { puts "IBEX_INPUT [get_name $port]" }
foreach port [all_outputs] { puts "IBEX_OUTPUT [get_name $port]" }
check_setup -verbose
report_parasitic_annotation
report_checks -path_delay max -group_path_count 1
report_checks -path_delay min -group_path_count 1

puts IBEX_SETUP_NEG_BEGIN
set paths [find_timing_paths -path_delay max -slack_max 0 -group_path_count 100000 -endpoint_path_count 1]
if {[llength $paths] >= 100000} { error "setup endpoint inventory hit the path report cap" }
foreach path $paths {
    if {[get_property $path slack] < 0} {
        puts "IBEX_SETUP_NEG [get_full_name [get_property $path endpoint]]"
    }
}
puts IBEX_SETUP_NEG_END

puts IBEX_STA_COMPLETE
exit

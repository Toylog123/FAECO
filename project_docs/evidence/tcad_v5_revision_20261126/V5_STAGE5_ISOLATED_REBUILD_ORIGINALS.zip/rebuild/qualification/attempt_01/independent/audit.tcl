read_db "/var/tmp/faeco_v6_stage5_rebuilt_20261127_v2/orfs/results/sky130hd/riscv32i/tc40ns_mmmc_drv/6_final.odb"
if {![design_is_routed]} {error "Unexpected unrouted final state"}
write_def "/var/tmp/faeco_v6_stage5_rebuilt_20261127_v2/qualification/attempt_01/independent/readback.def"
drt::check_drc -output_file "/var/tmp/faeco_v6_stage5_rebuilt_20261127_v2/qualification/attempt_01/independent/drc.rpt"
puts "RESUME_INDEPENDENT_ANTENNA [check_antennas -report_file "/var/tmp/faeco_v6_stage5_rebuilt_20261127_v2/qualification/attempt_01/independent/antenna.rpt"]"
puts RESUME_INDEPENDENT_COMPLETE
exit

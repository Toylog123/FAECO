read_db "/home/toylog/faeco_tcad_uart_wallclock_20261125_v1/cell_03/faeco/16/initial/routed.odb"
set blk [ord::get_db_block]
set fp [open "/var/tmp/FAECO-r5-odb-readback-20261127-02/uart_Table4_pure.tsv" w]
puts $fp "DBU\t[$blk getDbUnitsPerMicron]"
foreach inst [$blk getInsts] {
    set m [$inst getMaster]
    puts $fp "INSTANCE\t[$inst getName]\t[$m getName]\t[$m getType]\t[$m getWidth]\t[$m getHeight]"
}
close $fp
exit

read_db "/home/toylog/faeco_tcad_sky_holdout_20261123/aes_boxed_drc_20261126_v1/forward/faeco_boxed_drc/faeco/05/initial/routed.odb"
set blk [ord::get_db_block]
set fp [open "/var/tmp/FAECO-r5-odb-readback-20261127-02/sky130hd_aes_faeco_9.tsv" w]
puts $fp "DBU\t[$blk getDbUnitsPerMicron]"
foreach inst [$blk getInsts] {
    set m [$inst getMaster]
    puts $fp "INSTANCE\t[$inst getName]\t[$m getName]\t[$m getType]\t[$m getWidth]\t[$m getHeight]"
}
close $fp
exit

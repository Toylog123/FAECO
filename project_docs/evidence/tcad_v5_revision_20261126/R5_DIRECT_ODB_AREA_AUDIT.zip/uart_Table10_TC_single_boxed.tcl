read_db "/home/toylog/faeco_v4_tc_drc_sens_20261126_v1/timing_closed_asap7_uart/runner/single_boxed/18/initial/routed.odb"
set blk [ord::get_db_block]
set fp [open "/var/tmp/FAECO-r5-odb-readback-20261127-02/uart_Table10_TC_single_boxed.tsv" w]
puts $fp "DBU\t[$blk getDbUnitsPerMicron]"
foreach inst [$blk getInsts] {
    set m [$inst getMaster]
    puts $fp "INSTANCE\t[$inst getName]\t[$m getName]\t[$m getType]\t[$m getWidth]\t[$m getHeight]"
}
close $fp
exit

read_db "/var/tmp/faeco_v6_stage5_rebuilt_20261127_v2/orfs/results/sky130hd/riscv32i/tc40ns_mmmc_drv/6_final.odb"
set blk [ord::get_db_block]
set fp [open "/var/tmp/FAECO-r5-odb-readback-20261127-02/riscv32i_reference.tsv" w]
puts $fp "DBU\t[$blk getDbUnitsPerMicron]"
foreach inst [$blk getInsts] {
    set m [$inst getMaster]
    puts $fp "INSTANCE\t[$inst getName]\t[$m getName]\t[$m getType]\t[$m getWidth]\t[$m getHeight]"
}
close $fp
exit

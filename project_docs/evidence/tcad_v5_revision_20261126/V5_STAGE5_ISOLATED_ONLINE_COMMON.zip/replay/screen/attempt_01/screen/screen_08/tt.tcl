read_liberty "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib"
read_db "/var/tmp/faeco_v6_stage5_rebuilt_20261127_v2/orfs/results/sky130hd/riscv32i/tc40ns_mmmc_drv/6_final.odb"
set inst [[ord::get_db_block] findInst "_3672_"]
set target [[ord::get_db] findMaster "sky130_fd_sc_hd__a211oi_2"]
if {$inst eq "NULL" || $target eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__a211oi_4"} {
    error "frozen-screen source/target mismatch"
}
if {![$inst swapMaster $target] || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__a211oi_2"} {
    error "frozen-screen master replacement failed"
}

read_sdc "/var/tmp/faeco_v6_stage5_rebuilt_20261127_v2/orfs/results/sky130hd/riscv32i/tc40ns_mmmc_drv/6_final.sdc"
if {[llength [all_clocks]] == 0} { error "No clocks in saved SDC" }
read_spef "/var/tmp/faeco_v6_stage5_rebuilt_20261127_v2/orfs/results/sky130hd/riscv32i/tc40ns_mmmc_drv/6_final.spef"
puts "IBEX_SETUP_PS [expr {1e12 * [sta::worst_slack_cmd max]}]"
puts "IBEX_HOLD_PS [expr {1e12 * [sta::worst_slack_cmd min]}]"
puts "IBEX_TNS_PS [expr {1e12 * [sta::total_negative_slack_cmd max]}]"
puts "IBEX_HOLD_TNS_PS [expr {1e12 * [sta::total_negative_slack_cmd min]}]"
puts IBEX_MAX_SLEW_START
report_check_types -max_slew -violators -digits 9
puts IBEX_MAX_SLEW_END
puts IBEX_MAX_CAPACITANCE_START
report_check_types -max_capacitance -violators -digits 9
puts IBEX_MAX_CAPACITANCE_END
foreach port [all_inputs -no_clocks] { puts "IBEX_INPUT [get_name $port]" }
foreach port [all_outputs] { puts "IBEX_OUTPUT [get_name $port]" }
check_setup -verbose
puts SCREEN_ANN_BEGIN
report_parasitic_annotation -report_unannotated
puts SCREEN_ANN_END
report_checks -path_delay max -group_path_count 1
report_checks -path_delay min -group_path_count 1

puts IBEX_SETUP_NEG_BEGIN
set paths [find_timing_paths -path_delay max -slack_max 0 -group_path_count 100000 -endpoint_path_count 1]
if {[llength $paths] >= 100000} { error "setup endpoint inventory hit the path report cap" }
foreach path $paths {
    if {[get_property $path slack] < 0} {
        puts "IBEX_SETUP_NEG [get_full_name [get_property $path endpoint]]"
    }
}
puts IBEX_SETUP_NEG_END

puts IBEX_STA_COMPLETE
exit

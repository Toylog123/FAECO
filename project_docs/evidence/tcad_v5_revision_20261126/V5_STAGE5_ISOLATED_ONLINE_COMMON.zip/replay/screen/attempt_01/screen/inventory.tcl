read_liberty "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib"
read_db "/var/tmp/faeco_v6_stage5_rebuilt_20261127_v2/orfs/results/sky130hd/riscv32i/tc40ns_mmmc_drv/6_final.odb"
foreach lib [[ord::get_db] getLibs] {
    foreach master [$lib getMasters] {
        set site [$master getSite]
        set site_name [expr {$site eq "NULL" ? "" : [$site getName]}]
        set pins {}
        foreach pin [$master getMTerms] {
            lappend pins "[$pin getName]:[$pin getIoType]:[$pin getSigType]"
        }
        puts "MASTER	[$master getName]	[$master getType]	[$master getHeight]	$site_name	[join [lsort $pins] ,]	[$master getWidth]"
    }
}
foreach inst [[ord::get_db_block] getInsts] {
    set clock 0
    foreach pin [$inst getITerms] {
        set net [$pin getNet]
        if {$net ne "NULL" && [$net getSigType] eq "CLOCK"} { set clock 1 }
    }
    puts "INSTANCE	[$inst getName]	[[$inst getMaster] getName]	[$inst getPlacementStatus]	$clock	[$inst isDoNotTouch]"
}
puts IBEX_INVENTORY_COMPLETE
exit

read_liberty "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib"
read_db "/var/tmp/faeco_v6_stage5_rebuilt_20261127_v2/orfs/results/sky130hd/riscv32i/tc40ns_mmmc_drv/6_final.odb"

foreach item [[ord::get_db_block] getInsts] {
    set count 0
    foreach term [$item getITerms] {
        if {[[$term getMTerm] getIoType] ne "OUTPUT"} { continue }
        set net [$term getNet]
        if {$net eq "NULL"} { continue }
        set sinks 0
        foreach pin [$net getITerms] {
            if {[[$pin getMTerm] getIoType] in {INPUT INOUT}} { incr sinks }
        }
        foreach port [$net getBTerms] {
            if {[$port getIoType] in {OUTPUT INOUT}} { incr sinks }
        }
        set count [expr {max($count,$sinks)}]
    }
    puts "SCREEN_FANOUT\t[$item getName]\t$count"
}
puts SCREEN_FANOUT_COMPLETE
exit

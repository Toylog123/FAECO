read_liberty "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib"
read_db "/home/toylog/faeco_v5_step5_riscv32i_tc40ns_mmmc_drv_20261127_v1/orfs/results/sky130hd/riscv32i/tc40ns_mmmc_drv/6_final.odb"
read_sdc "/home/toylog/faeco_v5_step5_riscv32i_tc40ns_mmmc_drv_20261127_v1/orfs/results/sky130hd/riscv32i/tc40ns_mmmc_drv/6_final.sdc"
if {[llength [all_clocks]] == 0} { error "No clocks in saved SDC" }
read_spef "/home/toylog/faeco_v5_step5_riscv32i_tc40ns_mmmc_drv_20261127_v1/orfs/results/sky130hd/riscv32i/tc40ns_mmmc_drv/6_final.spef"
set_cmd_units -time ns
puts "RANK_WNS_PS [expr {1e12 * [sta::worst_slack_cmd max]}]"
foreach name [list {_4264_} {_3714_} {_4024_} {_4134_} {_4162_} {_4713_} {_7128_} {_3672_} {_3900_} {_3964_} {_4598_} {_4696_} {_4718_} {_7034_} {_3652_} {_3836_} {_3962_} {_4236_}] {
    set cell [get_cells -quiet $name]
    if {[llength $cell] != 1 || [get_full_name $cell] ne $name} { error "Wrong candidate instance: $name" }
    foreach pin [get_pins -quiet -of_objects $cell -filter "direction==output"] {
        puts "RANK_PIN $name [get_name $pin] [expr {1e3 * [get_property $pin slack_max]}]"
    }
}
puts AES_TT_RANK_COMPLETE
exit

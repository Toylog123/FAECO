read_db "/home/toylog/faeco_v5_step5_riscv32i_tc40ns_mmmc_drv_20261127_v1/arms/single_boxed/attempt_02/single/06/retry/routed.odb"
read_def -floorplan_initialize "/home/toylog/faeco_v5_step5_riscv32i_tc40ns_mmmc_drv_20261127_v1/arms/single_boxed/attempt_02/single/06/retry/unlocked_drc/normalized_nets.def"
write_def "/home/toylog/faeco_v5_step5_riscv32i_tc40ns_mmmc_drv_20261127_v1/arms/single_boxed/attempt_02/single/06/retry/unlocked_drc/normalized_geometry.def"
if {![design_is_routed]} { error "Unrouted signal nets" }
drt::check_drc -output_file "/home/toylog/faeco_v5_step5_riscv32i_tc40ns_mmmc_drv_20261127_v1/arms/single_boxed/attempt_02/single/06/retry/unlocked_drc/full_drc.rpt"
puts AES_UNLOCKED_DRC_COMPLETE
exit

import importlib.util, runpy, sys
spec = importlib.util.spec_from_file_location('prove_ibex', '/mnt/d/BaiduSyncdisk/01_Papers/03_FAECO/project_docs/evidence/tcad_ibex_20261123/prove_ibex.py')
module = importlib.util.module_from_spec(spec)
sys.modules['prove_ibex'] = module
spec.loader.exec_module(module)
runpy.run_path('/home/toylog/faeco_tcad_anytime_holdouts_20261125_v1/sec_native.py', run_name='__main__')

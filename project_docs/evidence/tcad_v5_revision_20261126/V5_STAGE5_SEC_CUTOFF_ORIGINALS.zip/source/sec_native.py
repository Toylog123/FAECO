#!/usr/bin/env python3
"""Two-state model for the two selected independent tops."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path('/mnt/d/BaiduSyncdisk/01_Papers/03_FAECO/project_docs/evidence/tcad_holdout_20261123')))
import holdout_tools
holdout_tools.TOPS.update(('riscv','ethmac'))
raise SystemExit(holdout_tools.run_sec())

#!/usr/bin/env python3
"""Compare original and repaired SEC on the rejected-by-deadline candidate."""

from dataclasses import asdict
from hashlib import sha256
import json
import os
from pathlib import Path
import sys
import time


REPO = Path("/mnt/d/BaiduSyncdisk/01_Papers/03_FAECO")
EVIDENCE = Path("project_docs/evidence")
PROVER = EVIDENCE / "tcad_ibex_20261123/prove_ibex.py"
CAPSULE = Path("/var/tmp/faeco_v6_stage5_input_20261127_v4/project")
ONLINE = Path("/var/tmp/faeco_v6_stage5_online_20261127_v1")
HOME = Path("/home/toylog")
NATIVE = HOME / "faeco_tcad_anytime_holdouts_20261125_v1/sec_native.py"
HISTORICAL = HOME / "faeco_v5_step5_riscv32i_tc40ns_mmmc_drv_20261127_v1"
SHORT = 1.7176138909999281


def binding(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": sha256(data).hexdigest()}


def read(path):
    return json.loads(path.read_bytes())


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def observe(proof):
    processes = []
    script_arg = os.fsencode(proof / "prove.ys")
    for proc in Path("/proc").iterdir():
        if not proc.name.isdecimal():
            continue
        try:
            cmd = (proc / "cmdline").read_bytes().split(b"\0")
            if script_arg in cmd:
                status = (proc / "stat").read_text().rsplit(") ", 1)[1].split()
                if status[0] != "Z":
                    processes.append({"pid": int(proc.name), "ppid": int(status[1]), "pgid": int(status[2]),
                                      "sid": int(status[3]), "argv": list(map(os.fsdecode, cmd[:-1]))})
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    return {"raw_seconds": time.clock_gettime(time.CLOCK_MONOTONIC_RAW), "processes": processes,
            "log_size": (proof / "prove.log").stat().st_size}


def arm(runner, directory, source, gold, gate, libraries, limit):
    directory.mkdir()
    entry = directory / "launch_native.py"
    entry.write_text(
        "import importlib.util, runpy, sys\n"
        f"spec = importlib.util.spec_from_file_location('prove_ibex', {str(source)!r})\n"
        "module = importlib.util.module_from_spec(spec)\n"
        "sys.modules['prove_ibex'] = module\n"
        "spec.loader.exec_module(module)\n"
        f"runpy.run_path({str(NATIVE)!r}, run_name='__main__')\n", encoding="utf-8",
    )
    proof = directory / "proof"
    result = runner([sys.executable, "-B", str(entry), str(gold), str(gate), str(proof)],
                    directory / "wrapper.log", limit, env=os.environ | {
                        "FAECO_DESIGN_TOP": "riscv", "FAECO_SEC_LIBRARIES": json.dumps(libraries),
                    })
    observations = [observe(proof)]
    deadline = time.monotonic() + 20
    while observations[-1]["processes"]:
        if time.monotonic() >= deadline:
            raise TimeoutError(f"proof subprocess still executing: {proof}")
        time.sleep(0.2)
        observations.append(observe(proof))
    time.sleep(0.15)
    observations.append(observe(proof))
    receipt = proof / "receipt.json"
    text = (proof / "prove.log").read_bytes()
    value = {"wrapper": asdict(result), "source": binding(source), "observations": observations,
             "proof_log": binding(proof / "prove.log"), "proof_script": binding(proof / "prove.ys"),
             "log_proved_4559": b"4559 are proven and 0 are unproven" in text
             and b"Equivalence successfully proven!" in text,
             "receipt": binding(receipt) if receipt.exists() else None}
    save(directory / "observation.json", value)
    print(directory.name, result.returncode, len(observations[0]["processes"]),
          value["log_proved_4559"], receipt.exists(), flush=True)
    return value


def main(output):
    sys.path.insert(0, str(REPO / EVIDENCE / "tcad_wallclock_schedule_20261125"))
    from raw_timed_process import run_process

    state = read(ONLINE / "stage5_progress.json")
    assert state["status"] == "finished" and state["active_arm"] is None
    ref = read(Path(state["qualification"]["path"]))
    gold = Path(ref["control_output_paths"]["v"]["path"])
    gate = ONLINE / "arms/single_boxed/attempt_01/single/08/initial/routed.v"
    previous = read(HISTORICAL / "arms/single_boxed/attempt_02/single/08/initial/sec/receipt.json")
    assert all(binding(point)["sha256"] == previous[key]["sha256"]
               for key, point in (("gold", gold), ("gate", gate)))
    for item in [*previous["liberties"], previous["yosys_binary"], previous["yosys_launcher"]]:
        assert binding(Path(item["path"])) == item
    models = [item["path"] for item in previous["liberties"]]
    old, fixed = CAPSULE / PROVER, REPO / PROVER
    assert binding(old)["sha256"] == "9388a0c69c13ab2dc91352e3431ebcd5927d1884c79ed8db2b38ec0f67403e7b"
    assert binding(fixed)["sha256"] == "861d3549ea8f20f082c6b30e58e7c3bb4cf56adabd48a50f210cf749d86ddfd4"
    output.mkdir()
    protocol = {"gold": binding(gold), "gate": binding(gate), "liberties": previous["liberties"],
                "native_entry": binding(NATIVE), "old": binding(old), "fixed": binding(fixed),
                "cpu_affinity": sorted(os.sched_getaffinity(0)), "short_limit": SHORT, "full_limit": 30.0}
    save(output / "protocol.json", protocol)
    a = arm(run_process, output / "original_short", old, gold, gate, models, SHORT)
    b = arm(run_process, output / "fixed_short", fixed, gold, gate, models, SHORT)
    c = arm(run_process, output / "fixed_full", fixed, gold, gate, models, 30.0)
    assert a["wrapper"]["returncode"] is None and a["receipt"] is None
    assert a["observations"][0]["processes"]
    assert a["observations"][-1]["log_size"] > a["observations"][0]["log_size"]
    assert b["wrapper"]["returncode"] is None and b["receipt"] is None
    assert not any(s["processes"] for s in b["observations"]) and not b["log_proved_4559"]
    assert b["observations"][0]["log_size"] == b["observations"][-1]["log_size"]
    assert c["wrapper"]["returncode"] == 0 and c["receipt"] and c["log_proved_4559"]
    receipt = read(Path(c["receipt"]["path"]))
    assert receipt["gold"] == protocol["gold"] and receipt["gate"] == protocol["gate"]
    assert receipt["passed"] and receipt["proven"] == 4559 and receipt["unproven"] == 0
    save(output / "verified.json", {"status": "verified", "protocol": binding(output / "protocol.json"),
                                    "arms": {name: binding(output / name / "observation.json")
                                             for name in ("original_short", "fixed_short", "fixed_full")}})


if __name__ == "__main__":
    main(Path(sys.argv[1]).resolve())

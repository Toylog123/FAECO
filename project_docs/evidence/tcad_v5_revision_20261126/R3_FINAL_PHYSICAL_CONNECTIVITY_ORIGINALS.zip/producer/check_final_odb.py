"""Check placement and PSM connectivity on exact R3 processor ODBs."""

import argparse
from hashlib import file_digest, sha256
import json
from pathlib import Path
import re
import subprocess
import time


SEARCH = Path('/var/tmp/faeco_v6_stage5_online_sec_fixed_20261127_v1/stage5_progress.json')
TOOL = Path('/home/toylog/.cache/bazel/_bazel_toylog/c540bbdc4bbb635360729b4d7a91c803/execroot/_main/bazel-out/k8-opt/bin/openroad_unstamped')
TOOL_SHA = '2d9662715130538b50e93b614c33099a5e183eef0cc31b642099daea8d203e19'
ODB_SHA = {
    'reference': '8703269738b504c2664c1acd7f20cb3b5742a522e5e878ce476546911f333178',
    'single_boxed': '8b166fa9c70dbc496161510f87cdb95c092400b27c6e92cf482e36252e1cab27',
    'fixed_boxed': 'e2b5f622ad2477abfe040e1030feae3d947428c5e6c45dac77613e9d2dfbfed1',
    'faeco_boxed': '7ff73d0f3e891d05d30468c6371e141aa681ae30fd6bd96076fa465ce7e80fcd',
}
CHECKS = ('ODB_ROUTED', 'PLACEMENT', 'PSM_VDD', 'PSM_VSS')


def bind(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'sha256': digest, 'bytes': path.stat().st_size}


def verify(binding):
    if bind(binding['path']) != binding:
        raise ValueError(f'input no longer matches the frozen artifact: {binding["path"]}')
    return Path(binding['path'])


def read(path):
    return json.loads(Path(path).read_text())


def write_json(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def tcl(value):
    if any(symbol in str(value) for symbol in '\n\r{}'):
        raise ValueError(f'cannot embed artifact path in Tcl: {value!s}')
    return '{' + str(value) + '}'


def inputs():
    state = read(SEARCH)
    if state['status'] != 'finished' or state['active_arm'] is not None:
        raise ValueError('Stage 5 state is no longer the accepted completion')
    protocol = read(verify(state['protocol']))
    seed = read(verify(protocol['seed']))
    tool = seed['bindings']['tools']['openroad']
    if Path(tool['path']) != TOOL or tool['sha256'] != TOOL_SHA:
        raise ValueError('OpenROAD does not match the historical route runner')
    verify(tool)
    qualification = read(verify(state['qualification']))
    targets = {'reference': {'receipt': state['qualification'],
                             **{k: qualification['control_output_paths'][k] for k in ('odb', 'def')}}}
    for method, arm in state['arms'].items():
        checkpoint = arm['accepted_checkpoints'][-1]
        physical = checkpoint['physical']
        record = read(verify(physical))
        target = {'receipt': physical, **{k: record['artifacts'][k] for k in ('odb', 'def')}}
        route = record['operations']['DRT_RCX']
        log = Path(route['log'])
        command = [row['command'] for row in read(verify(arm['tool_ledger'])) if row['log'] == str(log)]
        if len(command) != 1 or command[0][0] != str(TOOL):
            raise ValueError(f'{method} endpoint does not bind the exact tool run')
        target.update({'old_route_log': bind(log), 'old_route_command': command[0],
                       'route_scope_audit': bind(log.parent / 'routing_audit.json'),
                       'independent_drc': checkpoint['drc'], 'sec': checkpoint['sec']})
        targets[method] = target
    if list(targets) != list(ODB_SHA):
        raise ValueError('the four frozen endpoint identities are not present')
    for key, target in targets.items():
        if target['odb']['sha256'] != ODB_SHA[key]:
            raise ValueError(f'{key} ODB is not the pinned version')
        for path in ('odb', 'def', 'receipt', 'independent_drc', 'sec'):
            if path in target:
                verify(target[path])
    return state, tool, targets


def def_sections(binding):
    data = verify(binding).read_bytes()
    facts = {}
    for name in (b'PINS', b'SPECIALNETS'):
        match = re.search(rb'(?ms)^' + name + rb'\s+.*?^END ' + name + rb'\s*$', data)
        if match is None:
            raise ValueError(f'{name!r} absent from {binding["path"]}')
        facts[name.decode()] = {'bytes': len(match.group().rstrip()),
                                'sha256': sha256(match.group().rstrip()).hexdigest()}
    return facts


def script_for(odb, directory):
    return f'''# Intentionally no save, legalization, reroute, or PDN modification.
read_db {tcl(odb)}
puts "R3_READ_DB_COMPLETE"
set failed 0
proc run_r3_check {{id command require_true}} {{
    global failed
    puts "R3_CHECK_BEGIN $id"
    set status [catch {{uplevel 1 $command}} result]
    if {{$status || ($require_true && $result ne "1")}} {{
        set failed 1
        puts "R3_CHECK_FAIL $id $result"
    }} else {{
        puts "R3_CHECK_PASS $id"
    }}
}}
run_r3_check ODB_ROUTED {{design_is_routed -verbose}} 1
run_r3_check PLACEMENT [list check_placement -verbose -report_file_name {tcl(directory / 'placement.json')}] 0
run_r3_check PSM_VDD [list check_power_grid -net VDD -error_file {tcl(directory / 'VDD.errors.rpt')}] 1
run_r3_check PSM_VSS [list check_power_grid -net VSS -error_file {tcl(directory / 'VSS.errors.rpt')}] 1
puts "R3_CHECKS_COMPLETE $failed"
exit $failed
'''


def run_one(label, endpoint, root):
    folder = root / label
    folder.mkdir()
    odb = verify(endpoint['odb'])
    script = folder / 'check.tcl'
    script.write_text(script_for(odb, folder), encoding='utf-8')
    log = folder / 'openroad.log'
    argv = ['/usr/bin/timeout', '--foreground', '--kill-after=5s', '120s', str(TOOL),
            '-no_init', '-no_splash', '-threads', '1', '-exit', str(script)]
    start = time.monotonic()
    with log.open('wb') as stream:
        result = subprocess.run(argv, cwd=folder, stdout=stream, stderr=subprocess.STDOUT, check=False)
    stdout = log.read_text(encoding='utf-8', errors='replace')
    statuses = {name: ('pass' if re.search(rf'(?m)^R3_CHECK_PASS {name}$', stdout) else
                       'fail' if re.search(rf'(?m)^R3_CHECK_FAIL {name}(?: |$)', stdout) else 'unobserved')
                for name in CHECKS}
    evidence = {p.name: bind(p) for p in sorted(folder.iterdir()) if p.is_file()}
    verify(endpoint['odb'])
    verify(endpoint['def'])
    row = {'target': label, 'command': argv, 'returncode': result.returncode,
           'elapsed_s': time.monotonic() - start, 'checks': statuses, 'artifacts': evidence,
           'odb_unchanged': True, 'def_unchanged': True,
           'passed': result.returncode == 0 and all(x == 'pass' for x in statuses.values())
           and 'R3_CHECKS_COMPLETE 0' in stdout}
    write_json(folder / 'result.json', row)
    print(label, 'rc', row['returncode'], 'seconds', round(row['elapsed_s'], 3), statuses, flush=True)
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    root = args.output.resolve()
    state, tool, targets = inputs()
    root.mkdir()
    sections = {label: def_sections(entry['def']) for label, entry in targets.items()}
    if len({json.dumps(item, sort_keys=True) for item in sections.values()}) != 1:
        raise ValueError('frozen reference and endpoints do not have equal PINS/SPECIALNETS sections')
    write_json(root / 'protocol.json', {'driver': bind(Path(__file__)), 'tool': tool,
                                       'old_stage5_state': bind(SEARCH), 'old_stage5_seed': state['protocol'],
                                       'input': targets, 'def_sections': sections})
    print('R3 exact four-ODB inspection started', root, flush=True)
    rows = [run_one(name, entry, root) for name, entry in targets.items()]
    write_json(root / 'results.json', {'passed': all(row['passed'] for row in rows), 'endpoints': rows,
                                      'protocol': bind(root / 'protocol.json')})
    return 0 if all(row['passed'] for row in rows) else 1


if __name__ == '__main__':
    raise SystemExit(main())

# Intentionally no save, legalization, reroute, or PDN modification.
read_db {/var/tmp/faeco_v6_stage5_online_sec_fixed_20261127_v1/arms/faeco_boxed/attempt_01/faeco/03/initial/routed.odb}
puts "R3_READ_DB_COMPLETE"
set failed 0
proc run_r3_check {id command require_true} {
    global failed
    puts "R3_CHECK_BEGIN $id"
    set status [catch {uplevel 1 $command} result]
    if {$status || ($require_true && $result ne "1")} {
        set failed 1
        puts "R3_CHECK_FAIL $id $result"
    } else {
        puts "R3_CHECK_PASS $id"
    }
}
run_r3_check ODB_ROUTED {design_is_routed -verbose} 1
run_r3_check PLACEMENT [list check_placement -verbose -report_file_name {/var/tmp/faeco_r3_final_odb_connectivity_20261127_v1/faeco_boxed/placement.json}] 0
run_r3_check PSM_VDD [list check_power_grid -net VDD -error_file {/var/tmp/faeco_r3_final_odb_connectivity_20261127_v1/faeco_boxed/VDD.errors.rpt}] 1
run_r3_check PSM_VSS [list check_power_grid -net VSS -error_file {/var/tmp/faeco_r3_final_odb_connectivity_20261127_v1/faeco_boxed/VSS.errors.rpt}] 1
puts "R3_CHECKS_COMPLETE $failed"
exit $failed

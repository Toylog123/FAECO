read_liberty "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib"
read_db "/var/tmp/faeco_v6_stage5_online_sec_fixed_20261127_v1/arms/fixed_boxed/attempt_01/fixed/06/initial/routed.odb"
read_sdc "/var/tmp/faeco_v6_stage5_rebuilt_20261127_v2/orfs/results/sky130hd/riscv32i/tc40ns_mmmc_drv/6_final.sdc"
read_spef "/var/tmp/faeco_v6_stage5_online_sec_fixed_20261127_v1/arms/fixed_boxed/attempt_01/fixed/06/initial/routed.spef"
report_power -digits 9 -format json > "/var/tmp/faeco_v6_stage5_online_sec_fixed_20261127_v1/arms/fixed_boxed/attempt_01/best_pwr_power.json"
puts PWR_OK
exit

"""Run the real-WNS outer-loop recovery on an ISCAS89 sequential circuit.

N31-05 real-STA closure: drives the FAECO outer refinement loop
(run_multi_iteration_case) with a real OpenSTA evaluator
(RealWnsEvaluator) instead of a logic-level proxy.  For each candidate
cut produced by the weighted min-cut search, the evaluator:

  1. maps the cut gates onto the real SKY130 mapped netlist;
  2. generates R (equivalent-cell rewrite) / G (gate sizing) / optional B
     (buffer insertion) candidates for the critical-path instances;
  3. measures every candidate with real OpenSTA (pre-layout, ideal nets);
  4. accepts only candidates that strictly improve the baseline WNS.

The outer loop explores candidate cuts in weight order within each
iteration; if none improves WNS it classifies the failure (F4 timing gain
insufficient) and refines the F1-F5 search weights, then re-cuts.  This
makes the recovery genuinely failure-aware and measured end-to-end.

Usage (PowerShell):
  $env:PYTHONPATH='src'; python scripts/run_outerloop_real_wns.py
      --circuit s382 --period 0.5 --output-dir experiments/20260804_outerloop_realwns
"""
from __future__ import annotations

import argparse
from dataclasses import asdict
import json
import subprocess
import sys
from pathlib import Path

try:
    from run_sequential_timing_check import run_opensta, run_yosys_mapping  # reuse verified runners
except ModuleNotFoundError:  # imported by a test runner rather than executed as a script
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from run_sequential_timing_check import run_opensta, run_yosys_mapping

from rseco.feedback import ADAPTIVE_CONFIG, LEGACY_CONFIG, FeedbackConfig
from rseco.flow import run_multi_iteration_case
from rseco.real_wns import (
    RealWnsEvaluator,
    build_full_netlist_sec_checker,
    build_real_equivalence_checker,
    build_boundary_closure_checker,
    build_r_available,
    dff_d_input_net,
    parse_critical_instances,
    parse_worst_endpoint,
    strip_to_single_module,
)


ROOT = Path(__file__).resolve().parents[2]
# 2026-09-12 migration: `benchmarks/` became `data/raw/benchmarks/` and this
# script moved one level deeper (`scripts/` -> `code/scripts/`), so both the
# parents[] index and the data root had to be re-pointed.
_BENCH = ROOT / "data" / "raw" / "benchmarks"
LIB = (
    _BENCH
    / "raw"
    / "openroad_flow_scripts_sky130hd"
    / "da8f092a02a8e75658cc3100691aabff05f35629"
    / "lib"
    / "sky130_fd_sc_hd__tt_025C_1v80.lib"
)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--circuit", default="s382", help="ISCAS89 circuit id")
    p.add_argument("--iscas89-dir", type=Path, default=_BENCH / "raw" / "iscas89")
    p.add_argument("--source-file", type=Path, default=None,
                   help="Explicit RTL/netlist path (overrides --circuit in iscas89-dir)")
    p.add_argument("--period", type=float, default=0.5, help="Clock period (ns)")
    p.add_argument("--output-dir", type=Path, required=True)
    p.add_argument("--max-iterations", type=int, default=6)
    p.add_argument("--max-patches", type=int, default=None,
                   help="Hard maximum accepted patches; 0 stops before any candidate")
    p.add_argument("--sta-budget", type=int, default=None,
                   help="Hard maximum candidate STA reservations")
    p.add_argument("--formal-budget", type=int, default=None,
                   help="Hard maximum candidate formal-check reservations")
    p.add_argument("--wall-timeout-s", type=float, default=None,
                   help="Hard wall-clock budget for the outer loop")
    p.add_argument("--candidates-per-iteration", type=int, default=8,
                   help="Cut candidates explored per iteration (beam width; 1 isolates feedback)")
    p.add_argument("--cut-search-policy", choices=("legacy", "weighted_st"), default="legacy",
                   help="Candidate-boundary search: preserve legacy behavior or use canonical weighted s-t cuts")
    p.add_argument("--cut-sources", choices=("full", "weighted", "cover"), default="full",
                   help="Weighted s-t source control: both sources, Cw only, or Cc only")
    p.add_argument("--node-cost-mode", choices=("configured", "uniform"), default="configured",
                   help="Use configured node costs or unit capacities in the weighted s-t path")
    p.add_argument("--disable-topology", action="store_true",
                   help="Disable topology-rewrite candidates; preserves the legacy enabled default when omitted")
    p.add_argument("--no-feedback", action="store_true",
                   help="Disable F1-F5 weight refinement (ablation control; "
                        "Mixed-Fixed arm of the r2 §6 three-arm experiment)")
    feedback_group = p.add_mutually_exclusive_group()
    feedback_group.add_argument(
        "--feedback-legacy", action="store_const", dest="feedback_config_name",
        const="legacy",
        help="Legacy multiplicative weight refinement (LEGACY_CONFIG: "
             "rho=0, eta=1, clip off) -- bit-identical to the pre-L2 path")
    feedback_group.add_argument(
        "--feedback-ema", action="store_const", dest="feedback_config_name",
        const="ema",
        help="L2 EMA-smoothed failure feedback (ADAPTIVE_CONFIG: rho=0.5, "
             "eta_add=0.5, eta_c=0.25, clip on) -- FAECO-Adaptive arm of "
             "the r2 §6 three-arm experiment")
    p.set_defaults(feedback_config_name=None)
    p.add_argument("--random-order", action="store_true",
                   help="Shuffle candidate cuts within each iteration with a "
                        "seeded RNG (Mixed-Random arm; pairs with --seed)")
    p.add_argument("--seed", type=int, default=1,
                   help="RNG seed for --random-order (use 1, 2, 3 across runs)")
    p.add_argument("--workers", type=int, default=4,
                   help="Parallel OpenSTA evaluations per candidate (1 = serial)")
    p.add_argument("--enable-buffer", action="store_true",
                   help="Also try strategy B (buffer insertion)")
    p.add_argument("--tns-aware", action="store_true",
                   help="Accept WNS-equal candidates that improve TNS")
    p.add_argument("--max-instances", type=int, default=8,
                   help="Max patch gates evaluated per candidate (critical first)")
    p.add_argument("--joint-k", type=int, default=0,
                   help="Enable joint repair: also test a candidate that resizes the top-k "
                        "actionable gates simultaneously (0 disables)")
    p.add_argument("--adaptive", action="store_true",
                   help="Online adaptive decision layer: update per-cell-type strategy "
                        "priority from measured trials (UCB + recency decay) instead of "
                        "the static priority table")
    p.add_argument("--hold-mode", action="store_true",
                   help="Hold-repair mode: evaluate candidates under set_clock_uncertainty "
                        "-hold and accept only strict worst-min-slack improvements that "
                        "do not degrade setup WNS below the baseline")
    p.add_argument("--hold-uncertainty", type=float, default=0.8,
                   help="Clock hold uncertainty (ns) injected via set_clock_uncertainty "
                        "-hold in hold mode")
    p.add_argument("--priority-table", type=Path, default=None,
                   help="Path to strategy_priority_table.json; orders R/G/B by decision layer")
    proxy_group = p.add_mutually_exclusive_group()
    proxy_group.add_argument(
        "--proxy-ranking", action="store_true", dest="proxy_ranking",
        help="Enable auditable pre-STA proxy ranking (opt-in; not used by historical batches)",
    )
    proxy_group.add_argument(
        "--no-proxy-ranking", action="store_false", dest="proxy_ranking",
        help="Preserve the legacy strategy-priority order",
    )
    p.set_defaults(proxy_ranking=False)
    p.add_argument("--skip-mapping", action="store_true",
                   help="Reuse existing mapped.v instead of re-running Yosys")
    p.add_argument("--clock-port", default="CK",
                   help="Clock port name in the mapped netlist (CK for ISCAS89/ITC-99, clk for PicoRV32)")
    p.add_argument("--yosys-wsl", action="store_true",
                   help="Fall back to WSL2 Ubuntu Yosys 0.33 (default is the native\n                   OSS-CAD Suite nightly Yosys 0.67, unified FAECO toolchain)")
    # --- early-stop surface (0a merge of two divergent meanings) -------------
    # In the unified-loop architecture ``early_stop`` is a RealWnsEvaluator
    # field that short-circuits the INNER candidate loop (``_eval_one``: stop at
    # the first WNS-improving change).  The OUTER loop's accept budget is
    # governed by ``--max-patches`` (default == ``--max-iterations``).
    #
    # The pre-2026-09-12 trunk used ``--no-early-stop`` to mean "do not return
    # from the OUTER loop at the first accept".  That outer-level stop no longer
    # exists -- the state-driven loop keeps iterating until a stop reason is set
    # -- so main's old semantics now read as ``--max-patches 1``.
    # ``--no-early-stop`` is kept as an accepted alias (it forces the inner loop
    # open) so 20260908 run scripts keep working.
    #
    # NOTE: main's trunk defaulted ``early_stop=True`` "for the 20260826 batch";
    # the codex lineage that actually produced those artifacts defaults to
    # False.  The default stays at True here (trunk contract, no silent flip)
    # and must be settled against the recorded artifacts in the 0a E1-E6 gate.
    p.add_argument("--early-stop", action="store_true", dest="early_stop",
                   help="Stop the inner candidate loop at the first WNS improvement "
                        "(serial only).  For the pre-2026-09-12 outer-loop "
                        "'stop at first accept' behaviour use --max-patches 1.")
    p.add_argument("--no-early-stop", action="store_false", dest="early_stop",
                   help="Keep evaluating every candidate of an iteration even after a "
                        "WNS improvement (the default anyway; retained as an explicit "
                        "alias for 20260908 run scripts).")
    p.set_defaults(early_stop=True)
    p.add_argument("--physical-gate", action="store_true",
                   help="Enable paired physical gating: candidate SPEF WNS gain must meet "
                        "--min-physical-gain and paired TNS/hold must not regress (F6 feedback)")
    p.add_argument("--min-physical-gain", type=float, default=0.010,
                   help="Minimum paired physical candidate-vs-baseline WNS gain in ns")
    p.add_argument("--physical-fanout-penalty", type=float, default=1.0,
                   help="SPEF fanout penalty multiplier (>1 lengthens high-fanout nets)")
    p.add_argument("--physical-depth-penalty", type=float, default=1.0,
                   help="SPEF logic-depth penalty multiplier (>1 lengthens deep paths)")
    p.add_argument("--joint-enumerate-depth", type=int, default=0,
                   help="TCAD sprint: enumerate multi-gate joint candidates along the "
                        "critical path within a sliding window of this depth "
                        "(2..window subsets, bounded to 50); OpenSTA picks the best")
    p.add_argument("--strategies", default="R,G,B",
                   help="Comma-separated strategy kinds to enable (ablation: R, G, B, "
                        "R,G, R,B, G,B, R,G,B)")
    p.add_argument("--init-boundary-penalty", type=float, default=1.0,
                   help="Initial cut boundary penalty (sensitivity analysis lambda_1)")
    p.add_argument("--init-size-penalty", type=float, default=1.0,
                   help="Initial cut size penalty (sensitivity analysis lambda_2)")
    p.add_argument("--init-critical-coverage-reward", type=float, default=1.0,
                   help="Initial critical-coverage reward (sensitivity analysis lambda_3)")
    p.add_argument("--init-verification-cost-penalty", type=float, default=1.0,
                   help="Initial node-cost verification-scale penalty")
    p.add_argument("--init-equivalence-stability-reward", type=float, default=1.0,
                   help="Initial R-gated fanout penalty in the node cost")
    p.add_argument("--epsilon", type=float, default=0.0,
                   help="Configured timing-comparison epsilon (ns), recorded in logs")
    p.add_argument("--required-metrics", default="setup_wns,setup_tns",
                   help="Comma-separated hard acceptance metrics; default uses only measurable setup WNS/TNS. "
                        "Area/transition/cap/fanout are explicit and fail closed when unavailable.")

    p.add_argument("--physical-unit-len", type=float, default=40.0,
                   help="SPEF unit wire length (um); lower = lighter physical load "
                        "(2um approximates post-placement Manhattan distance)")

    # L3 S (r2 §4.9): window-local structure resynthesis as an independent
    # candidate type.  Off by default so every earlier arm stays bit-identical.
    p.add_argument("--structure-resynth", action="store_true",
                   help="Enable the L3 S window-local structure resynthesis "
                        "candidate type (r2 §4.9).  Runs only after the R/G/B "
                        "candidates of a round all fail to improve timing.")
    p.add_argument("--resynth-per-iteration", type=int, default=1,
                   help="How many cut boundaries per round are handed to S "
                        "(also bounded by --candidates-per-iteration)")
    p.add_argument("--resynth-window-pool", type=int, default=None,
                   help="Lever L1 (tech design §13.3): size of S's OWN cut-boundary "
                        "pool. Omit to keep the historical behaviour (S reuses the "
                        "--candidates-per-iteration-truncated list, i.e. pool == k). "
                        "Set larger than --candidates-per-iteration to give S a "
                        "dedicated _cone_candidates(k=pool) enumeration; the weighted "
                        "cut enumeration returns exactly k+1 boundaries (census "
                        "2026-09-28), so this is what actually widens S's reach.")
    p.add_argument("--resynth-variants", default="S0,S1,S2",
                   help="ABC variant chain for S (default S0,S1,S2 — r2 §4.3)")
    p.add_argument("--structure-out-dir", type=Path, default=None,
                   help="Where S window artifacts are written "
                        "(default: <output-dir>/structure_resynth)")

    # Electrical-risk collection (design plan §3 phase 3-A).  Collection only:
    # it records the worst max-slew / max-capacitance / max-fanout of every
    # candidate (and of the pre-patch baseline) for the later correlation
    # study.  Off by default so every earlier arm stays bit-identical, and it
    # never touches ranking, budgets or acceptance.
    p.add_argument("--capture-electrical", action="store_true",
                   help="Capture per-candidate electrical quantities "
                        "(max_transition / max_capacitance / max_fanout and the "
                        "critical-path electrical profile) into the trial record "
                        "(design plan §3 phase 3-A; collection only)")
    args = p.parse_args()
    from rseco.candidate_policy import validate_policy
    try:
        validate_policy(args.cut_search_policy,args.cut_sources,args.node_cost_mode)
    except ValueError as exc:
        p.error(str(exc))
    experimental_cuts = (args.cut_search_policy != "legacy"
                         or args.cut_sources != "full"
                         or args.node_cost_mode != "configured")
    if experimental_cuts and args.structure_resynth:
        p.error("experimental cut controls cannot be combined with --structure-resynth")
    if args.cut_search_policy == "weighted_st":
        strategies = [s.strip() for s in args.strategies.split(",") if s.strip()]
        if not strategies or set(strategies) - {"R", "G", "B"}:
            p.error("--strategies for weighted_st must contain only R, G, or B")
    return args


def main() -> int:
    args = parse_args()
    # r2 §6 three-arm selection: --no-feedback -> Mixed-Fixed;
    # --feedback-legacy -> LEGACY_CONFIG; --feedback-ema -> ADAPTIVE_CONFIG
    # (FAECO-Adaptive).  ``--adaptive`` (UCB decision layer) is a *separate*
    # mechanism and stays orthogonal to the feedback config.
    if args.no_feedback:
        if args.feedback_config_name is not None:
            print("--no-feedback is mutually exclusive with the "
                  "--feedback-legacy/--feedback-ema selectors", file=sys.stderr)
            return 2
        enable_feedback = False
        feedback_config: FeedbackConfig | None = None
    else:
        feedback_config = {
            "legacy": LEGACY_CONFIG,
            "ema": ADAPTIVE_CONFIG,
        }.get(args.feedback_config_name)
        enable_feedback = True
    circuit_path = args.source_file or (args.iscas89_dir / f"{args.circuit}.v")
    if not circuit_path.exists():
        print(f"{args.circuit}: circuit not found: {circuit_path}", file=sys.stderr)
        return 1
    out = args.output_dir / args.circuit
    out.mkdir(parents=True, exist_ok=True)

    # 1. Yosys -> pure SKY130 netlist (skip if reusing existing mapped.v)
    mapped = out / "mapped.v"
    errors = []
    if args.skip_mapping and mapped.exists():
        print(f"{args.circuit}: reusing existing mapped.v (skip mapping)")
    else:
        yosys_cmd = (["wsl.exe", "-d", "Ubuntu", "--", "/usr/bin/yosys"]
                     if args.yosys_wsl else None)
        errors = run_yosys_mapping(circuit_path, out, yosys_cmd=yosys_cmd)
    if errors or not mapped.exists():
        print(f"{args.circuit}: mapping failed", file=sys.stderr)
        return 1
    mapped_text = mapped.read_text(encoding="utf-8")
    single = strip_to_single_module(mapped_text, args.circuit)

    # 2. baseline OpenSTA (single worst path -> parse critical instances)
    base = run_opensta(mapped, args.period, out, top_module=args.circuit,
                       hold_uncertainty=args.hold_uncertainty if args.hold_mode else 0.0,
                       clock_port=args.clock_port, multi_path=True)
    baseline_wns = base["wns"]
    if baseline_wns is None:
        print(f"{args.circuit}: baseline OpenSTA returned no WNS", file=sys.stderr)
        return 1
    baseline_min_slack = base.get("min_slack")
    if args.hold_mode and baseline_min_slack is None:
        print(f"{args.circuit}: hold mode needs worst slack min from OpenSTA "
              "(got None)", file=sys.stderr)
        return 1
    sta_text = (out / "sta.log").read_text(encoding="utf-8", errors="replace")
    critical = parse_critical_instances(sta_text)
    endpoint = parse_worst_endpoint(sta_text)
    target_net = dff_d_input_net(single, endpoint) if endpoint else None
    if not critical or target_net is None:
        print(f"{args.circuit}: no critical instances / endpoint D net "
              f"(endpoint={endpoint})", file=sys.stderr)
        return 1
    print(f"baseline: wns={baseline_wns} min_slack={baseline_min_slack} "
          f"endpoint={endpoint} D={target_net}")
    print(f"critical path: {critical}")

    # 3. build the FAECO case from the mapped netlist (analysis domain:
    #    single-module version; original == resynthesized placeholder, the
    #    real success criterion is WNS, not logic-level reduction)
    case_dir = out / "case"
    (case_dir / "original").mkdir(parents=True, exist_ok=True)
    (case_dir / "resynthesized").mkdir(parents=True, exist_ok=True)
    (case_dir / "original" / "original.v").write_text(single, encoding="utf-8")
    (case_dir / "resynthesized" / "resynthesized.v").write_text(single, encoding="utf-8")
    (case_dir / "case.yaml").write_text(
        "case_id: " + args.circuit + "_real_wns\n"
        "target:\n"
        "  output: " + target_net + "\n",
        encoding="utf-8",
    )

    # 4. real-STA evaluator (decision layer: optional strategy priority table)
    priority_table = None
    if args.priority_table is not None:
        priority_table = json.loads(args.priority_table.read_text(encoding="utf-8"))
    evaluator = RealWnsEvaluator(
        mapped_text=mapped_text,
        top_module=args.circuit,
        period=args.period,
        liberty_text=LIB.read_text(encoding="utf-8"),
        baseline_wns=baseline_wns,
        baseline_tns=base.get("tns"),
        output_dir=out / "eval",
        critical_instances=critical,
        workers=args.workers,
        enable_buffer=args.enable_buffer,
        tns_aware=args.tns_aware,
        max_instances=args.max_instances,
        priority_table=priority_table,
        proxy_ranking=args.proxy_ranking,
        adaptive=args.adaptive,
        hold_mode=args.hold_mode,
        baseline_min_slack=baseline_min_slack,
        hold_uncertainty=args.hold_uncertainty,
        early_stop=args.early_stop,
        joint_k=args.joint_k,
        joint_enumerate_depth=args.joint_enumerate_depth,
        strategy_filter=tuple(s.strip() for s in args.strategies.split(',') if s.strip()),
        init_boundary_penalty=args.init_boundary_penalty,
        init_size_penalty=args.init_size_penalty,
        init_critical_coverage_reward=args.init_critical_coverage_reward,
        init_verification_cost_penalty=args.init_verification_cost_penalty,
        init_equivalence_stability_reward=args.init_equivalence_stability_reward,
        cut_search_policy=args.cut_search_policy,
        cut_sources=args.cut_sources,
        node_cost_mode=args.node_cost_mode,
        enable_topology=not args.disable_topology,
        clock_port=args.clock_port,
        physical_gate=args.physical_gate,
        min_physical_gain_ns=args.min_physical_gain,
        physical_fanout_penalty=args.physical_fanout_penalty,
        physical_depth_penalty=args.physical_depth_penalty,
        physical_unit_len_um=args.physical_unit_len,
        strict_gates=True,
        strict_budgets=True,
        required_metrics=tuple(m.strip() for m in args.required_metrics.split(",") if m.strip()),
        epsilon=args.epsilon,
        equivalence_checker=build_real_equivalence_checker(LIB.read_text(encoding="utf-8"),top_module=args.circuit),
        topology_sec_checker=build_full_netlist_sec_checker(
            top_module=args.circuit,
            liberty_text=LIB.read_text(encoding="utf-8"),
            artifact_dir=out / "topology-sec",
        ),
        boundary_checker=build_boundary_closure_checker(
            top_module=args.circuit, liberty_text=LIB.read_text(encoding="utf-8")),
        capture_electrical=args.capture_electrical,
    )

    # 5. outer loop.  Candidate-level equivalence is intentionally fail
    # closed when no functional checker is configured; timing gain alone is
    # never presented as proof of correctness.
    # Joint bi-objective cut: pass which critical-path gates have an R
    # equivalence candidate so the cut graph applies the hard equivalence
    # constraint and the critical-path cover is a first-round default.
    r_available = build_r_available(
        LIB.read_text(encoding="utf-8"), critical, strip_to_single_module(mapped_text,args.circuit)
    )
    result = run_multi_iteration_case(
        case_dir,
        max_iterations=args.max_iterations,
        enable_feedback=enable_feedback,
        wns_evaluator=evaluator,
        candidates_per_iteration=args.candidates_per_iteration,
        critical_instances=critical,
        r_available=r_available,
        init_weights={
            "boundary_penalty": args.init_boundary_penalty,
            "size_penalty": args.init_size_penalty,
            "critical_coverage_reward": args.init_critical_coverage_reward,
            "verification_cost_penalty": args.init_verification_cost_penalty,
            "equivalence_stability_reward": args.init_equivalence_stability_reward,
        },
        epsilon=args.epsilon,
        max_patches=args.max_patches,
        sta_budget=args.sta_budget,
        formal_budget=args.formal_budget,
        wall_timeout_s=args.wall_timeout_s,
        feedback_config=feedback_config,
        random_order=args.random_order,
        seed=args.seed,
        structure_resynth=args.structure_resynth,
        resynth_per_iteration=args.resynth_per_iteration,
        resynth_window_pool=args.resynth_window_pool,
        resynth_variants=tuple(
            v.strip() for v in args.resynth_variants.split(",") if v.strip()
        ),
        resynth_lib_path=LIB,
        structure_out_dir=args.structure_out_dir,
    )
    result["circuit"] = args.circuit
    result["period_ns"] = args.period
    result["baseline_wns"] = baseline_wns
    result["baseline_min_slack"] = baseline_min_slack
    result["hold_mode"] = args.hold_mode
    # L2 three-arm identity (explicit at top level; also carried by the
    # refinement-loop result via _extras() when it produced the trace fields)
    result["enable_feedback"] = enable_feedback
    result["feedback_config"] = (None if feedback_config is None
                                 else asdict(feedback_config))
    result["random_order"] = args.random_order
    result["seed"] = args.seed if args.random_order else None
    result["strategies"] = [s.strip() for s in args.strategies.split(',') if s.strip()]
    result["joint_enumerate_depth"] = args.joint_enumerate_depth
    result["init_weights"] = {
        "boundary_penalty": args.init_boundary_penalty,
        "size_penalty": args.init_size_penalty,
        "critical_coverage_reward": args.init_critical_coverage_reward,
        "verification_cost_penalty": args.init_verification_cost_penalty,
        "equivalence_stability_reward": args.init_equivalence_stability_reward,
    }
    result["cut_search_policy"] = args.cut_search_policy
    result["cut_sources"] = args.cut_sources
    result["node_cost_mode"] = args.node_cost_mode
    result["enable_topology"] = not args.disable_topology
    result["hold_uncertainty_ns"] = args.hold_uncertainty if args.hold_mode else None
    result["min_physical_gain_ns"] = args.min_physical_gain
    result["critical_instances"] = critical
    result["proxy_ranking"] = args.proxy_ranking
    result["endpoint"] = endpoint
    result["target_net"] = target_net
    result["n_candidate_sta_runs"] = len(evaluator.trials)
    result['n_candidate_sta_runs_semantics'] = 'legacy_candidate_evaluation_record_count'
    result['n_new_sta_runs'] = len(getattr(evaluator, 'sta_launch_events', []))
    result['n_candidate_evaluation_records'] = len(evaluator.trials)
    if hasattr(result.get("weights"), "__dataclass_fields__"):
        result["weights"] = asdict(result["weights"])
    (out / "outerloop_result.json").write_text(
        json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    evaluator.write_trials(out / "eval_trials.json")

    # OI-012 remediation: archive the full run configuration so every batch
    # is reproducible without reverse-engineering CLI flags from logs.
    def _git_head() -> str | None:
        try:
            return subprocess.run(
                ["git", "rev-parse", "HEAD"], cwd=str(ROOT),
                capture_output=True, text=True, check=True,
            ).stdout.strip()
        except Exception:
            return None

    run_config = {
        "argv": sys.argv,
        "resolved_args": {k: str(v) if isinstance(v, Path) else v
                          for k, v in vars(args).items()},
        "git_head": _git_head(),
        "circuit_path": str(circuit_path),
        "liberty": str(LIB),
        "enable_feedback": enable_feedback,
        "feedback_config_name": args.feedback_config_name,
        "feedback_config": (None if feedback_config is None
                            else asdict(feedback_config)),
        "random_order": args.random_order,
        "seed": args.seed if args.random_order else None,
        "adaptive_ucb_decision_layer": args.adaptive,
        # L3 S (r2 §4.9) — archived so the {S on, S off} batch is reproducible
        # from run_config.json alone (same discipline as the L2 arms).
        "structure_resynth": args.structure_resynth,
        "resynth_per_iteration": args.resynth_per_iteration,
        "resynth_window_pool": args.resynth_window_pool,
        "resynth_variants": [v.strip() for v in args.resynth_variants.split(",")
                             if v.strip()],
        "structure_resynth_stats": result.get("structure_resynth"),
        # Phase 3-A collection flag, archived with the electrical baseline so a
        # captured batch is self-describing.
        "capture_electrical": args.capture_electrical,
        "electrical_baseline": (
            getattr(evaluator, "electrical_baseline", None)
            if args.capture_electrical else None
        ),
    }
    (out / "run_config.json").write_text(
        json.dumps(run_config, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    print(f"outer loop: success={result['success']} iterations={result['iterations']}")
    print(f"wns_history={result.get('wns_history')}")
    if args.structure_resynth:
        s = result.get("structure_resynth") or {}
        print(f"S: windows_offered={s.get('windows_offered')} "
              f"extracted={s.get('windows_extracted')} "
              f"candidates={s.get('candidates')} measured={s.get('measured')} "
              f"accepted={s.get('accepted')} "
              f"rejections={len(s.get('rejections') or [])}")
    if result["success"]:
        print(f"accepted patch: {result['final_patch_id']} at wns="
              f"{result['history'][-1].get('wns')}")
    else:
        print("no candidate improved WNS; see outerloop_result.json for the "
              "refined weights / failure history")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

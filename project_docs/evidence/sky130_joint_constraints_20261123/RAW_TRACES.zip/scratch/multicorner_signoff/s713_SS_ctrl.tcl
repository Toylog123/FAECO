read_liberty /home/toylog/faeco_eda/build26/OpenROAD-src/test/sky130hd/sky130_fd_sc_hd__ss_n40C_1v40.lib
read_verilog /mnt/d/BaiduSyncdisk/01_Papers/03_FAECO/scratch/iscas89_postroute_verify/s713/CONTROL/routed.v
link_design s713
create_clock -name clk -period 0.5 [get_ports CK]
read_spef /mnt/d/BaiduSyncdisk/01_Papers/03_FAECO/scratch/iscas89_postroute_verify/s713/CONTROL/routed.spef
set_propagated_clock [all_clocks]
puts "ROUTED_WNS_MAX [sta::worst_slack_cmd max]"
puts "ROUTED_WNS_MIN [sta::worst_slack_cmd min]"
report_tns -digits 6
exit

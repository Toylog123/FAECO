read_liberty /home/toylog/faeco_eda/build26/OpenROAD-src/test/sky130hd/sky130_fd_sc_hd__tt_025C_1v80.lib
read_verilog /mnt/d/BaiduSyncdisk/01_Papers/03_FAECO/experiments/20261113_itc99_recovery/arms/Resizer/b04/routed.v
link_design b04
create_clock -name clk -period 0.5 [get_ports CK]
read_spef /mnt/d/BaiduSyncdisk/01_Papers/03_FAECO/experiments/20261113_itc99_recovery/arms/Resizer/b04/routed.spef
set_propagated_clock [all_clocks]
puts "===NOMINAL_POWER==="
report_power
set data_ins {}
foreach p [all_inputs] {
    if {[get_name $p] ne "CK"} { lappend data_ins $p }
}
set_input_delay 0.10 -clock clk $data_ins
set_output_delay 0.10 -clock clk [all_outputs]
set_load 0.01 [all_outputs]
set_input_transition 0.05 $data_ins
set_timing_derate -early 0.90
set_timing_derate -late 1.10
puts "ROUTED_WNS_MAX [sta::worst_slack_cmd max]"
puts "ROUTED_WNS_MIN [sta::worst_slack_cmd min]"
report_tns -digits 6
exit

\
set PLATFORM "/home/toylog/OpenROAD-flow-scripts/flow/platforms/sky130hd"
set NETLIST  "/mnt/d/BaiduSyncdisk/01_Papers/03_FAECO/scratch/tool_agnostic_iscas89/s420/evals/RUN_010/routed.v"
set SPEF     "/mnt/d/BaiduSyncdisk/01_Papers/03_FAECO/scratch/tool_agnostic_iscas89/s420/evals/RUN_010/routed.spef"
set TOP      s420
set PERIOD   0.5
set CLK_PORT CK

read_liberty $PLATFORM/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
read_verilog $NETLIST
link_design $TOP
create_clock -name clk -period $PERIOD [get_ports $CLK_PORT]
read_spef $SPEF
set_propagated_clock [all_clocks]

# sta::worst_slack_cmd returns SECONDS; report_tns reports NANOseconds.
puts "ROUTED_WNS_MAX [sta::worst_slack_cmd max]"
puts "ROUTED_WNS_MIN [sta::worst_slack_cmd min]"
puts "ROUTED_TNS_BEGIN"
report_tns
puts "ROUTED_TNS_END"
puts "ROUTED_STA_OK"

report_check_types -max_slew -max_capacitance -violators -digits 6

read_liberty /home/toylog/OpenROAD-flow-scripts/flow/platforms/sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
read_lef /home/toylog/OpenROAD-flow-scripts/flow/platforms/sky130hd/lef/sky130_fd_sc_hd.tlef
read_lef /home/toylog/OpenROAD-flow-scripts/flow/platforms/sky130hd/lef/sky130_fd_sc_hd_merged.lef
read_def /mnt/d/BaiduSyncdisk/01_Papers/03_FAECO/experiments/20261115_p1_resizer_vs_faeco/arms/Resizer/s832/routed.def
create_clock -name clk -period 0.5 [get_ports CK]
set_propagated_clock [all_clocks]
source /mnt/d/BaiduSyncdisk/01_Papers/03_FAECO/data/raw/benchmarks/raw/openroad_flow_scripts_sky130hd/da8f092a02a8e75658cc3100691aabff05f35629/setRC.tcl
read_spef /mnt/d/BaiduSyncdisk/01_Papers/03_FAECO/experiments/20261115_p1_resizer_vs_faeco/arms/Resizer/s832/routed.spef
replace_cell {_147_} {sky130_fd_sc_hd__or3_1}
replace_cell {_252_} {sky130_fd_sc_hd__nor4b_1}

detailed_placement
check_placement -verbose
set_routing_layers -signal met1-met5 -clock met3-met5
foreach net [[ord::get_db_block] getNets] {
    if {[$net getSigType] in {POWER GROUND}} { continue }
    set wire [$net getWire]
    if {$wire ne "NULL"} { odb::dbWire_destroy $wire }
}
pin_access
global_route
detailed_route -output_drc /mnt/d/BaiduSyncdisk/01_Papers/03_FAECO/scratch/tool_agnostic_iscas89/s832/evals/RUN_009/drc.rpt -verbose 0 -droute_end_iter 15
write_verilog /mnt/d/BaiduSyncdisk/01_Papers/03_FAECO/scratch/tool_agnostic_iscas89/s832/evals/RUN_009/routed.v
define_process_corner -ext_model_index 0 X
extract_parasitics -ext_model_file /mnt/d/BaiduSyncdisk/01_Papers/03_FAECO/data/raw/benchmarks/raw/openroad_flow_scripts_sky130hd/da8f092a02a8e75658cc3100691aabff05f35629/rcx/rcx_patterns.rules
write_spef /mnt/d/BaiduSyncdisk/01_Papers/03_FAECO/scratch/tool_agnostic_iscas89/s832/evals/RUN_009/routed.spef
puts "PHYSICAL_OK"
exit

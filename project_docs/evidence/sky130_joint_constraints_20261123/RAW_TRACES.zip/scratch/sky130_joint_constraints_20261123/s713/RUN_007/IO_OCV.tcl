\
set PLATFORM "/home/toylog/OpenROAD-flow-scripts/flow/platforms/sky130hd"
set NETLIST  "/mnt/d/BaiduSyncdisk/01_Papers/03_FAECO/scratch/sky130_joint_constraints_20261123/s713/RUN_007/routed.v"
set SPEF     "/mnt/d/BaiduSyncdisk/01_Papers/03_FAECO/scratch/sky130_joint_constraints_20261123/s713/RUN_007/routed.spef"
set TOP      s713
set PERIOD   0.5
set CLK_PORT CK

read_liberty /home/toylog/faeco_eda/build26/OpenROAD-src/test/sky130hd/sky130_fd_sc_hd__tt_025C_1v80.lib
read_verilog $NETLIST
link_design $TOP
create_clock -name clk -period $PERIOD [get_ports $CLK_PORT]
read_spef $SPEF
set_propagated_clock [all_clocks]
foreach p [all_inputs] {
    if {[get_name $p] ne "CK"} {
        set_input_delay 0.10 -clock clk $p
        set_input_transition 0.05 $p
    }
}
set_output_delay 0.10 -clock clk [all_outputs]
set_load 0.01 [all_outputs]
set_timing_derate -early 0.90
set_timing_derate -late 1.10

# sta::worst_slack_cmd returns SECONDS; report_tns reports NANOseconds.
puts "ROUTED_WNS_MAX [sta::worst_slack_cmd max]"
puts "ROUTED_WNS_MIN [sta::worst_slack_cmd min]"
puts "ROUTED_TNS_BEGIN"
report_tns -digits 6
puts "ROUTED_TNS_END"
puts "ROUTED_STA_OK"

report_check_types -max_slew -max_capacitance -violators -digits 6

report_checks -path_delay min -format full_clock_expanded -digits 6
puts JOINT_STA_COMPLETE
exit

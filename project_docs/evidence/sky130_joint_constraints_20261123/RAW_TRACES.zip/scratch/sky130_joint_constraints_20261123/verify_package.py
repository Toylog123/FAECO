from pathlib import Path
import hashlib
import json
import math
from zipfile import ZipFile, ZIP_DEFLATED

root = Path.cwd()
evidence = root / 'project_docs/evidence/sky130_joint_constraints_20261123'
scratch = root / 'scratch/sky130_joint_constraints_20261123'
modes = ('TT','SS','FF','IO_OCV')

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def refs(x):
    if isinstance(x, dict):
        if {'path','sha256','bytes'} <= x.keys():
            yield x
        for value in x.values():
            yield from refs(value)
    elif isinstance(x, list):
        for value in x:
            yield from refs(value)

historic = {x['path']: x for x in refs(read(evidence/'ENDPOINTS.json'))}
assert len(historic) == 357
for name, entry in historic.items():
    path = root/name
    assert path.stat().st_size == entry['bytes'] and sha(path) == entry['sha256'], name

full = {}
phases = {}
for label in ('s713','s713_retry','s713_replay','s832'):
    base = scratch/label
    summary, config = read(base/'summary.json'), read(base/'config.json')
    candidates = summary['evaluations']
    all_rows = [summary['no_change'], *candidates]
    phases[label] = {
        'openroad_attempts': summary['physical_route_count'],
        'openroad_completed': sum(row['route_ok'] and not row.get('reused_route') for row in all_rows),
        'route_reuses': summary.get('reused_route_count', 0),
        'gate_eligible_routed_candidates': sum(row['physical_ok'] for row in candidates),
        'sta_calls': 8 + sum(len(row['metrics']) for row in all_rows),
        'sec_calls': len(summary['sec']),
    }
    for name, digest in config['control_sha256'].items():
        assert sha(root/config['control']/name)==digest
    for row in all_rows:
        assert row == read(base/row['endpoint']/'metrics.json')
        for name, digest in row['routed_sha256'].items():
            assert sha(base/row['endpoint']/name)==digest, (label, row['endpoint'], name)
        if row.get('reused_route'):
            origin = read(scratch/row['reused_route']/'metrics.json')
            assert origin['action_ids'] == row['action_ids']
            assert origin['routed_sha256'] == row['routed_sha256']
        if label not in ('s713_replay','s832') or row['endpoint']=='NO_CHANGE':
            continue
        assert row['route_returncode']==0 and row['drc_count']==0 and row['physical_ok']
        assert row['area_saved'] > 0 and list(row['metrics'])==list(modes)
        expect, relative = [], []
        for mode, measurement in row['metrics'].items():
            assert measurement['valid'] and measurement['returncode']==0
            control=summary['control_metrics'][mode]
            check = []
            if measurement['setup_ns'] - control['setup_ns'] < -0.010001: check.append(f'{mode}:setup_budget')
            if measurement['hold_ns'] - control['hold_ns'] < -0.000001: check.append(f'{mode}:hold_regression')
            expect.extend(check)
            relative.extend(check)
            if measurement['hold_ns'] < 0:
                expect.append(f'{mode}:negative_hold')
                if mode!='IO_OCV': relative.append(f'{mode}:negative_hold')
            for metric in ('setup_ns','hold_ns','tns_ns'):
                assert math.isclose(row['deltas_ps'][mode][metric], 1000*(measurement[metric]-control[metric]), abs_tol=1e-8)
        assert expect==row['strict_reasons'] and relative==row['relative_io_hold_reasons']
    if label in ('s713_replay','s832'):
        assert len(candidates)==10 and len({tuple(x['action_ids']) for x in candidates})==10
        assert summary['no_change']['physical_ok'] and abs(summary['no_change']['area_saved'])<1e-6
        assert all(row['metrics']['IO_OCV']['hold_ns']<0 for row in candidates)
        assert summary['selected_strict'] is None
        chosen = summary['selected_relative_io_hold_diagnostic']
        if chosen is not None:
            proof=summary['sec'][chosen]
            selected=next(row for row in candidates if row['endpoint']==chosen)
            assert not selected['relative_io_hold_reasons']
            assert proof['accepted'] and proof['equiv_proven']>0 and proof['equiv_unproven']==0
            assert proof['gold_routed_sha256']==config['control_sha256']['routed.v']
            assert proof['gate_routed_sha256']==selected['routed_sha256']['routed.v']
            assert 'Equivalence successfully proven!' in (base/chosen/'SEC/sec.log').read_text(encoding='utf8')
        full[summary['circuit']] = {"directory": base.relative_to(root).as_posix(), "summary": summary}

assert full['s713']['summary']['selected_relative_io_hold_diagnostic'] is None
assert full['s832']['summary']['selected_relative_io_hold_diagnostic']=='RUN_005'
totals = {key: sum(val[key] for val in phases.values()) for key in phases['s832']}
bundle={'policy':'same CONTROL V/SPEF; TT/SS/FF and TT+IO+OCV; <=10.001 ps setup loss in each, hold nonnegative and <=0.001 ps regression, positive area, DRC0 and nonempty 2-state SEC', 'primary_cases': full, 'phase_counts': phases, 'phase_totals': totals, 'historical_source_files_verified': len(historic)}
(evidence/'SUMMARY.json').write_text(json.dumps(bundle, indent=2, ensure_ascii=False)+'\n',encoding='utf8')

archive = evidence/'RAW_TRACES.zip'
trace_paths = {p.relative_to(root).as_posix() for p in scratch.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
archive_names = sorted(set(historic)|trace_paths)
with ZipFile(archive,'w',compression=ZIP_DEFLATED,compresslevel=5) as out:
    for name in archive_names:
        out.write(root/name,name)
with ZipFile(archive) as out:
    assert len(out.namelist())==len(archive_names)
    assert out.testzip() is None
    for name, entry in historic.items():
        assert hashlib.sha256(out.read(name)).hexdigest()==entry['sha256'], name
print('Verified 20 distinct candidates across 2 designs, 357 historical source digests and',len(archive_names),'archived files;',totals,'archive_bytes=',archive.stat().st_size)


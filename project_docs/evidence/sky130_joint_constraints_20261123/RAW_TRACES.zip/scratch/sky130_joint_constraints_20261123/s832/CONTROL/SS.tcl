\
set PLATFORM "/home/toylog/OpenROAD-flow-scripts/flow/platforms/sky130hd"
set NETLIST  "/mnt/d/BaiduSyncdisk/01_Papers/03_FAECO/experiments/20261115_p1_resizer_vs_faeco/arms/Resizer/s832/routed.v"
set SPEF     "/mnt/d/BaiduSyncdisk/01_Papers/03_FAECO/experiments/20261115_p1_resizer_vs_faeco/arms/Resizer/s832/routed.spef"
set TOP      s832
set PERIOD   0.5
set CLK_PORT CK

read_liberty /home/toylog/faeco_eda/build26/OpenROAD-src/test/sky130hd/sky130_fd_sc_hd__ss_n40C_1v40.lib
read_verilog $NETLIST
link_design $TOP
create_clock -name clk -period $PERIOD [get_ports $CLK_PORT]
read_spef $SPEF
set_propagated_clock [all_clocks]

# sta::worst_slack_cmd returns SECONDS; report_tns reports NANOseconds.
puts "ROUTED_WNS_MAX [sta::worst_slack_cmd max]"
puts "ROUTED_WNS_MIN [sta::worst_slack_cmd min]"
puts "ROUTED_TNS_BEGIN"
report_tns -digits 6
puts "ROUTED_TNS_END"
puts "ROUTED_STA_OK"

report_check_types -max_slew -max_capacitance -violators -digits 6

report_checks -path_delay min -format full_clock_expanded -digits 6
puts JOINT_STA_COMPLETE
exit

read_liberty /mnt/d/BaiduSyncdisk/01_Papers/03_FAECO/data/raw/benchmarks/raw/openroad_flow_scripts_sky130hd/da8f092a02a8e75658cc3100691aabff05f35629/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
read_verilog /mnt/d/BaiduSyncdisk/01_Papers/03_FAECO/experiments/20261014_r22_cut_ablation/W0/s27/eval/iter002_cand002/005__11__B/mapped.v
link_design s27
create_clock -name clk -period 0.5 [get_ports CK]
report_checks -path_delay max
report_checks -path_delay max -slack_max 0 -endpoint_count 100000
puts "TNS_BEGIN"
report_tns
puts "TNS_END"
report_worst_slack -max
report_worst_slack -min

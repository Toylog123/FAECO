read_db "/home/toylog/faeco_tcad_sky_holdout_20261123/gcd_geometry_release_20261127_v1/cell_01/online/01/retry/routed.odb"
read_def -floorplan_initialize "/home/toylog/faeco_tcad_sky_holdout_20261123/gcd_geometry_release_20261127_v1/cell_01/online/01/retry/unlocked_drc/normalized_nets.def"
write_def "/home/toylog/faeco_tcad_sky_holdout_20261123/gcd_geometry_release_20261127_v1/cell_01/online/01/retry/unlocked_drc/normalized_geometry.def"
if {![design_is_routed]} { error "Unrouted signal nets" }
drt::check_drc -output_file "/home/toylog/faeco_tcad_sky_holdout_20261123/gcd_geometry_release_20261127_v1/cell_01/online/01/retry/unlocked_drc/full_drc.rpt"
puts AES_UNLOCKED_DRC_COMPLETE
exit

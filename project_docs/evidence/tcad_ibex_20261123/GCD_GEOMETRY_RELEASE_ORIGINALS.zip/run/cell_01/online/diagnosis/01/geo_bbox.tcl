read_db "/home/toylog/faeco_tcad_sky_holdout_20261123/gcd/results/sky130hd/gcd/base/6_final.odb"
set block [ord::get_db_block]
puts "DBU [$block getDbUnitsPerMicron]"
foreach name {_092_ _093_ _094_} {
  set inst [$block findInst $name]
  if { $inst eq "NULL" } { continue }
  set bb [$inst getBBox]
  puts "INST $name [$bb xMin] [$bb yMin] [$bb xMax] [$bb yMax]"
}
puts FAECO_GEO_BBOX_DONE
exit

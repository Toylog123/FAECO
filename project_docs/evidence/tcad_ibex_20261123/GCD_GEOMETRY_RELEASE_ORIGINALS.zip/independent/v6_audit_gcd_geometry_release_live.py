#!/usr/bin/env python3
"""Recompute the completed GCD geometry plus marker-retry experiment from live originals."""

import argparse
from collections import Counter
from hashlib import sha256
import json
import math
from pathlib import Path
import re
import sys


HERE = Path(__file__).resolve().parent
REPO = next(path for path in (HERE, *HERE.parents) if (path / "project_docs/evidence/tcad_ibex_20261123").is_dir())
sys.path.insert(0, str(REPO / "project_docs/evidence/tcad_ibex_20261123"))

import v6_verify_gcd_geometry_release as rank
import v6_verify_gcd_same_proposal as shared


PRIOR_RESULTS_SHA = "02b44e2774fe87ae93eae269842817bb92a5fdeca7a330a35d8a125f416d106d"
ORACLE_TCL_SHA = "1ff36d934b33e27887720b58a6f40a0cb8147b488cab968fc65b7527fb36ea90"


def actual_tool_order(arm, request, window, protocol, geometry, assets):
    tools = shared.read(arm / "subprocesses.json")
    start, deadline = window["start_raw"], window["deadline_raw"]
    admitted = request["admitted_raw"]
    shared.check(start <= admitted <= geometry["start_raw"] <= geometry["stop_raw"] < deadline
                 and math.isclose(deadline - start + protocol["charged_screening_seconds"], 720,
                                  rel_tol=0, abs_tol=1e-7)
                 and geometry["seconds"] == geometry["stop_raw"] - geometry["start_raw"], "geometry timing window")
    last = admitted
    stage_counts = Counter()
    stage_seconds = Counter()
    for row in tools:
        log = Path(row["log"])
        stage = log.relative_to(arm).parts[0]
        shared.check(stage in ("01", "diagnosis") and last <= row["start_raw"] < deadline
                     and row["start_raw"] <= row["stop_raw"]
                     and math.isclose(row["effective_timeout_seconds"],
                                      min(deadline - row["start_raw"], row["configured_timeout_seconds"]),
                                      rel_tol=0, abs_tol=1e-7), "geometry subprocess ordering or limit")
        stage_counts[log.name] += 1
        stage_seconds[log.name] += row["wall_seconds"]
        last = row["stop_raw"]
    probe, *physical = tools
    tcl = arm / "diagnosis/01/geo_bbox.tcl"
    expected = [str(shared.verify(assets["tools"]["openroad"])), "-no_init", "-no_splash", "-threads", "1", "-exit",
                str(tcl)]
    shared.check(probe["command"] == expected and probe["log"] == str(tcl.with_suffix(".log"))
                 and probe["configured_timeout_seconds"] == 60 and probe["returncode"] == 0
                 and geometry["start_raw"] <= probe["start_raw"] <= probe["stop_raw"] <= geometry["stop_raw"]
                 and (not physical or geometry["stop_raw"] <= physical[0]["start_raw"])
                 and all(Path(tool["log"]).is_relative_to(arm / "01") for tool in physical),
                 "geometry extraction did not precede the protected physical pass")
    return physical, last, dict(stage_counts), dict(stage_seconds)


def raw_pass(trial, protocol, assets, reference, areas, masters, cold_scope):
    artifact = trial / "receipt.json"
    if not artifact.exists():
        return {"completed": False}
    receipt = shared.read(artifact)
    if not (receipt["routed_to_completion"] and receipt["extracted_to_completion"]
            and set(receipt["views"]) == set(shared.cmp.CORNERS) and "routing_audit" in cold_scope):
        return {"completed": False, "receipt": shared.cmp.bind(artifact), "physical_failures": receipt["failures"]}
    physical = shared.audit_pass(trial, protocol, assets, reference, areas, masters, shared.ACTIONS,
                                 shared.read(shared.verify(cold_scope["routing_audit"])))
    program = shared.normalized_tcl(trial / "route.tcl", trial)
    reads = re.findall(r"(?m)^(read_db|read_def|read_sdc) (.+)$", program)
    shared.check(reads == [("read_db", shared.cmp.tcl(shared.verify(assets["control"]["odb"]))),
                           ("read_def", '-floorplan_initialize "<OUTPUT>/fixed_wires.def"'),
                           ("read_sdc", shared.cmp.tcl(shared.verify(assets["control"]["sdc"])))],
                 (trial, "pass did not restart from frozen CONTROL"))
    scope = shared.read(trial / "routing_scope.json")
    physical.update(touched_nets=scope["expected_touched_nets"], fixed_nets=len(scope["fixed_nets"]),
                    fixed_wire_patch=scope["fixed_wire_patch"], released_neighbors=cold_scope["released"],
                    receipt=shared.cmp.bind(artifact),
                    markers_located_in_diagnosis_windows=shared.locate_late_markers(
                        physical["drc_markers"], shared.reconstruct_geometry(protocol)))
    return physical


def audited_arm(root, protocol, geometry, inputs):
    assets, _, reference, nets, edited, incident, areas, masters, _ = inputs
    rows = shared.read(root / "results.json")
    item, = rows
    shared.check((item["cell"], item["method"], item["diagnosis_mode"]) == (1, "online", "geometry"),
                 "wrong or incomplete fixed-proposal geometry experiment")
    zero_dir = root / "preflight/zero"
    gate = protocol["gate"]
    zero_row, zero = shared.audit_logical(zero_dir, nets, assets["control"], reference, gate)
    zero_proof = shared.read(zero_dir / "initial/sec/receipt.json")
    shared.check(zero.valid and zero.sec_pass and zero_row["actions"] == []
                 and (zero_proof["proven"], zero_proof["unproven"]) == (262, 0)
                 and b"262 are proven and 0 are unproven" in shared.verify(zero_proof["log"]).read_bytes(),
                 "shared strict-zero reference qualifications")
    arm = root / "cell_01/online"
    directory = arm / "01"
    summary, progress = [shared.read(arm / f"{name}.json") for name in ("summary", "progress")]
    request, = progress["logical_requests"]
    checkpoints = progress["checkpoints"]
    shared.check(summary == item["result"] and item["outer_start_raw"] <= progress["start_raw"]
                 <= summary["stop_raw"] <= item["outer_stop_raw"] and request["id"] == summary["logical_admitted"] == 1
                 and request["actions"] == shared.ACTIONS and summary["logical_finished"] == len(checkpoints) <= 1,
                 "geometry arm did not retain the common proposal or wall budget")
    physical_tools, last, counts, wall = actual_tool_order(arm, request, progress, protocol, geometry, assets)
    initial = {geometry["selected"]}
    scopes = shared.cold.audit_physical(directory, request, physical_tools, edited, incident, initial, nets)
    passes = {phase: raw_pass(directory / phase, protocol, assets, reference, areas, masters, scope)
              for phase, scope in scopes.items()}
    actual_initial = shared.read(directory / "initial/routing_scope.json") if "initial" in passes else None
    if actual_initial is not None:
        shared.check(set(actual_initial["expected_touched_nets"]) == incident | initial
                     and {"clk", "clknet_0_clk"} <= set(actual_initial["fixed_nets"])
                     and len(actual_initial["fixed_nets"]) == 475 and actual_initial["released_neighbors"] == sorted(initial),
                     "one-net geometry intervention changed protected scope")
    added = set()
    retry = directory / "retry_decision.json"
    if retry.exists():
        recorded = shared.read(retry)
        first = directory / "initial"
        reports = tuple(first / name for name in ("drc.rpt", "full_drc.rpt", "unlocked_drc/full_drc.rpt"))
        added, marker_evidence = shared.drc_neighbor_evidence(reports, incident | initial, edited, nets)
        shared.check(recorded["released_neighbors"] == sorted(added) and marker_evidence == recorded["drc_marker_evidence"],
                     "geometry retry depended on something other than the current raw markers")
    if "retry" in scopes:
        shared.check(added and added.isdisjoint(incident | initial)
                     and set(scopes["retry"]["released"]) == initial | added, "retry lost the initial release or duplicated it")
    output = {"zero_proof": [262, 0], "zero_area_um2": zero.area, "admitted": 1, "finished": len(checkpoints),
              "initial_release": sorted(initial), "additional_retry_release": sorted(added), "passes": passes,
              "stage_attempts": counts, "stage_wall_seconds": wall, "charged_screening_seconds": protocol["charged_screening_seconds"],
              "stop_reason": summary["stop_reason"], "area_saved_um2": summary["window"]["area_saved"],
              "actual_wall_timeouts": [{"log": row["log"], "effective_s": row["effective_timeout_seconds"]}
                                       for row in physical_tools if row["returncode"] is None
                                       and row["timeout_bound"] == "wall"]}
    if not checkpoints:
        shared.check("finished_raw" not in request and not output["area_saved_um2"]
                     and summary["stop_reason"] == "end_to_end_wall_cap", "unfinished outcome misclassified")
        return output
    result, end = (shared.audit_guided_retry(directory, assets["control"], reference, gate) if "retry" in scopes
                   else shared.audit_logical(directory, nets, assets["control"], reference, gate))
    final = passes[result["passes"][-1]]
    failures = list(final.get("failures", result["failures"]))
    if "sec" in result["failures"] and "sec" not in failures:
        shared.check(counts.get("sec.log", 0) == 1 and not failures, "SEC launched for a failed physical gate")
        failures.append("sec")
    if shared.DRC_REASONS.intersection(failures):
        failures = [failure for failure in failures if failure not in shared.RELATIVE_HOLD_REASONS]
    checkpoint, = checkpoints
    shared.check(Counter(failures) == Counter(result["failures"]) == Counter(request["failures"])
                 and checkpoint["endpoint"] == result["endpoint"] and last <= request["finished_raw"] < progress["deadline_raw"]
                 and math.isclose(checkpoint["elapsed_seconds"], request["finished_raw"] - progress["start_raw"]
                                  + protocol["charged_screening_seconds"], rel_tol=0, abs_tol=1e-7),
                 "geometry result, gate reasons, or accepted checkpoint time changed")
    policy = shared.cmp.BudgetPolicy.from_ps(gate["budget_ps"], tolerance_ns=shared.cmp.PS_TOLERANCE / 1000)
    accepted = shared.cmp.assess(zero, end, policy).feasible and end.area < zero.area - 1e-9
    shared.check(checkpoint["accepted"] == accepted and output["area_saved_um2"] == (zero.area - end.area if accepted else 0),
                 "the geometry arm's deliverable cannot be reconstructed")
    proof_counts = None
    if accepted:
        receipt = shared.read(directory / result["passes"][-1] / "sec/receipt.json")
        shared.check((receipt["proven"], receipt["unproven"]) == (262, 0)
                     and b"262 are proven and 0 are unproven" in shared.verify(receipt["log"]).read_bytes(),
                     "accepted geometry endpoint SEC is missing")
        proof_counts = [receipt["proven"], receipt["unproven"]]
    output.update(accepted=accepted, failure_reasons=result["failures"], evaluated_area_um2=end.area,
                  candidate_sec=proof_counts)
    return output


def cross_stage(left, right):
    if not left or not right or not left["completed"] or not right["completed"]:
        return None
    return {"artifact_sha256_equal": {name: left["artifact_sha256"][name] == right["artifact_sha256"][name]
                                        for name in ("odb", "def", "v")},
            "spef_without_date_equal": left["spef_without_date_sha256"] == right["spef_without_date_sha256"],
            "drc_marker_rows_equal": left["drc_markers"] == right["drc_markers"],
            "raw_three_corner_views_equal": left["views"] == right["views"],
            "failure_reasons_equal": left["failures"] == right["failures"],
            "release_set_equal": left["released_neighbors"] == right["released_neighbors"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=rank.FRESH)
    parser.add_argument("--prior", type=Path, default=shared.FRESH)
    parser.add_argument("--rank-receipt", type=Path, default=HERE / "v6_gcd_geometry_release_rank.json")
    args = parser.parse_args()
    with shared.bind_runtime("gcd", None):
        protocol = shared.read(args.root / "protocol.json")
        inputs = shared.source_and_pool(args.root, protocol)
        assets, _, _, _, edited, incident, _, _, _ = inputs
        geometry = rank.raw_rank(args.root / "cell_01/online/diagnosis/01", protocol, assets, edited, incident)
        shared.check(shared.read(args.rank_receipt)["geometry"] == json.loads(json.dumps(geometry)),
                     "selection differs from the earlier independent ranking")
        measured = audited_arm(args.root, protocol, geometry, inputs)
        shared.check(shared.digest(args.prior / "results.json") == PRIOR_RESULTS_SHA,
                     "matched-window historical results changed")
        past_protocol, previous = shared.audit_run(args.prior, "fresh")
        shared.check(all(past_protocol[field] == protocol[field] for field in shared.SHARED),
                     "geometry experiment changed its common setup")
    ordinary = previous["rows"][0]
    oracle = ordinary["passes"]["retry"]
    shared.check(oracle["route_tcl_normalized_sha256"] == ORACLE_TCL_SHA
                 and oracle["released_neighbors"] == ["net242"] and not oracle["drc_markers"]
                 and oracle["failures"] == ["TT:hold_regression"], "historical marker-oracle physical scope changed")
    comparisons = {f"geometry_{phase}": {"versus_ordinary_initial": cross_stage(physical, ordinary["passes"]["initial"]),
                                          "versus_posthoc_marker_oracle": cross_stage(physical, oracle)}
                   for phase, physical in measured["passes"].items()}
    print(json.dumps({"root": str(args.root), "producer": shared.cmp.bind(Path(__file__).resolve()),
                      "rank_source": shared.cmp.bind(args.rank_receipt), "geometry": geometry, "trial": measured,
                      "prior_results": shared.cmp.bind(args.prior / "results.json"),
                      "posthoc_marker_oracle": {"physical": oracle["geometry_sources"],
                                                "relative_tt_hold_delta_ps": oracle["hold_delta_ps"]["TT"],
                                                "qualified_area_saved_um2": ordinary["area_saved_um2"]},
                      "physical_comparison": comparisons}, indent=2))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Read-only audit of matched ordinary, boxed and full pre-route GCD diagnostics."""

import argparse
from collections import Counter
from decimal import Decimal
from hashlib import sha256
from itertools import combinations
import json
import math
from pathlib import Path
import re
import sys
from types import SimpleNamespace


REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "project_docs/evidence/tcad_ibex_20261123"))

import compare_ibex as cmp
from probe_aes_selective_repair import audit_timing, normalize_net, read, verify
from run_aes_protected_online import PROTECT_PA, drc_neighbor_evidence
from run_screened_matrix import RELATIVE_HOLD_REASONS, bind_runtime
import run_setup_budget_sweep as sweep
import verify_aes_cold_online as cold
from verify_aes_diagnostic_repair import audit_guided_retry
from verify_aes_protected_online import audit_logical, check


ROOT = Path("/home/toylog/faeco_tcad_sky_holdout_20261123")
HISTORICAL = ROOT / "gcd_marker_mechanism_20261125_v1"
FRESH = ROOT / "gcd_window_diagnosis_20261127_v1"
OLD_SHA = {
    "protocol.json": "be1e8b5e6aa0fe00554346f506d0fdd5bdf1a378402d4d8908822eddbbec4c6c",
    "results.json": "08eec7bdc16ba260d8cbb10afdf2db7f7129707c2617f8f58e640e81abb3849c",
    "independent_verification.json": "bf66317a21c06a2e1151208dd53f8f663a25dd532fed5ee312d12d05899232e5",
}
RANKS = (13, 14, 15)
ACTIONS = [f"\\_{n:03d}_=sky130_fd_sc_hd__mux2_1" for n in (92, 93, 94)]
MODES = {
    "historical": ("ordinary", "online", "online", "ordinary"),
    "fresh": ("ordinary", "boxed", "online"),
}
SHARED = ("seed", "reference", "original_sdc", "pool", "screen_inputs", "charged_screening_seconds", "clock",
          "fixed_ranks", "fixed_actions", "wall_budget_seconds_including_screen", "maximum_logical_requests_per_cell",
          "area_target_pct", "gate", "route_threads", "diagnostic_threads", "single_pin_access", "physical_cache")
DRC_REASONS = {"drc", "full_drc", "unlocked_drc"}
HISTORICAL_BASELINES = {"ordinary": 1, "boxed": 2, "online": 2}


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def dateless_spef(path):
    lines = path.read_bytes().splitlines(keepends=True)
    dates = [line for line in lines if line.startswith(b"*DATE ")]
    check(len(dates) == 1, (path, "SPEF must contain exactly one DATE field"))
    return sha256(b"".join(line for line in lines if not line.startswith(b"*DATE "))).hexdigest()


def marker_rows(path):
    data = path.read_text(encoding="utf-8")
    result = []
    for block in re.split(r"(?m)(?=^violation type: )", data):
        if not block.strip():
            continue
        match = re.fullmatch(r"violation type: (.+)\n\s*srcs:\s*(.+)\n\s*bbox\s*=\s*(.+)", block.strip())
        check(match is not None, (path, "DRC report has an unrecognized block"))
        kind, sources, bbox = match.groups()
        result.append((kind.strip(), " ".join(sorted(sources.split())), bbox.strip()))
    return result


def placements(definition):
    rows = re.findall(r"(?m)^\s*- (_09[234]_) (\S+) \+ PLACED \( (\d+) (\d+) \) (N|FS) ;$", definition)
    result = {name: {"cell": cell, "xy_dbu": [int(x), int(y)], "orientation": orient}
              for name, cell, x, y, orient in rows}
    check(set(result) == {"_092_", "_093_", "_094_"}, "three GCD candidate placements not found")
    return result


def reconstruct_geometry(protocol):
    assets = read(verify(protocol["seed"]))["bindings"]
    control = verify(assets["control"]["def"])
    lef = verify(assets["flow"]["setRC.tcl"]).parent / "lef"
    cells, tech = lef / "sky130_fd_sc_hd_merged.lef", lef / "sky130_fd_sc_hd.tlef"
    synth = control.parents[4] / "logs/sky130hd/gcd/base/1_synth.log"
    synth_log = synth.read_text(encoding="utf-8")
    check(all(f"LEF file: {path}, created " in synth_log for path in (cells, tech)),
          "GCD synthesis log does not bind its imported LEFs")
    definition = control.read_text(encoding="utf-8")
    dbu = int(re.search(r"(?m)^UNITS DISTANCE MICRONS (\d+) ;$", definition)[1])
    die = list(map(int, re.search(r"(?m)^DIEAREA \( (\d+) (\d+) \) \( (\d+) (\d+) \) ;$", definition).groups()))
    cell_lef = cells.read_text(encoding="utf-8")
    macro = re.search(r"(?ms)^MACRO sky130_fd_sc_hd__mux2_1\n(.*?)^END sky130_fd_sc_hd__mux2_1$", cell_lef)[1]
    prior_macro = re.search(r"(?ms)^MACRO sky130_fd_sc_hd__mux2_4\n(.*?)^END sky130_fd_sc_hd__mux2_4$", cell_lef)[1]
    site = re.search(r"(?ms)^SITE unithd\n(.*?)^END unithd$", tech.read_text(encoding="utf-8"))[1]
    dimensions = r"SIZE\s+([\d.]+) BY\s+([\d.]+)\s*;"
    width, height = [int(Decimal(value) * dbu) for value in re.search(dimensions, macro).groups()]
    original_width, original_height = [int(Decimal(value) * dbu) for value in re.search(dimensions, prior_macro).groups()]
    halo = int(Decimal(re.search(dimensions, site)[2]) * dbu)
    check(re.search(r"ORIGIN\s+0(?:\.0+)?\s+0(?:\.0+)?\s*;", macro) is not None and halo == height
          and "SITE unithd" in macro, "GCD target macro origin, row site, or height changed")
    anchors = placements(definition)
    boxes = {}
    for name, details in anchors.items():
        x, y = details["xy_dbu"]
        boxes[name] = [max(die[0], x - halo), max(die[1], y - halo),
                       min(die[2], x + width + halo), min(die[3], y + height + halo)]
    check(all(a[2] < b[0] or b[2] < a[0] or a[3] < b[1] or b[3] < a[1]
              for a, b in combinations(boxes.values(), 2)), "the GCD edited-instance windows merge")
    return {"sources": {"control_def": cmp.bind(control), "technology_lef": cmp.bind(tech),
                        "cell_lef": cmp.bind(cells), "synthesis_log": cmp.bind(synth)},
            "dbu_per_um": dbu, "die_bbox_dbu": die, "row_height_dbu": halo, "target_size_dbu": [width, height],
            "original_size_dbu": [original_width, original_height],
            "area_difference_from_lef_um2": len(anchors) * (original_width * original_height - width * height) / dbu**2,
            "placements": anchors, "inferred_windows_dbu": boxes}


def locate_late_markers(markers, geometry):
    located = []
    for kind, sources, marker in markers:
        numbers = re.findall(r"[-+]?\d+(?:\.\d+)?", marker.split(" on Layer ", 1)[0])
        bbox = [int(Decimal(value) * geometry["dbu_per_um"]) for value in numbers]
        check(len(bbox) == 4, (marker, "unrecognized GCD marker rectangle"))
        containing = [name for name, (x1, y1, x2, y2) in geometry["inferred_windows_dbu"].items()
                      if x1 <= bbox[0] <= bbox[2] <= x2 and y1 <= bbox[1] <= bbox[3] <= y2]
        intersections = {}
        for name, window in geometry["inferred_windows_dbu"].items():
            x1, y1, x2, y2 = max(bbox[0], window[0]), max(bbox[1], window[1]), min(bbox[2], window[2]), min(bbox[3], window[3])
            if x1 < x2 and y1 < y2:
                intersections[name] = [x1, y1, x2, y2]
        located.append({"kind": kind, "sources": sources, "bbox_dbu": bbox, "report_bbox": marker,
                        "window_intersections_dbu": intersections, "contained_in_windows_of": containing})
    return located


def source_and_pool(root, protocol):
    seed = read(verify(protocol["seed"]))
    assets = seed["bindings"]
    control = assets["control"]
    for payloads in (protocol["sources"], control, assets["flow"], assets["tools"]):
        for binding in payloads.values():
            verify(binding)
    for libraries in assets["used_libraries"].values():
        for library in libraries:
            verify(library)
    qualification = read(verify(assets["qualification_receipt"]))
    sdc = qualification["source_sdc_semantics"]
    check(seed["top"] == "gcd" and seed["pdk"] == "sky130hd" and seed["route_mode"] == "local"
          and seed["route_guide_source"] == "embedded in frozen CONTROL ODB"
          and seed["route_drt_iters"] == 64 and protocol["route_threads"] == seed["methods_route_threads"] == 4
          and protocol["single_pin_access"] and seed["single_pin_access"]
          and tuple(sdc[key] for key in ("period_ps", "io_delay_ps", "virtual_latency_ps")) == (1100, 220, 290)
          and sdc["expanded_port_counts"] == {"input": 35, "output": 18}
          and sdc["source_io_matches_all_nonclock_inputs_and_outputs"]
          and qualification["status"] == "hold_qualified" and qualification["detailed_route_drc_count"] == 0
          and qualification["source_sdc"] == protocol["original_sdc"] == assets["original_sdc"],
          (root, "GCD design, route settings or IO semantics changed"))
    verify(protocol["original_sdc"])
    pool = [cmp.PhysicalAction(**row) for row in read(verify(protocol["pool"]))]
    screen = protocol["screen_inputs"]
    screen_receipt = read(verify(screen["receipt"]))
    check(screen == seed["screen_inputs"] and read(verify(screen["pool"])) == read(verify(protocol["pool"]))
          and screen_receipt["wall_seconds"] == protocol["charged_screening_seconds"]
          and screen_receipt["pool_sha256"] == screen["pool"]["sha256"]
          and tuple(protocol["fixed_ranks"]) == RANKS and protocol["fixed_actions"] == ACTIONS
          and len(pool) == len({row.action_id for row in pool}) == 18
          and sorted(pool[rank - 1].action_id for rank in RANKS) == ACTIONS, (root, "pool or fixed proposal"))
    reference = read(verify(protocol["reference"]))["views"]
    definition = verify(control["def"])
    nets = cmp.def_section(definition, "NETS")
    edited, incident = cold.incident_signal_nets(ACTIONS, nets)
    check(len(nets) == 486 and len(incident) == 10 and set(protocol["static_check"]["incident_nets"]) == incident
          and all("+ USE CLOCK" in nets[clock] for clock in ("clk", "clknet_0_clk")),
          (root, "GCD incident/clock scope changed"))
    check(protocol["clock"] == "CLOCK_MONOTONIC_RAW" and protocol["wall_budget_seconds_including_screen"] == 720
          and protocol["maximum_logical_requests_per_cell"] == 1 and protocol["diagnostic_threads"] == 1
          and protocol["gate"]["budget_ps"] == 11 and protocol["gate"]["protect_clean_setup_views"] is False,
          (root, "GCD time and setup constraints changed"))
    areas = cmp.liberty_areas([verify(lib) for lib in assets["used_libraries"]["TT"]])
    masters = cmp.logical_masters(verify(control["v"]), areas)
    return assets, pool, reference, nets, edited, incident, areas, masters, sdc


def boxed_preview(directory, request, preview, physical, assets, actions, edited, incident, nets, deadline):
    check(len(preview) <= 1, (directory, "extra boxed diagnostic call"))
    path = directory / "diagnosis.json"
    if not path.exists():
        check(not physical and "finished_raw" not in request
              and (not preview or preview[0]["timeout_bound"] == "wall" and preview[0]["returncode"] is None),
              (directory, "boxed preview receipt missing before physical work"))
        return set(), {"mode": "boxed", "status": "window_censored" if preview else "not_started"}
    tool, = preview
    receipt = read(path)
    script = verify(receipt["script"])
    log = directory / "preview.log"
    check(script == directory / "preview.tcl" and tool["log"] == str(log)
          and tool["command"] == [str(verify(assets["tools"]["openroad"])), "-no_init", "-no_splash",
                                  "-threads", "1", "-exit", str(script)]
          and tool["configured_timeout_seconds"] == 60 and tool["start_raw"] < deadline
          and request["admitted_raw"] <= receipt["start_raw"] <= tool["start_raw"] <= tool["stop_raw"] <= receipt["stop_raw"]
          and receipt["seconds"] == receipt["stop_raw"] - receipt["start_raw"]
          and (not physical or receipt["stop_raw"] <= physical[0]["start_raw"]), (directory, "boxed process scope"))
    text = script.read_text(encoding="utf-8")
    reads = [("read_liberty", cmp.tcl(verify(lib))) for lib in assets["used_libraries"]["TT"]]
    reads += [("read_db", cmp.tcl(verify(assets["control"]["odb"]))),
              ("read_sdc", cmp.tcl(verify(assets["control"]["sdc"]))),
              *(("source", cmp.tcl(verify(assets["flow"][key]))) for key in ("setRC.tcl", "fastroute.tcl"))]
    boundary = 'puts "IBEX_CLEARED_SIGNAL_WIRES $cleared"\n'
    check(re.findall(r"(?m)^\s*(read_\w+|source) (.+)$", text) == reads
          and re.findall(r"(?m)^set inst \[\[ord::get_db_block\] findInst (.+)\]$", text)
          == [cmp.tcl(action.instance) for action in actions for _ in (0, 1)]
          and re.findall(r"(?m)^set target \[\[ord::get_db\] findMaster (.+)\]$", text)
          == [cmp.tcl(action.target_cell) for action in actions]
          and text.count(boundary) == 1 and "odb::dbWire_destroy $wire" in text.split(boundary)[0]
          and text.count("drt::check_drc -box ") == text.count("drt::check_drc ") == 1
          and "round($_row_h * 1.0)" in text and "getDieArea" in text and "getBBox" in text
          and text.index(boundary) < text.index("drt::check_drc -box ")
          and not re.search(r"(?m)^\s*(?:detailed_route|global_route|extract_parasitics|write_\w+|read_guides)\s", text)
          and text.rstrip().endswith(f"puts {cold.PREVIEW_COMPLETE}\nexit"), (directory, "boxed Tcl scope"))
    check(receipt["diagnosis_mode"] == "boxed" and receipt["halo_rows"] == 1
          and receipt["actions"] == request["actions"] and receipt["incident_nets"] == sorted(incident),
          (directory, "boxed receipt altered candidate or halo"))
    if receipt["status"] == "unavailable":
        check(not receipt["released_neighbors"] and receipt["failure"], (directory, "unavailable diagnostic guided"))
        return set(), {"mode": "boxed", "status": "unavailable", "seconds": receipt["seconds"]}
    check(tool["returncode"] == 0 and receipt["failure"] is None, (directory, "boxed measurement failed"))
    output = log.read_text(encoding="utf-8")
    found = re.findall(r"(?m)^FAECO_BOXED_DRC_META dbu=(\d+) row_h=(\d+) halo=(\d+) seeds=(\d+) boxes=(\d+)$", output)
    sizes, = found
    keys = ("dbu_per_um", "row_height_dbu", "halo_dbu", "seed_instances", "merged_boxes")
    meta = dict(zip(keys, map(int, sizes), strict=True))
    check(meta == receipt["box_meta"] and meta["dbu_per_um"] == 1000
          and meta["row_height_dbu"] == meta["halo_dbu"] == 2720
          and meta["seed_instances"] == len(edited) and 1 <= meta["merged_boxes"] <= len(edited)
          and set(re.findall(r"(?m)^IBEX_TOUCHED_NET (.+)$", output)) == incident
          and re.findall(r"(?m)^IBEX_CLEARED_SIGNAL_WIRES (\d+)$", output) == [str(len(incident))]
          and cold.PREVIEW_COMPLETE in output, (directory, "boxed metadata or touched nets"))
    raw = [marker for idx in range(meta["merged_boxes"]) for marker in marker_rows(directory / f"box_{idx}.rpt")]
    report = verify(receipt["report"])
    markers = marker_rows(report)
    check(report == directory / "local_drc.rpt" and Counter(markers) == Counter(dict.fromkeys(raw, 1))
          and len(raw) == receipt["raw_marker_count"] and len(markers) == receipt["marker_count"],
          (directory, "boxed markers do not reconstruct from per-window reports"))
    neighbors, proof = drc_neighbor_evidence((report,), incident, edited, nets)
    if len(proof) != len(markers):
        neighbors = set()
    check(sorted(neighbors) == receipt["released_neighbors"] and proof == receipt["marker_evidence"]
          and receipt["status"] == ("guided" if neighbors else "no_complete_guidance"),
          (directory, "boxed guidance does not reconstruct from measured markers"))
    return neighbors, {"mode": "boxed", "status": receipt["status"], "seconds": receipt["seconds"], "box_meta": meta,
                       "marker_count": len(markers), "marker_rows": markers, "released": sorted(neighbors),
                       "sources": {"tcl": cmp.bind(script), "log": cmp.bind(log), "merged_report": receipt["report"],
                                   "window_reports": [cmp.bind(directory / f"box_{idx}.rpt")
                                                      for idx in range(meta["merged_boxes"])]}}


def normalized_tcl(path, directory):
    return path.read_text(encoding="utf-8").replace(str(directory), "<OUTPUT>")


def audit_pass(directory, protocol, assets, reference, areas, masters, expected_actions, route_audit):
    path = directory / "receipt.json"
    if not path.exists():
        return {"completed": False}
    receipt = read(path)
    check(receipt["actions"] == expected_actions and receipt["control_sdc"] == assets["control"]["sdc"],
          (directory, "route changed proposed edit tuple or bound SDC"))
    if not receipt["routed_to_completion"] or not receipt["extracted_to_completion"]:
        return {"completed": False, "route_reported_failures": receipt["failures"]}
    check(set(receipt["views"]) == set(cmp.CORNERS), (directory, "missing STA corners"))
    for corner, expected in receipt["views"].items():
        sta = Path(receipt["operations"][f"STA_{corner}"]["log"])
        raw = sta.read_text(encoding="utf-8")
        check(sta == directory / f"sta_{corner}.log" and "IBEX_STA_COMPLETE" in raw and cmp.parse_sta(raw) == expected,
              (directory, corner, "raw STA does not reconstruct"))
    artifacts = {key: verify(binding) for key, binding in receipt["artifacts"].items()}
    expected_masters = dict(masters)
    for action in expected_actions:
        name, cell = action.split("=", 1)
        expected_masters[cmp.canonical_odb_name(name)] = cell
    actual = cmp.logical_masters(artifacts["v"], areas)
    check(actual == expected_masters and math.isclose(math.fsum(areas[cell] for cell in actual.values()),
                                                      receipt["endpoint"]["area"], rel_tol=0, abs_tol=1e-8),
          (directory, "routed netlist action set or Liberty area"))
    route = (directory / "route.tcl").read_text(encoding="utf-8")
    log = (directory / "route.log").read_text(encoding="utf-8")
    pin_access = len(re.findall(PROTECT_PA, log))
    check('if {![grt::have_routes]}' in route and route.count("-droute_end_iter 64") == 1 and pin_access == 1,
          (directory, "actual embedded-guide route or single pin access"))
    assessment = read(directory / "assessment.json")
    independent = read(directory / "unlocked_drc/audit.json")
    inputs = read(directory / "unlocked_drc/inputs.json")
    check(verify(assessment["physical_receipt"]) == path and independent == assessment["unlocked"]
          and inputs["matrix_config"] == protocol["seed"]
          and all(inputs[f"input_{key}"] == receipt["artifacts"][key] for key in ("odb", "def"))
          and assessment["pin_access_starts"] == pin_access, (directory, "independent DRC is bound to another route"))
    verify(independent["normalized_geometry"])
    unlocked_tcl = (directory / "unlocked_drc/audit.tcl").read_text(encoding="utf-8")
    check(unlocked_tcl.count("drt::check_drc ") == 1 and "drt::check_drc -box" not in unlocked_tcl,
          (directory, "post-route DRC must remain full-block"))
    markers = marker_rows(verify(independent["report"]))
    check(len(markers) == independent["drc_markers"] and sorted({row[0] for row in markers}) == independent["marker_types"],
          (directory, "independent DRC report/receipt mismatch"))
    frozen_nets = cmp.def_section(verify(assets["control"]["def"]), "NETS")
    routed_nets = cmp.def_section(artifacts["def"], "NETS")
    restored_nets = cmp.def_section(verify(independent["normalized_geometry"]), "NETS")
    fixed_count = sum("+ FIXED " in entry for entry in routed_nets.values())
    check(set(routed_nets) == set(restored_nets) and fixed_count == inputs["original_fixed_wire_count"]
          and not any("+ FIXED " in entry for entry in restored_nets.values())
          and all(normalize_net(routed_nets[net]) == normalize_net(restored_nets[net]) for net in routed_nets),
          (directory, "restored full-block DRC modified route geometry"))
    observed_placement = placements(artifacts["def"].read_text(encoding="utf-8"))
    frozen_placement = placements(verify(assets["control"]["def"]).read_text(encoding="utf-8"))
    check(all(expected_masters[name] == observed_placement[name]["cell"]
              and all(observed_placement[name][key] == frozen_placement[name][key] for key in ("orientation", "xy_dbu"))
              for name in frozen_placement), (directory, "routed candidate changed placement coordinates"))
    snapshot = directory / "pre_drt.def"
    check(placements(snapshot.read_text(encoding="utf-8")) == frozen_placement,
          (directory, "pre-route snapshot placement"))
    if expected_actions:
        check(route.index("pre_drt.def") < route.index("swapMaster"),
              (directory, "pre-route snapshot must precede the master replacements"))
    gate = protocol["gate"]
    timing_gate = sweep.BudgetGate(gate["budget_ps"], gate["setup_tns_budget_ps_by_view"], gate["protect_clean_setup_views"])
    hold = cmp.joint_failures(reference, receipt["views"], check_setup=False)
    check(all(reason in receipt["failures"] for reason in hold), (directory, "joint hold/electrical gate changed"))
    failures = [reason for reason in receipt["failures"] if expected_actions or reason != "no_area_gain"]
    failures += route_audit.get("failures", [])
    if markers:
        failures.append("unlocked_drc")
    failures.extend(audit_timing(SimpleNamespace(ref_views=reference), receipt, timing_gate, not expected_actions))
    check(Counter(failures) == Counter(assessment["failures"]), (directory, "physical acceptance reasons differ"))
    return {"completed": True, "failures": failures, "pin_access_starts": pin_access, "drc_markers": markers,
            "droute_report_markers": receipt["drc_violations"], "fixed_wire_count": inputs["original_fixed_wire_count"],
            "released_neighbors": read(directory / "routing_scope.json")["released_neighbors"],
            "incident_and_neighbor_wires_equal_to_control": {net: normalize_net(frozen_nets[net])
                                                                == normalize_net(routed_nets[net])
                                                                for net in ("net242", "net266")},
            "routed_placements": observed_placement,
            "geometry_sources": {"pre_swap_def": cmp.bind(snapshot), "routed_def": receipt["artifacts"]["def"],
                                 "whole_block_report": independent["report"], "route_tcl": cmp.bind(directory / "route.tcl")},
            "route_tcl_normalized_sha256": sha256(normalized_tcl(directory / "route.tcl", directory).encode()).hexdigest(),
            "unlocked_tcl_normalized_sha256": sha256(normalized_tcl(directory / "unlocked_drc/audit.tcl", directory).encode()).hexdigest(),
            "artifact_sha256": {key: receipt["artifacts"][key]["sha256"] for key in ("odb", "def", "v", "spef")},
            "spef_without_date_sha256": dateless_spef(artifacts["spef"]), "views": receipt["views"],
            "hold_delta_ps": {c: receipt["views"][c]["hold_wns_ps"] - reference[c]["hold_wns_ps"] for c in cmp.CORNERS}}


def audit_cell(root, row, protocol, inputs, zero, previous_stop):
    assets, pool, reference, nets, edited, incident, areas, masters, _ = inputs
    method, index = row["method"], row["cell"]
    mode = row.get("diagnosis_mode", method)
    mode = "online" if mode == "full" else mode
    check(method == ("ordinary" if mode == "ordinary" else "online"), (index, "mismatched arm mode and path"))
    arm = root / f"cell_{index:02d}" / method
    progress = read(arm / "progress.json")
    summary = read(arm / "summary.json")
    start, deadline = progress["start_raw"], progress["deadline_raw"]
    charge = protocol["charged_screening_seconds"]
    requests, checkpoints = progress["logical_requests"], progress["checkpoints"]
    check(summary == row["result"] and (previous_stop is None or previous_stop <= row["outer_start_raw"])
          and row["outer_start_raw"] <= start <= summary["stop_raw"] <= row["outer_stop_raw"]
          and math.isclose(deadline - start + charge, 720, rel_tol=0, abs_tol=1e-7)
          and 0 <= len(checkpoints) <= len(requests) <= 1 and summary["logical_admitted"] == len(requests)
          and summary["logical_finished"] == len(checkpoints), (arm, "publication, timing window, or dispatch count"))
    tools = read(arm / "subprocesses.json")
    output = {"cell": index, "method": method, "mode": mode, "status": summary["stop_reason"],
              "admitted": len(requests), "finished": len(checkpoints), "area_saved_um2": summary["window"]["area_saved"]}
    if not requests:
        check(not tools and not checkpoints and summary["stop_reason"] == "end_to_end_wall_cap",
              (arm, "tool or acceptance before dispatch"))
        return output
    request, = requests
    admitted = request["admitted_raw"]
    check(request["id"] == 1 and request["actions"] == ACTIONS and start <= admitted < deadline,
          (arm, "different fixed proposal or late admission"))
    audit_order = admitted
    preview, physical = [], []
    for row in tools:
        log = Path(row["log"]).relative_to(arm)
        check(log.parts[0] in ("01", "diagnosis") and audit_order <= row["start_raw"] < deadline
              and row["stop_raw"] >= row["start_raw"]
              and math.isclose(row["effective_timeout_seconds"],
                               min(row["configured_timeout_seconds"], deadline - row["start_raw"]),
                               rel_tol=0, abs_tol=1e-7), (arm, "tool outside timed fixed request"))
        audit_order = row["stop_raw"]
        (preview if log.parts[0] == "diagnosis" else physical).append(row)
    directory = arm / "diagnosis/01"
    if mode == "ordinary":
        check(not directory.exists() and not preview, (arm, "ordinary arm executed pre-route diagnosis"))
        neighbors, diagnosis = set(), None
    elif mode == "boxed":
        by_id = {action.action_id: action for action in pool}
        neighbors, diagnosis = boxed_preview(directory, request, preview, physical, assets,
                                             [by_id[key] for key in ACTIONS], edited, incident, nets, deadline)
    else:
        by_id = {action.action_id: action for action in pool}
        neighbors, info = cold.audit_diagnosis(directory, request, preview, physical, assets, by_id,
                                               edited, incident, nets, deadline)
        diagnosis = {"mode": "online", "status": info["status"]}
        if info["completed"]:
            diagnosis.update(marker_count=info["markers"], released=info["released"], seconds=info["seconds"],
                             marker_rows=marker_rows(verify(info["report"])) if info["report"] else [],
                             sources={"log": info["log"], "report": info["report"],
                                      "tcl": cmp.bind(directory / "preview.tcl")})
    scopes = cold.audit_physical(arm / "01", request, physical, edited, incident, neighbors, nets)
    passes = {}
    for name, scope in scopes.items():
        trial = arm / "01" / name
        route_audit = read(verify(scope["routing_audit"])) if "routing_audit" in scope else {}
        passes[name] = audit_pass(trial, protocol, assets, reference, areas, masters, ACTIONS, route_audit)
    stages = Counter(Path(row["log"]).name for row in tools)
    wall_seconds = {stage: math.fsum(tool["wall_seconds"] for tool in tools if Path(tool["log"]).name == stage)
                    for stage in stages}
    output.update(diagnosis=diagnosis, passes=passes, stage_attempts=dict(stages), stage_wall_seconds=wall_seconds,
                  actual_wall_timeouts=[{"log": Path(item["log"]).name, "effective_s": item["effective_timeout_seconds"]}
                                        for item in tools if item["returncode"] is None and item["timeout_bound"] == "wall"])
    if not checkpoints:
        check("finished_raw" not in request and summary["stop_reason"] == "end_to_end_wall_cap"
              and not output["area_saved_um2"], (arm, "unfinished request attributed incorrectly"))
        return output
    checkpoint, = checkpoints
    check(admitted <= audit_order <= request["finished_raw"] < deadline
          and math.isclose(checkpoint["elapsed_seconds"], charge + request["finished_raw"] - start,
                           rel_tol=0, abs_tol=1e-7), (arm, "late or unmetered finish"))
    gate = protocol["gate"]
    if neighbors and "retry" in scopes:
        result, endpoint = audit_guided_retry(arm / "01", assets["control"], reference, gate)
    else:
        result, endpoint = audit_logical(arm / "01", nets, assets["control"], reference, gate)
    expected = list(passes[result["passes"][-1]].get("failures", result["failures"]))
    if "sec" in result["failures"]:
        check(stages["sec.log"] == 1 and not expected, (arm, "SEC preceded failed physical gate"))
        expected.append("sec")
    if DRC_REASONS.intersection(expected):
        expected = [reason for reason in expected if reason not in RELATIVE_HOLD_REASONS]
    check(Counter(expected) == Counter(result["failures"]) == Counter(request["failures"])
          and checkpoint["endpoint"] == result["endpoint"], (arm, "final failure or endpoint provenance"))
    policy = cmp.BudgetPolicy.from_ps(gate["budget_ps"], tolerance_ns=cmp.PS_TOLERANCE / 1000)
    accepted = cmp.assess(zero, endpoint, policy).feasible and endpoint.area < zero.area - 1e-9
    check(checkpoint["accepted"] == accepted and output["area_saved_um2"] == (zero.area - endpoint.area if accepted else 0),
          (arm, "720s accepted endpoint does not reconstruct"))
    proof = None
    if accepted:
        final = arm / "01" / result["passes"][-1] / "sec"
        proof = read(final / "receipt.json")
        check(stages["sec.log"] == 1 and proof["proven"] == 262 and proof["unproven"] == 0
              and b"262 are proven and 0 are unproven" in verify(proof["log"]).read_bytes(),
              (arm, "accepted proposal lacks whole-netlist GCD proof"))
    output.update(accepted=accepted, failure_reasons=result["failures"], evaluated_area_um2=endpoint.area,
                  sec_observed=None if proof is None else [proof["proven"], proof["unproven"]])
    return output


def audit_run(root, group, *, partial=False):
    protocol = read(root / "protocol.json")
    raw = read(root / "results.json")
    arm_modes = [row.get("diagnosis_mode", row["method"]) for row in raw]
    arm_modes = ["online" if mode == "full" else mode for mode in arm_modes]
    check(tuple(arm_modes) == MODES[group][:len(raw)] and (partial or len(raw) == len(MODES[group]))
          and [row["cell"] for row in raw] == list(range(1, len(raw) + 1)), (root, "unexpected arm order"))
    inputs = source_and_pool(root, protocol)
    assets, _, views, nets, _, _, areas, masters, sdc = inputs
    zero_dir = root / "preflight/zero"
    zero_record, zero = audit_logical(zero_dir, nets, assets["control"], views, protocol["gate"])
    zero_proof = read(zero_dir / "initial/sec/receipt.json")
    zero_route = audit_pass(zero_dir / "initial", protocol, assets, views, areas, masters, [],
                            read(zero_dir / "initial/routing_audit.json"))
    check(zero.valid and zero.sec_pass and not zero_record["actions"] and not zero_route["failures"]
          and zero_proof["proven"] == 262 and zero_proof["unproven"] == 0
          and b"262 are proven and 0 are unproven" in verify(zero_proof["log"]).read_bytes(),
          (root, "strict zero reference did not reproduce"))
    checked, last = [], None
    geometry = reconstruct_geometry(protocol)
    for row in raw:
        audited = audit_cell(root, row, protocol, inputs, zero, last)
        for phase, item in audited.get("passes", {}).items():
            if item["completed"]:
                item["markers_located_in_reconstructed_windows"] = locate_late_markers(item["drc_markers"], geometry)
        if audited.get("diagnosis") and audited["diagnosis"].get("box_meta"):
            box_meta = audited["diagnosis"]["box_meta"]
            check(box_meta["merged_boxes"] == len(geometry["inferred_windows_dbu"]),
                  "recorded merged-window count differs from DEF/LEF reconstruction")
        checked.append(audited)
        last = row["outer_stop_raw"]
    return protocol, {"root": str(root), "zero_area_um2": zero.area, "zero_proof": [262, 0], "source_sdc": sdc,
                      "reference_hold_ps": {corner: views[corner]["hold_wns_ps"] for corner in cmp.CORNERS},
                      "window_geometry_from_def_lef": geometry, "rows": checked}


def compare_pair(left, right):
    comparisons = {}
    for name in sorted(left.get("passes", {}).keys() & right.get("passes", {}).keys()):
        first, second = left["passes"][name], right["passes"][name]
        if not (first["completed"] and second["completed"]):
            comparisons[name] = {"both_full_physical_passes": False}
            continue
        comparisons[name] = {"both_full_physical_passes": True,
                             "artifact_hash_equal": {key: first["artifact_sha256"][key] == second["artifact_sha256"][key]
                                                     for key in ("odb", "def", "v", "spef")},
                             **{f"same_{key}": first[key] == second[key] for key in (
                                 "spef_without_date_sha256", "route_tcl_normalized_sha256", "views", "drc_markers",
                                 "unlocked_tcl_normalized_sha256", "released_neighbors", "failures")}}
    one, two = left.get("diagnosis"), right.get("diagnosis")
    return {"same_finished_and_outcome": (left["finished"], left.get("accepted"), left.get("failure_reasons"))
            == (right["finished"], right.get("accepted"), right.get("failure_reasons")),
            "preview_full_vs_boxed_marker_and_release_match": None if not one or not two or "marker_rows" not in one
            or "marker_rows" not in two else (one["marker_rows"], one["released"]) == (two["marker_rows"], two["released"]),
            "physical_passes": comparisons}


def compact_geometry(report):
    cells = []
    for row in report["rows"]:
        physical = {}
        for phase, trial in row.get("passes", {}).items():
            if trial["completed"]:
                physical[phase] = {key: trial[key] for key in ("geometry_sources", "routed_placements", "released_neighbors",
                                   "markers_located_in_reconstructed_windows", "incident_and_neighbor_wires_equal_to_control")}
        cells.append({"mode": row["mode"], "cell": row["cell"], "diagnosis": row.get("diagnosis"),
                      "physical": physical})
    return {"producer": cmp.bind(Path(__file__).resolve()), "root": report["root"], "actions": ACTIONS,
            "window_geometry_from_def_lef": report["window_geometry_from_def_lef"], "cells": cells,
            "method": "Window coordinates reconstructed from the imported LEFs, stable DEF placements, target master "
                      "dimensions and the preview Tcl. The recorded OpenROAD box count is checked independently. "
                      "The pre_drt.def snapshot precedes swapMaster; the exported routed DEF confirms the new masters "
                      "and preserved anchors. Each later whole-block marker is checked against all reconstructed windows."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--historical", type=Path, default=HISTORICAL)
    parser.add_argument("--fresh", type=Path, default=FRESH)
    parser.add_argument("--historical-only", action="store_true")
    parser.add_argument("--partial", action="store_true", help="accept a formally published prefix of the three fresh arms")
    parser.add_argument("--geometry-only", action="store_true", help="emit the compact window and late-marker evidence receipt")
    args = parser.parse_args()
    for key, expected in OLD_SHA.items():
        check(digest(args.historical / key) == expected, (key, "historical GCD source changed"))
    with bind_runtime("gcd", None):
        old_protocol, old = audit_run(args.historical, "historical")
        payload = {"historical": old}
        if not args.historical_only:
            new_protocol, new = audit_run(args.fresh, "fresh", partial=args.partial)
            check(all(old_protocol[key] == new_protocol[key] for key in SHARED),
                  "fresh common route/constraint protocol changed")
            matching = {row["mode"]: compare_pair(old["rows"][HISTORICAL_BASELINES[row["mode"]] - 1], row)
                        for row in new["rows"]}
            pairs = {f"{a['mode']}_vs_{b['mode']}": compare_pair(a, b) for a, b in combinations(new["rows"], 2)}
            payload.update(fresh=new, against_historical=matching, fresh_pairs=pairs)
    if args.geometry_only:
        report = payload["historical"] if args.historical_only else payload["fresh"]
        payload = compact_geometry(report)
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()

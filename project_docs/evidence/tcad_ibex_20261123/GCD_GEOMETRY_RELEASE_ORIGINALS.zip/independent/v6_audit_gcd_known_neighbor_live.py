#!/usr/bin/env python3
"""Read-only GCD posthoc known-neighbor audit against the old ordinary retry."""
import argparse
from collections import Counter
import json
import math
from pathlib import Path

import v6_audit_gcd_geometry_release_live as geometry
import v6_verify_gcd_same_proposal as evidence


ROOT = evidence.ROOT / "gcd_known_neighbor_release_20261127_v2"
ORDINARY = "cell_01/ordinary/01"
NEIGHBOR = "net242"


def ordinary_pass(prior, protocol, inputs):
    assets, _, views, nets, _, incident, areas, masters, _ = inputs
    directory = prior / ORDINARY
    result = evidence.read(directory / "result.json")
    check = evidence.check
    check(result["passes"] == ["initial", "retry"] and result["failures"] == ["TT:hold_regression"],
          "previous ordinary arm did not have its expected two-pass hold result")
    trial = directory / "retry"
    scope = evidence.read(trial / "routing_scope.json")
    check(scope["released_neighbors"] == [NEIGHBOR] and set(scope["expected_touched_nets"]) == incident | {NEIGHBOR},
          "previous retry did not apply the same one-net scope")
    route_audit = evidence.read(trial / "routing_audit.json")
    standalone_scope = {"routing_audit": evidence.cmp.bind(trial / "routing_audit.json"),
                        "released": [NEIGHBOR]}
    check(not route_audit["changed_protected_nets"] and not route_audit["changed_untouched_nets"],
          "historical retry modified protected wires")
    physical = geometry.raw_pass(trial, protocol, assets, views, areas, masters, standalone_scope)
    check(physical["completed"] and physical["route_tcl_normalized_sha256"] == geometry.ORACLE_TCL_SHA,
          "reference retry recipe changed")
    route_seconds = [row["wall_seconds"] for row in evidence.read(directory.parent / "subprocesses.json")
                     if Path(row["log"]).name == "route.log"]
    check(len(route_seconds) == 2, "previous ordinary arm did not actually run both route processes")
    cp, = evidence.read(directory.parent / "progress.json")["checkpoints"]
    return trial, physical, route_seconds, cp["elapsed_seconds"]


def verify_known(root, prior):
    read, check = evidence.read, evidence.check
    protocol = read(root / "protocol.json")
    old_protocol = read(prior / "protocol.json")
    check(evidence.digest(prior / "results.json") == geometry.PRIOR_RESULTS_SHA
          and all(old_protocol[key] == protocol[key] for key in evidence.SHARED),
          "known-neighbor arm changed the frozen protocol or previous experiment")
    inputs = evidence.source_and_pool(root, protocol)
    assets, _, views, nets, edited, incident, areas, masters, _ = inputs
    release_origin = read(evidence.verify(protocol["release_source"]))
    check(protocol["initial_release_cap"] == 1 and release_origin["released_neighbors"] == [NEIGHBOR]
          and NEIGHBOR not in incident and "+ USE SIGNAL" in nets[NEIGHBOR] and "+ ROUTED " in nets[NEIGHBOR],
          "known initial release has no eligible historical provenance")
    zero_dir = root / "preflight/zero"
    _, zero = evidence.audit_logical(zero_dir, nets, assets["control"], views, protocol["gate"])
    zero_sec = read(zero_dir / "initial/sec/receipt.json")
    check(zero.valid and zero.sec_pass and (zero_sec["proven"], zero_sec["unproven"]) == (262, 0),
          "new zero-edit qualification failed")
    arm = root / "cell_01/online"
    directory = arm / "01"
    hint_path = arm / "diagnosis/01/known_neighbor.json"
    hint = read(hint_path)
    check(hint["actions"] == evidence.ACTIONS and hint["released_neighbors"] == [NEIGHBOR]
          and "post hoc" in hint["source"], "incorrect known-neighbor admission")
    row, = read(root / "results.json")
    progress, summary = [read(arm / f"{name}.json") for name in ("progress", "summary")]
    request, = progress["logical_requests"]
    checkpoint, = progress["checkpoints"]
    charge = protocol["charged_screening_seconds"]
    deadline = progress["deadline_raw"]
    check((row["cell"], row["method"], row["diagnosis_mode"]) == (1, "online", "known_neighbor")
          and row["result"] == summary and request["actions"] == evidence.ACTIONS and request["physical_passes"] == 1
          and summary["logical_admitted"] == summary["logical_finished"] == 1
          and row["outer_start_raw"] <= progress["start_raw"] <= request["admitted_raw"] < request["finished_raw"] < deadline
          and request["finished_raw"] <= summary["stop_raw"] <= row["outer_stop_raw"]
          and math.isclose(deadline - progress["start_raw"] + charge, 720.0, abs_tol=1e-7, rel_tol=0)
          and math.isclose(checkpoint["elapsed_seconds"], request["finished_raw"] - progress["start_raw"] + charge,
                           abs_tol=1e-7, rel_tol=0), "wrong proposal, logical count or wall-window provenance")
    tools = read(arm / "subprocesses.json")
    counts = Counter(Path(tool["log"]).name for tool in tools)
    check(counts == {"route.log": 1, "sta_FF.log": 1, "sta_TT.log": 1, "sta_SS.log": 1, "audit.log": 1}
          and all(tool["returncode"] == 0 and request["admitted_raw"] <= tool["start_raw"] <= tool["stop_raw"]
                  <= request["finished_raw"] and math.isclose(tool["effective_timeout_seconds"],
                       min(deadline - tool["start_raw"], tool["configured_timeout_seconds"]), abs_tol=1e-7, rel_tol=0)
                  for tool in tools)
          and all(left["stop_raw"] <= right["start_raw"] for left, right in zip(tools, tools[1:])),
          "the known-neighbor arm did not execute exactly one complete route and signoff pass")
    scopes = evidence.cold.audit_physical(directory, request, tools, edited, incident, {NEIGHBOR}, nets)
    check(tuple(scopes) == ("initial",) and not (directory / "retry_decision.json").exists(),
          "unexpected retry in known-neighbor arm")
    trial = directory / "initial"
    physical = geometry.raw_pass(trial, protocol, assets, views, areas, masters, scopes["initial"])
    result, endpoint = evidence.audit_logical(directory, nets, assets["control"], views, protocol["gate"])
    check(physical["completed"] and physical["released_neighbors"] == [NEIGHBOR]
          and set(physical["touched_nets"]) == incident | {NEIGHBOR} and physical["fixed_nets"] == 475
          and physical["drc_markers"] == [] and physical["droute_report_markers"] == 0
          and physical["failures"] == request["failures"] == result["failures"] == ["TT:hold_regression"]
          and result["proof_operations"] == {} and not endpoint.valid and not endpoint.sec_pass
          and not checkpoint["accepted"] and checkpoint["endpoint"] == result["endpoint"]
          and summary["window"]["area_saved"] == 0, "DRC-clean known-neighbor route did not retain the hold gate")
    old_trial, former, old_route, old_elapsed = ordinary_pass(prior, old_protocol, inputs)
    identity = geometry.cross_stage(physical, former)
    identity.update(normalized_route_tcl_equal=physical["route_tcl_normalized_sha256"]
                    == former["route_tcl_normalized_sha256"],
                    fixed_wire_patch_equal=physical["fixed_wire_patch"]["sha256"] == former["fixed_wire_patch"]["sha256"],
                    normalized_whole_block_drc_tcl_equal=physical["unlocked_tcl_normalized_sha256"]
                    == former["unlocked_tcl_normalized_sha256"])
    check(all(identity["artifact_sha256_equal"].values())
          and all(value for key, value in identity.items() if key != "artifact_sha256_equal"), identity)
    return {"root": str(root), "prior_retry": str(old_trial), "historical_release_source": protocol["release_source"],
            "known_neighbor_receipt": evidence.cmp.bind(hint_path), "new_results": evidence.cmp.bind(root / "results.json"),
            "strict_zero_sec": [262, 0], "current_initial": physical,
            "matched_historical_retry_hashes": former["artifact_sha256"],
            "matched_historical_retry_spef_without_date_sha256": former["spef_without_date_sha256"],
            "physical_identity": identity, "current_candidate_tools": dict(counts),
            "current_route_sec": tools[0]["wall_seconds"], "prior_route_sec": old_route,
            "current_elapsed_including_screen_sec": checkpoint["elapsed_seconds"],
            "prior_elapsed_including_screen_sec": old_elapsed, "qualified_saved_um2": 0.0,
            "rejection": result["failures"], "failed_attempt_v1": failed_v1(root)}


def failed_v1(root):
    failed = root.with_name(root.name.removesuffix("_v2") + "_v1")
    arm = failed / "cell_01/online"
    evidence.check((failed / "preflight/zero/result.json").exists() and not (arm / "01").exists()
                   and not (failed / "results.json").exists(), "v1 provenance unexpectedly included candidate physics")
    return {"root": str(failed), "preflight_present": True, "candidate_physical_directory_present": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--prior", type=Path, default=evidence.FRESH)
    args = parser.parse_args()
    with evidence.bind_runtime("gcd", None):
        out = verify_known(args.root, args.prior)
    out["independent_auditor"] = evidence.cmp.bind(Path(__file__).resolve())
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()

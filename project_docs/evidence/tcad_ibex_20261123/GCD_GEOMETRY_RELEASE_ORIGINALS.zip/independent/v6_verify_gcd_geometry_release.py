#!/usr/bin/env python3
"""Recompute GCD's geometry release rank and independently audit its live arm."""

import argparse
from collections import Counter
from hashlib import sha256
import json
import math
from pathlib import Path
import re

import v6_verify_gcd_same_proposal as shared


FRESH = shared.ROOT / "gcd_geometry_release_20261127_v1"
LAYERS = {"li1", "met1"}


def frozen_def_segments(path):
    text = path.read_text(encoding="utf-8")
    section = re.search(r"(?ms)^NETS (\d+) ;\n(.*?)^END NETS$", text)
    entries = dict(re.findall(r"(?ms)^[ \t]*- (\S+)\s+([^;]*);", section[2]))
    shared.check(len(entries) == int(section[1]) == 486, "independent DEF parse did not cover frozen net inventory")
    source = {}
    skipped_unsupported_layers = 0
    patch_rectangles = 0
    for name, entry in entries.items():
        if not re.search(r"\+\s+USE\s+SIGNAL\b", entry):
            continue
        geometry = re.search(r"\+\s+ROUTED\s+([^+]*)(?:\+|$)", entry)
        if geometry is None:
            continue
        chunks = re.split(r"\sNEW\s+", geometry[1])
        segments = []
        for chunk in chunks:
            layer = chunk.split(None, 1)[0]
            if layer not in LAYERS:
                skipped_unsupported_layers += 1
                continue
            points = []
            for shape, field in re.findall(r"(\bRECT\s*)?\(([^()]*)\)", chunk):
                xy = field.split()
                if shape:
                    shared.check(len(xy) == 4 and all(re.fullmatch(r"[+-]?\d+", v) for v in xy),
                                 (name, layer, "malformed DEF patch rectangle"))
                    patch_rectangles += 1
                    continue
                shared.check(len(xy) in (2, 3) and all(re.fullmatch(r"[+-]?\d+|\*", v) for v in xy[:2]),
                             (name, layer, "unsupported DEF point"))
                xy = tuple(points[-1][i] if item == "*" and points else int(item) for i, item in enumerate(xy[:2]))
                if points:
                    old_x, old_y = points[-1]
                    shared.check(old_x == xy[0] or old_y == xy[1], (name, layer, "unexpected diagonal DEF segment"))
                points.append(xy)
            if points:
                segments.extend((layer, first, second)
                                for first, second in zip([points[0], *points[:-1]], points, strict=True))
        if segments:
            source[name] = segments
    return source, skipped_unsupported_layers, patch_rectangles


def squared_distance(segment, box):
    _, (x0, y0), (x1, y1) = segment
    left, bottom, right, top = box
    dx = max(left - max(x0, x1), min(x0, x1) - right, 0)
    dy = max(bottom - max(y0, y1), min(y0, y1) - top, 0)
    return dx * dx + dy * dy


def raw_rank(directory, protocol, assets, edited, incident):
    report = shared.read(directory / "geometry.json")
    control = assets["control"]
    definition = shared.verify(report["wire_source"])
    odb = shared.verify(report["placement_source"])
    shared.check(report["placement_source"] == control["odb"] and report["wire_source"] == control["def"]
                 and report["actions"] == shared.ACTIONS and report["incident_nets"] == sorted(incident)
                 and set(report["route_layers"]) == LAYERS and protocol["initial_release_cap"] == 1,
                 "geometry chooser received a different control, action tuple or pool")
    tcl = directory / "geo_bbox.tcl"
    tcl_text = tcl.read_text(encoding="utf-8")
    shared.check(re.findall(r"(?m)^\s*(read_\w+|source) (.+)$", tcl_text) == [("read_db", shared.cmp.tcl(odb))]
                 and "getBBox" in tcl_text and "drt::check_drc" not in tcl_text,
                 "bbox probe accessed more than the frozen ODB")
    log = directory / "geo_bbox.log"
    output = log.read_text(encoding="utf-8")
    boxes = {name: list(map(int, xyz.split())) for name, xyz in
             re.findall(r"(?m)^INST (\S+) ((?:\d+ ){3}\d+)$", output)}
    shared.check("FAECO_GEO_BBOX_DONE" in output and "DBU 1000" in output
                 and boxes == report["instance_boxes_dbu"] and set(boxes) == edited,
                 "producer boxes differ from raw OpenDB probe")
    placements = shared.reconstruct_geometry(protocol)
    width, height = placements["original_size_dbu"]
    for name, (x0, y0, x1, y1) in boxes.items():
        shared.check([x0, y0] == placements["placements"][name]["xy_dbu"]
                     and (x1 - x0, y1 - y0) == (width, height), (name, "DEF/LEF and queried ODB bbox differ"))
    wire, skipped_layers, patch_rectangles = frozen_def_segments(definition)
    eligible = wire.keys() - incident
    best = {net: min((squared_distance(segment, box), instance, segment)
                     for instance, box in boxes.items() for segment in wire[net]) for net in eligible}
    ranking = sorted((entry[0], name) for name, entry in best.items())
    producer = report["ranked_distance_dbu_and_net"]
    shared.check(len(ranking) == len(producer) and all(name == actual_name and math.isclose(
        math.sqrt(square), distance, rel_tol=0, abs_tol=1e-8) for (square, name), (distance, actual_name) in
        zip(ranking, producer, strict=True)), "independent DEF ranking disagrees with producer")
    top_sq, chosen = ranking[0]
    minima = [name for square, name in ranking if square == top_sq]
    oracle_rank = next((idx for idx, (_, name) in enumerate(ranking, 1) if name == "net242"), None)
    shared.check(report["released_neighbors"] == [chosen] and report["minimum_distance_ties"] == minima,
                 "frozen minimum or deterministic tie-break changed")
    return {"raw_geometry_receipt": shared.cmp.bind(directory / "geometry.json"), "source_probe_tcl": shared.cmp.bind(tcl),
            "source_probe_log": shared.cmp.bind(log), "wire_source": control["def"], "placement_source": control["odb"],
            "instance_boxes_dbu_equal_from_def_lef_and_odb": boxes, "candidate_nets": len(ranking),
            "ranked_segment_count": sum(len(wire[name]) for name in eligible), "ignored_higher_layer_runs": skipped_layers,
            "ignored_def_patch_rectangles": patch_rectangles,
            "minimum_distance_dbu": math.sqrt(top_sq), "tied_minima_ranked": minima, "selected": chosen,
            "historical_neighbor_rank": oracle_rank,
            "minimum_distance_witnesses": {name: {"instance": best[name][1], "layer_and_endpoints_dbu": best[name][2]}
                                           for name in minima},
            "rank_digest": sha256(json.dumps(ranking, separators=(",", ":")).encode()).hexdigest(),
            "start_raw": report["start_raw"], "stop_raw": report["stop_raw"], "seconds": report["seconds"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=FRESH)
    parser.add_argument("--rank-only", action="store_true")
    args = parser.parse_args()
    protocol = shared.read(args.root / "protocol.json")
    with shared.bind_runtime("gcd", None):
        inputs = shared.source_and_pool(args.root, protocol)
        assets, _, _, _, edited, incident, _, _, _ = inputs
        arm = args.root / "cell_01/online"
        geometry = raw_rank(arm / "diagnosis/01", protocol, assets, edited, incident)
    if not args.rank_only:
        parser.error("use --rank-only until the complete physical audit is installed")
    print(json.dumps({"geometry": geometry}, indent=2))


if __name__ == "__main__":
    main()

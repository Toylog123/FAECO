read_liberty "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib"
read_db "/home/toylog/faeco_tcad_sky_holdout_20261123/gcd/results/sky130hd/gcd/base/6_final.odb"
read_def -floorplan_initialize "/home/toylog/faeco_tcad_sky_holdout_20261123/gcd_known_neighbor_release_20261127_v2/cell_01/online/01/initial/fixed_wires.def"
write_def "/home/toylog/faeco_tcad_sky_holdout_20261123/gcd_known_neighbor_release_20261127_v2/cell_01/online/01/initial/pre_drt.def"
set fp [open "/home/toylog/faeco_tcad_sky_holdout_20261123/gcd_known_neighbor_release_20261127_v2/cell_01/online/01/initial/pre_drt.def" r]
set snapshot [read $fp]
close $fp
set first [string first "\nNETS " $snapshot]
set last [string first "\nEND NETS" $snapshot]
set observed [regexp -all {[+] FIXED } [string range $snapshot $first $last]]
if {$first < 0 || $last < $first || $observed != 475} {
    error "Expected 475 encoded fixed nets, read back $observed"
}
puts "AES_SELECTIVE_FIXED_READBACK $observed"
unset snapshot
read_sdc "/home/toylog/faeco_tcad_sky_holdout_20261123/gcd/results/sky130hd/gcd/base/6_final.sdc"
if {[llength [all_clocks]] == 0} { error "No clocks in saved SDC" }
source "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/setRC.tcl"
set env(MIN_ROUTING_LAYER) met1
set env(MIN_CLK_ROUTING_LAYER) met3
set env(MAX_ROUTING_LAYER) met5
set env(ROUTING_LAYER_ADJUSTMENT) 0.25
source "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/fastroute.tcl"

set inst [[ord::get_db_block] findInst "_092_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__mux2_4"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "sky130_fd_sc_hd__mux2_1"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "_092_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__mux2_1"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "_093_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__mux2_4"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "sky130_fd_sc_hd__mux2_1"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "_093_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__mux2_1"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "_094_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__mux2_4"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "sky130_fd_sc_hd__mux2_1"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "_094_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__mux2_1"} {
    error "target instance/master mismatch"
}

check_placement -verbose

set nets [dict create]
foreach name [list "_092_" "_093_" "_094_"] {
    set inst [[ord::get_db_block] findInst $name]
    foreach pin [$inst getITerms] {
        set net [$pin getNet]
        if {$net ne "NULL" && [$net getSigType] ni {POWER GROUND}} {
            dict set nets [$net getName] $net
        }
    }
}

foreach name [list "net242"] {
    set net [[ord::get_db_block] findNet $name]
    if {$net eq "NULL" || [$net getSigType] ne "SIGNAL"} {
        error "Released neighbor must be an existing data net: $name"
    }
    dict set nets $name $net
}
set cleared 0
dict for {name net} $nets {
    if {[$net getSigType] in {POWER GROUND}} { continue }
    puts "IBEX_TOUCHED_NET $name"
    set wire [$net getWire]
    if {$wire ne "NULL"} { odb::dbWire_destroy $wire; incr cleared }
}
puts "IBEX_CLEARED_SIGNAL_WIRES $cleared"
if {![grt::have_routes]} {error "No embedded route guides"}
detailed_route -output_drc "/home/toylog/faeco_tcad_sky_holdout_20261123/gcd_known_neighbor_release_20261127_v2/cell_01/online/01/initial/drc.rpt" -verbose 1 -droute_end_iter 64
puts "IBEX_DRT_VIOLATIONS [detailed_route_num_drvs]"
if {![design_is_routed]} { error "Unrouted nets after DRT" }
check_placement -verbose
puts IBEX_DRT_COMPLETE
set antenna [check_antennas -report_file "/home/toylog/faeco_tcad_sky_holdout_20261123/gcd_known_neighbor_release_20261127_v2/cell_01/online/01/initial/antenna.rpt"]
puts "AES_SELECTIVE_ANTENNA $antenna"
drt::check_drc -output_file "/home/toylog/faeco_tcad_sky_holdout_20261123/gcd_known_neighbor_release_20261127_v2/cell_01/online/01/initial/full_drc.rpt"
puts AES_SELECTIVE_FULL_DRC_COMPLETE
set ::env(REPORTS_DIR) "/home/toylog/faeco_tcad_sky_holdout_20261123/gcd_known_neighbor_release_20261127_v2/cell_01/online/01/initial"
source "/home/toylog/faeco_eda/orfs/flow/scripts/util.tcl"
write_verilog "/home/toylog/faeco_tcad_sky_holdout_20261123/gcd_known_neighbor_release_20261127_v2/cell_01/online/01/initial/routed.v" -remove_cells [find_physical_only_masters]
write_def "/home/toylog/faeco_tcad_sky_holdout_20261123/gcd_known_neighbor_release_20261127_v2/cell_01/online/01/initial/routed.def"
write_db "/home/toylog/faeco_tcad_sky_holdout_20261123/gcd_known_neighbor_release_20261127_v2/cell_01/online/01/initial/routed.odb"
define_process_corner -ext_model_index 0 X
extract_parasitics -ext_model_file "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/rcx_patterns.rules"
write_spef "/home/toylog/faeco_tcad_sky_holdout_20261123/gcd_known_neighbor_release_20261127_v2/cell_01/online/01/initial/routed.spef"
puts IBEX_RCX_COMPLETE
puts IBEX_ROUTE_COMPLETE
exit

module gcd (clk,
    req_rdy,
    req_val,
    reset,
    resp_rdy,
    resp_val,
    req_msg,
    resp_msg);
 input clk;
 output req_rdy;
 input req_val;
 input reset;
 input resp_rdy;
 output resp_val;
 input [31:0] req_msg;
 output [15:0] resp_msg;

 wire net_o_273;
 wire net263;
 wire net262;
 wire net261;
 wire net260;
 wire net259;
 wire net258;
 wire net257;
 wire net256;
 wire net255;
 wire net253;
 wire net245;
 wire net244;
 wire net242;
 wire net240;
 wire net_2;
 wire net_1;
 wire _000_;
 wire net39;
 wire net46;
 wire net47;
 wire net48;
 wire net49;
 wire net50;
 wire net51;
 wire net52;
 wire net53;
 wire net54;
 wire net40;
 wire net41;
 wire net42;
 wire net43;
 wire net44;
 wire net45;
 wire \dpath.a_lt_b$in1[0] ;
 wire \dpath.a_lt_b$in1[1] ;
 wire \dpath.a_lt_b$in1[2] ;
 wire \dpath.a_lt_b$in1[3] ;
 wire \dpath.a_lt_b$in1[4] ;
 wire \dpath.a_lt_b$in1[5] ;
 wire \dpath.a_lt_b$in1[6] ;
 wire \dpath.a_lt_b$in1[7] ;
 wire \dpath.a_lt_b$in1[8] ;
 wire \dpath.a_lt_b$in1[9] ;
 wire \dpath.a_lt_b$in1[10] ;
 wire \dpath.a_lt_b$in1[11] ;
 wire \dpath.a_lt_b$in1[12] ;
 wire \dpath.a_lt_b$in1[13] ;
 wire \dpath.a_lt_b$in1[14] ;
 wire \dpath.a_lt_b$in1[15] ;
 wire \dpath.a_lt_b$in0[0] ;
 wire \dpath.a_lt_b$in0[1] ;
 wire \dpath.a_lt_b$in0[2] ;
 wire \dpath.a_lt_b$in0[3] ;
 wire \dpath.a_lt_b$in0[4] ;
 wire \dpath.a_lt_b$in0[5] ;
 wire \dpath.a_lt_b$in0[6] ;
 wire \dpath.a_lt_b$in0[7] ;
 wire \dpath.a_lt_b$in0[8] ;
 wire \dpath.a_lt_b$in0[9] ;
 wire \dpath.a_lt_b$in0[10] ;
 wire \dpath.a_lt_b$in0[11] ;
 wire \dpath.a_lt_b$in0[12] ;
 wire \dpath.a_lt_b$in0[13] ;
 wire \dpath.a_lt_b$in0[14] ;
 wire \dpath.a_lt_b$in0[15] ;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire \ctrl.state.out[1] ;
 wire \ctrl.state.out[2] ;
 wire net3;
 wire net4;
 wire net5;
 wire net6;
 wire net7;
 wire net8;
 wire net9;
 wire net10;
 wire net11;
 wire net12;
 wire net13;
 wire net14;
 wire net15;
 wire net16;
 wire net17;
 wire net18;
 wire net19;
 wire net20;
 wire net21;
 wire net22;
 wire net23;
 wire net24;
 wire net25;
 wire net26;
 wire net27;
 wire net28;
 wire net29;
 wire net30;
 wire net31;
 wire net32;
 wire net33;
 wire net34;
 wire net38;
 wire net35;
 wire net36;
 wire net37;
 wire net55;
 wire net158;
 wire net159;
 wire net160;
 wire net161;
 wire net162;
 wire net163;
 wire net166;
 wire net173;
 wire net172;
 wire net174;
 wire net445;
 wire net182;
 wire net183;
 wire net369;
 wire net200;
 wire net230;
 wire net229;
 wire net228;
 wire net227;
 wire net233;
 wire net232;
 wire net231;
 wire clknet_2_3__leaf_clk;
 wire net234;
 wire net235;
 wire net236;
 wire net237;
 wire net238;
 wire net239;
 wire net241;
 wire clknet_2_2__leaf_clk;
 wire net246;
 wire net247;
 wire net248;
 wire net249;
 wire net250;
 wire net251;
 wire net252;
 wire net254;
 wire net266;
 wire net265;
 wire clknet_2_0__leaf_clk;
 wire clknet_0_clk;
 wire clknet_2_1__leaf_clk;
 wire net157;
 wire net164;
 wire net165;
 wire net167;
 wire net168;
 wire net169;
 wire net170;
 wire net367;
 wire net357;
 wire net370;
 wire net375;
 wire net376;
 wire net382;
 wire net388;

 sky130_fd_sc_hd__clkinv_1 _085_ (.A(\ctrl.state.out[1] ),
    .Y(_082_));
 sky130_fd_sc_hd__clkinv_1 _086_ (.A(\ctrl.state.out[2] ),
    .Y(_083_));
 sky130_fd_sc_hd__o21bai_4 _087_ (.A1(_083_),
    .A2(net_o_273),
    .B1_N(net369),
    .Y(_015_));
 sky130_fd_sc_hd__mux2_4 _088_ (.A0(net262),
    .A1(net9),
    .S(net370),
    .X(_016_));
 sky130_fd_sc_hd__mux2_4 _089_ (.A0(net367),
    .A1(net3),
    .S(net266),
    .X(_017_));
 sky130_fd_sc_hd__mux2_4 _090_ (.A0(net261),
    .A1(net14),
    .S(net266),
    .X(_018_));
 sky130_fd_sc_hd__mux2_4 _091_ (.A0(net260),
    .A1(net25),
    .S(net266),
    .X(_019_));
 sky130_fd_sc_hd__mux2_1 _092_ (.A0(net259),
    .A1(net28),
    .S(net266),
    .X(_020_));
 sky130_fd_sc_hd__mux2_1 _093_ (.A0(net258),
    .A1(net29),
    .S(net266),
    .X(_021_));
 sky130_fd_sc_hd__mux2_1 _094_ (.A0(net257),
    .A1(net30),
    .S(net266),
    .X(_022_));
 sky130_fd_sc_hd__mux2_4 _095_ (.A0(net256),
    .A1(net31),
    .S(net266),
    .X(_023_));
 sky130_fd_sc_hd__mux2_4 _096_ (.A0(net255),
    .A1(net32),
    .S(net370),
    .X(_024_));
 sky130_fd_sc_hd__mux2_4 _097_ (.A0(net254),
    .A1(net33),
    .S(net375),
    .X(_025_));
 sky130_fd_sc_hd__mux2_4 _098_ (.A0(net253),
    .A1(net34),
    .S(net370),
    .X(_026_));
 sky130_fd_sc_hd__mux2_4 _099_ (.A0(\dpath.a_lt_b$in0[10] ),
    .A1(net4),
    .S(net370),
    .X(_027_));
 sky130_fd_sc_hd__mux2_4 _100_ (.A0(\dpath.a_lt_b$in0[11] ),
    .A1(net5),
    .S(net375),
    .X(_028_));
 sky130_fd_sc_hd__mux2_4 _101_ (.A0(net263),
    .A1(net6),
    .S(net375),
    .X(_029_));
 sky130_fd_sc_hd__mux2_4 _102_ (.A0(\dpath.a_lt_b$in0[13] ),
    .A1(net7),
    .S(net375),
    .X(_030_));
 sky130_fd_sc_hd__mux2_4 _103_ (.A0(\dpath.a_lt_b$in0[14] ),
    .A1(net8),
    .S(net375),
    .X(_031_));
 sky130_fd_sc_hd__or2_4 _104_ (.A(\ctrl.state.out[2] ),
    .B(net38),
    .X(_001_));
 sky130_fd_sc_hd__nand2b_1 _105_ (.A_N(net38),
    .B(\ctrl.state.out[2] ),
    .Y(_038_));
 sky130_fd_sc_hd__mux2i_1 _106_ (.A0(net252),
    .A1(net39),
    .S(net166),
    .Y(_039_));
 sky130_fd_sc_hd__nand2_1 _107_ (.A(net10),
    .B(net229),
    .Y(_040_));
 sky130_fd_sc_hd__o21ai_1 _108_ (.A1(net229),
    .A2(_039_),
    .B1(_040_),
    .Y(_032_));
 sky130_fd_sc_hd__mux2i_1 _109_ (.A0(net245),
    .A1(net46),
    .S(net170),
    .Y(_041_));
 sky130_fd_sc_hd__nand2_1 _110_ (.A(net11),
    .B(net229),
    .Y(_042_));
 sky130_fd_sc_hd__o21ai_0 _111_ (.A1(net229),
    .A2(_041_),
    .B1(_042_),
    .Y(_033_));
 sky130_fd_sc_hd__mux2i_1 _112_ (.A0(net244),
    .A1(net47),
    .S(net167),
    .Y(_043_));
 sky130_fd_sc_hd__nand2_1 _113_ (.A(net12),
    .B(net229),
    .Y(_044_));
 sky130_fd_sc_hd__o21ai_1 _114_ (.A1(net229),
    .A2(_043_),
    .B1(_044_),
    .Y(_034_));
 sky130_fd_sc_hd__mux2i_1 _115_ (.A0(net241),
    .A1(net48),
    .S(net170),
    .Y(_045_));
 sky130_fd_sc_hd__nand2_1 _116_ (.A(net13),
    .B(net229),
    .Y(_046_));
 sky130_fd_sc_hd__o21ai_1 _117_ (.A1(net229),
    .A2(_045_),
    .B1(_046_),
    .Y(_035_));
 sky130_fd_sc_hd__mux2i_1 _118_ (.A0(net240),
    .A1(net49),
    .S(net170),
    .Y(_047_));
 sky130_fd_sc_hd__nand2_1 _119_ (.A(net15),
    .B(net229),
    .Y(_048_));
 sky130_fd_sc_hd__o21ai_1 _120_ (.A1(net229),
    .A2(_047_),
    .B1(_048_),
    .Y(_036_));
 sky130_fd_sc_hd__mux2i_1 _121_ (.A0(net239),
    .A1(net50),
    .S(net168),
    .Y(_049_));
 sky130_fd_sc_hd__nand2_1 _122_ (.A(net16),
    .B(net229),
    .Y(_050_));
 sky130_fd_sc_hd__o21ai_0 _123_ (.A1(net229),
    .A2(_049_),
    .B1(_050_),
    .Y(_037_));
 sky130_fd_sc_hd__mux2i_1 _124_ (.A0(net238),
    .A1(net51),
    .S(net168),
    .Y(_051_));
 sky130_fd_sc_hd__nand2_1 _125_ (.A(net17),
    .B(net229),
    .Y(_052_));
 sky130_fd_sc_hd__o21ai_0 _126_ (.A1(net229),
    .A2(_051_),
    .B1(_052_),
    .Y(_002_));
 sky130_fd_sc_hd__mux2i_1 _127_ (.A0(net237),
    .A1(net52),
    .S(net167),
    .Y(_053_));
 sky130_fd_sc_hd__nand2_1 _128_ (.A(net18),
    .B(net229),
    .Y(_054_));
 sky130_fd_sc_hd__o21ai_0 _129_ (.A1(net229),
    .A2(_053_),
    .B1(_054_),
    .Y(_003_));
 sky130_fd_sc_hd__mux2i_1 _130_ (.A0(net236),
    .A1(net53),
    .S(net357),
    .Y(_055_));
 sky130_fd_sc_hd__nand2_1 _131_ (.A(net19),
    .B(net230),
    .Y(_056_));
 sky130_fd_sc_hd__o21ai_0 _132_ (.A1(net230),
    .A2(_055_),
    .B1(_056_),
    .Y(_004_));
 sky130_fd_sc_hd__mux2i_1 _133_ (.A0(net235),
    .A1(net54),
    .S(net169),
    .Y(_057_));
 sky130_fd_sc_hd__nand2_1 _134_ (.A(net20),
    .B(net230),
    .Y(_058_));
 sky130_fd_sc_hd__o21ai_1 _135_ (.A1(net230),
    .A2(_057_),
    .B1(_058_),
    .Y(_005_));
 sky130_fd_sc_hd__mux2i_1 _136_ (.A0(net251),
    .A1(net40),
    .S(net169),
    .Y(_059_));
 sky130_fd_sc_hd__nand2_1 _137_ (.A(net21),
    .B(net230),
    .Y(_060_));
 sky130_fd_sc_hd__o21ai_1 _138_ (.A1(net230),
    .A2(_059_),
    .B1(_060_),
    .Y(_006_));
 sky130_fd_sc_hd__mux2i_1 _139_ (.A0(net250),
    .A1(net41),
    .S(net169),
    .Y(_061_));
 sky130_fd_sc_hd__nand2_1 _140_ (.A(net22),
    .B(net230),
    .Y(_062_));
 sky130_fd_sc_hd__o21ai_1 _141_ (.A1(net230),
    .A2(_061_),
    .B1(_062_),
    .Y(_007_));
 sky130_fd_sc_hd__mux2i_1 _142_ (.A0(net249),
    .A1(net42),
    .S(net168),
    .Y(_063_));
 sky130_fd_sc_hd__nand2_1 _143_ (.A(net23),
    .B(net229),
    .Y(_064_));
 sky130_fd_sc_hd__o21ai_0 _144_ (.A1(net229),
    .A2(_063_),
    .B1(_064_),
    .Y(_008_));
 sky130_fd_sc_hd__mux2i_1 _145_ (.A0(net248),
    .A1(net43),
    .S(net168),
    .Y(_065_));
 sky130_fd_sc_hd__nand2_1 _146_ (.A(net24),
    .B(net229),
    .Y(_066_));
 sky130_fd_sc_hd__o21ai_1 _147_ (.A1(net229),
    .A2(_065_),
    .B1(_066_),
    .Y(_009_));
 sky130_fd_sc_hd__mux2i_1 _148_ (.A0(net247),
    .A1(net44),
    .S(net169),
    .Y(_067_));
 sky130_fd_sc_hd__nand2_1 _149_ (.A(net26),
    .B(net230),
    .Y(_068_));
 sky130_fd_sc_hd__o21ai_0 _150_ (.A1(net230),
    .A2(_067_),
    .B1(_068_),
    .Y(_010_));
 sky130_fd_sc_hd__nor2_2 _151_ (.A(_082_),
    .B(_001_),
    .Y(net55));
 sky130_fd_sc_hd__a221o_1 _152_ (.A1(_078_),
    .A2(net265),
    .B1(net55),
    .B2(net37),
    .C1(net36),
    .X(_011_));
 sky130_fd_sc_hd__nor2b_1 _153_ (.A(net265),
    .B_N(net37),
    .Y(_069_));
 sky130_fd_sc_hd__nor4_1 _154_ (.A(net246),
    .B(net236),
    .C(net235),
    .D(net251),
    .Y(_070_));
 sky130_fd_sc_hd__nor4_1 _155_ (.A(net250),
    .B(net249),
    .C(net248),
    .D(net247),
    .Y(_071_));
 sky130_fd_sc_hd__nor4_1 _156_ (.A(net252),
    .B(net245),
    .C(net244),
    .D(net237),
    .Y(_072_));
 sky130_fd_sc_hd__nor4_1 _157_ (.A(net241),
    .B(net240),
    .C(net239),
    .D(net238),
    .Y(_073_));
 sky130_fd_sc_hd__and4_1 _158_ (.A(_070_),
    .B(net228),
    .C(_072_),
    .D(net227),
    .X(_074_));
 sky130_fd_sc_hd__nand2_1 _159_ (.A(net_o_273),
    .B(_074_),
    .Y(_075_));
 sky130_fd_sc_hd__a21oi_2 _160_ (.A1(net_o_273),
    .A2(_074_),
    .B1(\ctrl.state.out[1] ),
    .Y(_076_));
 sky130_fd_sc_hd__o22ai_1 _161_ (.A1(_082_),
    .A2(_069_),
    .B1(net234),
    .B2(_076_),
    .Y(_077_));
 sky130_fd_sc_hd__clkinv_1 _162_ (.A(net35),
    .Y(_078_));
 sky130_fd_sc_hd__nor2b_1 _163_ (.A(net36),
    .B_N(_077_),
    .Y(_012_));
 sky130_fd_sc_hd__a22oi_1 _164_ (.A1(net35),
    .A2(net265),
    .B1(\ctrl.state.out[2] ),
    .B2(_075_),
    .Y(_079_));
 sky130_fd_sc_hd__nor2_1 _165_ (.A(net36),
    .B(_079_),
    .Y(_013_));
 sky130_fd_sc_hd__mux2i_1 _166_ (.A0(net246),
    .A1(net45),
    .S(net169),
    .Y(_080_));
 sky130_fd_sc_hd__nand2_1 _167_ (.A(net27),
    .B(net230),
    .Y(_081_));
 sky130_fd_sc_hd__o21ai_1 _168_ (.A1(net230),
    .A2(_080_),
    .B1(_081_),
    .Y(_014_));
 \ALU_16_0_16_0_16_unused_CO[14:0]_X_KOGGE_STONE  _169_ (.net_o_272(net_o_273),
    .\dpath.a_lt_b$in0_12_ (net263),
    .\dpath.a_lt_b$in0_9_ (net253),
    .net131_243(net242),
    .\dpath.a_lt_b$in0_11_ (\dpath.a_lt_b$in0[11] ),
    .\dpath.a_lt_b$in0_15_ (net262),
    .\dpath.a_lt_b$in0_1_ (net261),
    .\dpath.a_lt_b$in0_2_ (net260),
    .\dpath.a_lt_b$in0_3_ (net259),
    .\dpath.a_lt_b$in0_4_ (net258),
    .\dpath.a_lt_b$in0_5_ (net257),
    .\dpath.a_lt_b$in0_6_ (net256),
    .\dpath.a_lt_b$in0_7_ (net255),
    .\dpath.a_lt_b$in0_8_ (\dpath.a_lt_b$in0[8] ),
    .\dpath.a_lt_b$in1_1_ (net245),
    .\dpath.a_lt_b$in1_2_ (net244),
    .\dpath.a_lt_b$in1_4_ (net240),
    .A({\dpath.a_lt_b$in0[15] ,
    \dpath.a_lt_b$in0[14] ,
    \dpath.a_lt_b$in0[13] ,
    \dpath.a_lt_b$in0[12] ,
    \dpath.a_lt_b$in0[11] ,
    \dpath.a_lt_b$in0[10] ,
    \dpath.a_lt_b$in0[9] ,
    \dpath.a_lt_b$in0[8] ,
    \dpath.a_lt_b$in0[7] ,
    \dpath.a_lt_b$in0[6] ,
    \dpath.a_lt_b$in0[5] ,
    \dpath.a_lt_b$in0[4] ,
    \dpath.a_lt_b$in0[3] ,
    \dpath.a_lt_b$in0[2] ,
    \dpath.a_lt_b$in0[1] ,
    \dpath.a_lt_b$in0[0] }),
    .B({\dpath.a_lt_b$in1[15] ,
    \dpath.a_lt_b$in1[14] ,
    \dpath.a_lt_b$in1[13] ,
    \dpath.a_lt_b$in1[12] ,
    \dpath.a_lt_b$in1[11] ,
    \dpath.a_lt_b$in1[10] ,
    \dpath.a_lt_b$in1[9] ,
    \dpath.a_lt_b$in1[8] ,
    \dpath.a_lt_b$in1[7] ,
    \dpath.a_lt_b$in1[6] ,
    \dpath.a_lt_b$in1[5] ,
    \dpath.a_lt_b$in1[4] ,
    \dpath.a_lt_b$in1[3] ,
    \dpath.a_lt_b$in1[2] ,
    \dpath.a_lt_b$in1[1] ,
    \dpath.a_lt_b$in1[0] }),
    .BI(net_1),
    .CI(net_2),
    .Y({net45,
    net44,
    net43,
    net42,
    net41,
    net40,
    net54,
    net53,
    net52,
    net51,
    net50,
    net49,
    net48,
    net47,
    net46,
    net39}),
    .\CO[15] (_000_));
 sky130_fd_sc_hd__conb_1 _169__1 (.HI(net_1));
 sky130_fd_sc_hd__conb_1 _169__2 (.HI(net_2));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_0_clk (.A(clk),
    .X(clknet_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_2_0__f_clk (.A(clknet_0_clk),
    .X(clknet_2_0__leaf_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_2_1__f_clk (.A(clknet_0_clk),
    .X(clknet_2_1__leaf_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_2_2__f_clk (.A(clknet_0_clk),
    .X(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_2_3__f_clk (.A(clknet_0_clk),
    .X(clknet_2_3__leaf_clk));
 sky130_fd_sc_hd__bufinv_16 clkload0 (.A(clknet_2_0__leaf_clk));
 sky130_fd_sc_hd__clkbuf_8 clkload1 (.A(clknet_2_1__leaf_clk));
 sky130_fd_sc_hd__clkinv_2 clkload2 (.A(clknet_2_3__leaf_clk));
 sky130_fd_sc_hd__bufbuf_16 clone365 (.A(net38),
    .X(net370));
 sky130_fd_sc_hd__dfxtp_4 \ctrl.state.out[0]$_DFF_P_  (.D(_011_),
    .Q(net38),
    .CLK(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 \ctrl.state.out[1]$_DFF_P_  (.D(_012_),
    .Q(\ctrl.state.out[1] ),
    .CLK(clknet_2_0__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 \ctrl.state.out[2]$_DFF_P_  (.D(_013_),
    .Q(\ctrl.state.out[2] ),
    .CLK(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.a_reg.out[0]$_DFFE_PP_  (.D(_032_),
    .DE(net233),
    .Q(\dpath.a_lt_b$in0[0] ),
    .CLK(clknet_2_0__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.a_reg.out[10]$_DFFE_PP_  (.D(_006_),
    .DE(net231),
    .Q(\dpath.a_lt_b$in0[10] ),
    .CLK(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.a_reg.out[11]$_DFFE_PP_  (.D(_007_),
    .DE(net231),
    .Q(\dpath.a_lt_b$in0[11] ),
    .CLK(clknet_2_3__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.a_reg.out[12]$_DFFE_PP_  (.D(_008_),
    .DE(net233),
    .Q(\dpath.a_lt_b$in0[12] ),
    .CLK(clknet_2_3__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.a_reg.out[13]$_DFFE_PP_  (.D(_009_),
    .DE(net233),
    .Q(\dpath.a_lt_b$in0[13] ),
    .CLK(clknet_2_3__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.a_reg.out[14]$_DFFE_PP_  (.D(_010_),
    .DE(net231),
    .Q(\dpath.a_lt_b$in0[14] ),
    .CLK(clknet_2_3__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.a_reg.out[15]$_DFFE_PP_  (.D(_014_),
    .DE(net231),
    .Q(\dpath.a_lt_b$in0[15] ),
    .CLK(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.a_reg.out[1]$_DFFE_PP_  (.D(_033_),
    .DE(net233),
    .Q(\dpath.a_lt_b$in0[1] ),
    .CLK(clknet_2_0__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.a_reg.out[2]$_DFFE_PP_  (.D(_034_),
    .DE(net232),
    .Q(\dpath.a_lt_b$in0[2] ),
    .CLK(clknet_2_0__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.a_reg.out[3]$_DFFE_PP_  (.D(_035_),
    .DE(net233),
    .Q(\dpath.a_lt_b$in0[3] ),
    .CLK(clknet_2_1__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.a_reg.out[4]$_DFFE_PP_  (.D(_036_),
    .DE(net233),
    .Q(\dpath.a_lt_b$in0[4] ),
    .CLK(clknet_2_1__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.a_reg.out[5]$_DFFE_PP_  (.D(_037_),
    .DE(net233),
    .Q(\dpath.a_lt_b$in0[5] ),
    .CLK(clknet_2_1__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.a_reg.out[6]$_DFFE_PP_  (.D(_002_),
    .DE(net233),
    .Q(\dpath.a_lt_b$in0[6] ),
    .CLK(clknet_2_1__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.a_reg.out[7]$_DFFE_PP_  (.D(_003_),
    .DE(net232),
    .Q(\dpath.a_lt_b$in0[7] ),
    .CLK(clknet_2_0__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.a_reg.out[8]$_DFFE_PP_  (.D(_004_),
    .DE(net231),
    .Q(\dpath.a_lt_b$in0[8] ),
    .CLK(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.a_reg.out[9]$_DFFE_PP_  (.D(_005_),
    .DE(net231),
    .Q(\dpath.a_lt_b$in0[9] ),
    .CLK(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.b_reg.out[0]$_DFFE_PP_  (.D(_017_),
    .DE(net157),
    .Q(\dpath.a_lt_b$in1[0] ),
    .CLK(clknet_2_0__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.b_reg.out[10]$_DFFE_PP_  (.D(_027_),
    .DE(net157),
    .Q(\dpath.a_lt_b$in1[10] ),
    .CLK(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.b_reg.out[11]$_DFFE_PP_  (.D(_028_),
    .DE(net157),
    .Q(\dpath.a_lt_b$in1[11] ),
    .CLK(clknet_2_3__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.b_reg.out[12]$_DFFE_PP_  (.D(_029_),
    .DE(net157),
    .Q(\dpath.a_lt_b$in1[12] ),
    .CLK(clknet_2_3__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.b_reg.out[13]$_DFFE_PP_  (.D(_030_),
    .DE(net157),
    .Q(\dpath.a_lt_b$in1[13] ),
    .CLK(clknet_2_3__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.b_reg.out[14]$_DFFE_PP_  (.D(_031_),
    .DE(net157),
    .Q(\dpath.a_lt_b$in1[14] ),
    .CLK(clknet_2_3__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.b_reg.out[15]$_DFFE_PP_  (.D(_016_),
    .DE(net157),
    .Q(\dpath.a_lt_b$in1[15] ),
    .CLK(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.b_reg.out[1]$_DFFE_PP_  (.D(_018_),
    .DE(net157),
    .Q(\dpath.a_lt_b$in1[1] ),
    .CLK(clknet_2_1__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.b_reg.out[2]$_DFFE_PP_  (.D(_019_),
    .DE(net157),
    .Q(\dpath.a_lt_b$in1[2] ),
    .CLK(clknet_2_0__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.b_reg.out[3]$_DFFE_PP_  (.D(_020_),
    .DE(net157),
    .Q(\dpath.a_lt_b$in1[3] ),
    .CLK(clknet_2_1__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.b_reg.out[4]$_DFFE_PP_  (.D(_021_),
    .DE(net157),
    .Q(\dpath.a_lt_b$in1[4] ),
    .CLK(clknet_2_1__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.b_reg.out[5]$_DFFE_PP_  (.D(_022_),
    .DE(net157),
    .Q(\dpath.a_lt_b$in1[5] ),
    .CLK(clknet_2_1__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.b_reg.out[6]$_DFFE_PP_  (.D(_023_),
    .DE(net157),
    .Q(\dpath.a_lt_b$in1[6] ),
    .CLK(clknet_2_1__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.b_reg.out[7]$_DFFE_PP_  (.D(_024_),
    .DE(net157),
    .Q(\dpath.a_lt_b$in1[7] ),
    .CLK(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.b_reg.out[8]$_DFFE_PP_  (.D(_025_),
    .DE(net157),
    .Q(\dpath.a_lt_b$in1[8] ),
    .CLK(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__edfxtp_1 \dpath.b_reg.out[9]$_DFFE_PP_  (.D(_026_),
    .DE(net157),
    .Q(\dpath.a_lt_b$in1[9] ),
    .CLK(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__buf_1 input10 (.A(req_msg[16]),
    .X(net10));
 sky130_fd_sc_hd__buf_1 input11 (.A(req_msg[17]),
    .X(net11));
 sky130_fd_sc_hd__buf_1 input12 (.A(req_msg[18]),
    .X(net12));
 sky130_fd_sc_hd__buf_1 input13 (.A(req_msg[19]),
    .X(net13));
 sky130_fd_sc_hd__buf_1 input14 (.A(req_msg[1]),
    .X(net14));
 sky130_fd_sc_hd__buf_1 input15 (.A(req_msg[20]),
    .X(net15));
 sky130_fd_sc_hd__buf_1 input16 (.A(req_msg[21]),
    .X(net16));
 sky130_fd_sc_hd__buf_1 input17 (.A(req_msg[22]),
    .X(net17));
 sky130_fd_sc_hd__buf_1 input18 (.A(req_msg[23]),
    .X(net18));
 sky130_fd_sc_hd__buf_1 input19 (.A(req_msg[24]),
    .X(net19));
 sky130_fd_sc_hd__buf_1 input20 (.A(req_msg[25]),
    .X(net20));
 sky130_fd_sc_hd__buf_1 input21 (.A(req_msg[26]),
    .X(net21));
 sky130_fd_sc_hd__buf_1 input22 (.A(req_msg[27]),
    .X(net22));
 sky130_fd_sc_hd__buf_1 input23 (.A(req_msg[28]),
    .X(net23));
 sky130_fd_sc_hd__buf_1 input24 (.A(req_msg[29]),
    .X(net24));
 sky130_fd_sc_hd__buf_1 input25 (.A(req_msg[2]),
    .X(net25));
 sky130_fd_sc_hd__buf_1 input26 (.A(req_msg[30]),
    .X(net26));
 sky130_fd_sc_hd__buf_1 input27 (.A(req_msg[31]),
    .X(net27));
 sky130_fd_sc_hd__buf_1 input28 (.A(req_msg[3]),
    .X(net28));
 sky130_fd_sc_hd__buf_1 input29 (.A(req_msg[4]),
    .X(net29));
 sky130_fd_sc_hd__buf_1 input3 (.A(req_msg[0]),
    .X(net3));
 sky130_fd_sc_hd__buf_1 input30 (.A(req_msg[5]),
    .X(net30));
 sky130_fd_sc_hd__buf_1 input31 (.A(req_msg[6]),
    .X(net31));
 sky130_fd_sc_hd__buf_1 input32 (.A(req_msg[7]),
    .X(net32));
 sky130_fd_sc_hd__buf_1 input33 (.A(req_msg[8]),
    .X(net33));
 sky130_fd_sc_hd__buf_1 input34 (.A(req_msg[9]),
    .X(net34));
 sky130_fd_sc_hd__buf_1 input35 (.A(req_val),
    .X(net35));
 sky130_fd_sc_hd__buf_1 input36 (.A(reset),
    .X(net36));
 sky130_fd_sc_hd__buf_1 input37 (.A(resp_rdy),
    .X(net37));
 sky130_fd_sc_hd__buf_1 input4 (.A(req_msg[10]),
    .X(net4));
 sky130_fd_sc_hd__buf_1 input5 (.A(req_msg[11]),
    .X(net5));
 sky130_fd_sc_hd__buf_1 input6 (.A(req_msg[12]),
    .X(net6));
 sky130_fd_sc_hd__buf_1 input7 (.A(req_msg[13]),
    .X(net7));
 sky130_fd_sc_hd__buf_1 input8 (.A(req_msg[14]),
    .X(net8));
 sky130_fd_sc_hd__buf_1 input9 (.A(req_msg[15]),
    .X(net9));
 sky130_fd_sc_hd__buf_1 output38 (.A(net376),
    .X(req_rdy));
 sky130_fd_sc_hd__buf_1 output39 (.A(net39),
    .X(resp_msg[0]));
 sky130_fd_sc_hd__buf_1 output40 (.A(net163),
    .X(resp_msg[10]));
 sky130_fd_sc_hd__buf_1 output41 (.A(net162),
    .X(resp_msg[11]));
 sky130_fd_sc_hd__buf_1 output42 (.A(net161),
    .X(resp_msg[12]));
 sky130_fd_sc_hd__buf_1 output43 (.A(net160),
    .X(resp_msg[13]));
 sky130_fd_sc_hd__buf_1 output44 (.A(net159),
    .X(resp_msg[14]));
 sky130_fd_sc_hd__buf_1 output45 (.A(net158),
    .X(resp_msg[15]));
 sky130_fd_sc_hd__buf_1 output46 (.A(net200),
    .X(resp_msg[1]));
 sky130_fd_sc_hd__buf_1 output47 (.A(net183),
    .X(resp_msg[2]));
 sky130_fd_sc_hd__buf_1 output48 (.A(net182),
    .X(resp_msg[3]));
 sky130_fd_sc_hd__buf_1 output49 (.A(net174),
    .X(resp_msg[4]));
 sky130_fd_sc_hd__buf_1 output50 (.A(net173),
    .X(resp_msg[5]));
 sky130_fd_sc_hd__buf_1 output51 (.A(net51),
    .X(resp_msg[6]));
 sky130_fd_sc_hd__buf_1 output52 (.A(net172),
    .X(resp_msg[7]));
 sky130_fd_sc_hd__buf_1 output53 (.A(net165),
    .X(resp_msg[8]));
 sky130_fd_sc_hd__buf_1 output54 (.A(net164),
    .X(resp_msg[9]));
 sky130_fd_sc_hd__buf_1 output55 (.A(net55),
    .X(resp_val));
 sky130_fd_sc_hd__buf_12 place157 (.A(_015_),
    .X(net157));
 sky130_fd_sc_hd__buf_4 place158 (.A(net45),
    .X(net158));
 sky130_fd_sc_hd__buf_4 place159 (.A(net44),
    .X(net159));
 sky130_fd_sc_hd__buf_4 place160 (.A(net43),
    .X(net160));
 sky130_fd_sc_hd__buf_4 place161 (.A(net42),
    .X(net161));
 sky130_fd_sc_hd__buf_4 place162 (.A(net41),
    .X(net162));
 sky130_fd_sc_hd__buf_4 place163 (.A(net40),
    .X(net163));
 sky130_fd_sc_hd__buf_4 place164 (.A(net54),
    .X(net164));
 sky130_fd_sc_hd__buf_4 place165 (.A(net53),
    .X(net165));
 sky130_fd_sc_hd__buf_6 place166 (.A(_000_),
    .X(net166));
 sky130_fd_sc_hd__buf_8 place167 (.A(_000_),
    .X(net167));
 sky130_fd_sc_hd__buf_8 place168 (.A(_000_),
    .X(net168));
 sky130_fd_sc_hd__buf_12 place169 (.A(_000_),
    .X(net169));
 sky130_fd_sc_hd__buf_8 place170 (.A(_000_),
    .X(net170));
 sky130_fd_sc_hd__buf_4 place172 (.A(net52),
    .X(net172));
 sky130_fd_sc_hd__buf_6 place173 (.A(net50),
    .X(net173));
 sky130_fd_sc_hd__buf_4 place174 (.A(net49),
    .X(net174));
 sky130_fd_sc_hd__buf_4 place182 (.A(net48),
    .X(net182));
 sky130_fd_sc_hd__buf_6 place183 (.A(net47),
    .X(net183));
 sky130_fd_sc_hd__buf_6 place200 (.A(net46),
    .X(net200));
 sky130_fd_sc_hd__buf_4 place227 (.A(_073_),
    .X(net227));
 sky130_fd_sc_hd__buf_4 place228 (.A(_071_),
    .X(net228));
 sky130_fd_sc_hd__buf_12 place229 (.A(_038_),
    .X(net229));
 sky130_fd_sc_hd__buf_4 place230 (.A(_038_),
    .X(net230));
 sky130_fd_sc_hd__buf_12 place231 (.A(_001_),
    .X(net231));
 sky130_fd_sc_hd__buf_4 place232 (.A(_001_),
    .X(net232));
 sky130_fd_sc_hd__buf_12 place233 (.A(_001_),
    .X(net233));
 sky130_fd_sc_hd__buf_4 place234 (.A(_083_),
    .X(net234));
 sky130_fd_sc_hd__buf_4 place235 (.A(\dpath.a_lt_b$in1[9] ),
    .X(net235));
 sky130_fd_sc_hd__buf_4 place236 (.A(\dpath.a_lt_b$in1[8] ),
    .X(net236));
 sky130_fd_sc_hd__buf_4 place237 (.A(\dpath.a_lt_b$in1[7] ),
    .X(net237));
 sky130_fd_sc_hd__buf_4 place238 (.A(\dpath.a_lt_b$in1[6] ),
    .X(net238));
 sky130_fd_sc_hd__buf_4 place239 (.A(\dpath.a_lt_b$in1[5] ),
    .X(net239));
 sky130_fd_sc_hd__buf_4 place240 (.A(\dpath.a_lt_b$in1[4] ),
    .X(net240));
 sky130_fd_sc_hd__buf_4 place241 (.A(net242),
    .X(net241));
 sky130_fd_sc_hd__buf_4 place242 (.A(\dpath.a_lt_b$in1[3] ),
    .X(net242));
 sky130_fd_sc_hd__buf_4 place243 (.A(net382),
    .X(net244));
 sky130_fd_sc_hd__buf_4 place244 (.A(\dpath.a_lt_b$in1[1] ),
    .X(net245));
 sky130_fd_sc_hd__buf_4 place245 (.A(\dpath.a_lt_b$in1[15] ),
    .X(net246));
 sky130_fd_sc_hd__buf_4 place246 (.A(\dpath.a_lt_b$in1[14] ),
    .X(net247));
 sky130_fd_sc_hd__buf_4 place247 (.A(\dpath.a_lt_b$in1[13] ),
    .X(net248));
 sky130_fd_sc_hd__buf_4 place248 (.A(\dpath.a_lt_b$in1[12] ),
    .X(net249));
 sky130_fd_sc_hd__buf_4 place249 (.A(\dpath.a_lt_b$in1[11] ),
    .X(net250));
 sky130_fd_sc_hd__buf_4 place250 (.A(net445),
    .X(net251));
 sky130_fd_sc_hd__buf_4 place251 (.A(net388),
    .X(net252));
 sky130_fd_sc_hd__buf_4 place252 (.A(\dpath.a_lt_b$in0[9] ),
    .X(net253));
 sky130_fd_sc_hd__buf_6 place253 (.A(\dpath.a_lt_b$in0[8] ),
    .X(net254));
 sky130_fd_sc_hd__buf_6 place254 (.A(\dpath.a_lt_b$in0[7] ),
    .X(net255));
 sky130_fd_sc_hd__buf_6 place255 (.A(\dpath.a_lt_b$in0[6] ),
    .X(net256));
 sky130_fd_sc_hd__buf_6 place256 (.A(\dpath.a_lt_b$in0[5] ),
    .X(net257));
 sky130_fd_sc_hd__buf_4 place257 (.A(\dpath.a_lt_b$in0[4] ),
    .X(net258));
 sky130_fd_sc_hd__buf_4 place258 (.A(\dpath.a_lt_b$in0[3] ),
    .X(net259));
 sky130_fd_sc_hd__buf_4 place259 (.A(\dpath.a_lt_b$in0[2] ),
    .X(net260));
 sky130_fd_sc_hd__buf_4 place260 (.A(\dpath.a_lt_b$in0[1] ),
    .X(net261));
 sky130_fd_sc_hd__buf_4 place261 (.A(\dpath.a_lt_b$in0[15] ),
    .X(net262));
 sky130_fd_sc_hd__buf_4 place262 (.A(\dpath.a_lt_b$in0[12] ),
    .X(net263));
 sky130_fd_sc_hd__buf_4 place264 (.A(net369),
    .X(net265));
 sky130_fd_sc_hd__buf_12 place265 (.A(net38),
    .X(net266));
 sky130_fd_sc_hd__buf_6 rebuffer352 (.A(net_o_273),
    .X(net357));
 sky130_fd_sc_hd__buf_4 rebuffer362 (.A(\dpath.a_lt_b$in0[0] ),
    .X(net367));
 sky130_fd_sc_hd__buf_4 rebuffer364 (.A(net38),
    .X(net369));
 sky130_fd_sc_hd__buf_12 rebuffer370 (.A(net38),
    .X(net375));
 sky130_fd_sc_hd__buf_4 rebuffer371 (.A(net370),
    .X(net376));
 sky130_fd_sc_hd__buf_4 rebuffer377 (.A(\dpath.a_lt_b$in1[2] ),
    .X(net382));
 sky130_fd_sc_hd__buf_4 rebuffer383 (.A(\dpath.a_lt_b$in1[0] ),
    .X(net388));
 sky130_fd_sc_hd__buf_4 rebuffer440 (.A(\dpath.a_lt_b$in1[10] ),
    .X(net445));
endmodule
module \ALU_16_0_16_0_16_unused_CO[14:0]_X_KOGGE_STONE  (net_o_272,
    \dpath.a_lt_b$in0_12_ ,
    \dpath.a_lt_b$in0_9_ ,
    net131_243,
    \dpath.a_lt_b$in0_11_ ,
    \dpath.a_lt_b$in0_15_ ,
    \dpath.a_lt_b$in0_1_ ,
    \dpath.a_lt_b$in0_2_ ,
    \dpath.a_lt_b$in0_3_ ,
    \dpath.a_lt_b$in0_4_ ,
    \dpath.a_lt_b$in0_5_ ,
    \dpath.a_lt_b$in0_6_ ,
    \dpath.a_lt_b$in0_7_ ,
    \dpath.a_lt_b$in0_8_ ,
    \dpath.a_lt_b$in1_1_ ,
    \dpath.a_lt_b$in1_2_ ,
    \dpath.a_lt_b$in1_4_ ,
    A,
    B,
    BI,
    CI,
    Y,
    \CO[15] );
 output net_o_272;
 input \dpath.a_lt_b$in0_12_ ;
 input \dpath.a_lt_b$in0_9_ ;
 input net131_243;
 input \dpath.a_lt_b$in0_11_ ;
 input \dpath.a_lt_b$in0_15_ ;
 input \dpath.a_lt_b$in0_1_ ;
 input \dpath.a_lt_b$in0_2_ ;
 input \dpath.a_lt_b$in0_3_ ;
 input \dpath.a_lt_b$in0_4_ ;
 input \dpath.a_lt_b$in0_5_ ;
 input \dpath.a_lt_b$in0_6_ ;
 input \dpath.a_lt_b$in0_7_ ;
 input \dpath.a_lt_b$in0_8_ ;
 input \dpath.a_lt_b$in1_1_ ;
 input \dpath.a_lt_b$in1_2_ ;
 input \dpath.a_lt_b$in1_4_ ;
 input [15:0] A;
 input [15:0] B;
 input BI;
 input CI;
 output [15:0] Y;
 output \CO[15] ;

 wire _033_;
 wire _032_;
 wire _031_;
 wire _030_;
 wire _029_;
 wire _028_;
 wire _027_;
 wire _026_;
 wire _023_;
 wire _022_;
 wire _021_;
 wire _020_;
 wire _019_;
 wire _018_;
 wire _017_;
 wire _016_;
 wire _015_;
 wire _014_;
 wire _013_;
 wire _012_;
 wire _011_;
 wire _010_;
 wire _009_;
 wire _008_;
 wire _007_;
 wire _006_;
 wire _005_;
 wire _004_;
 wire _003_;
 wire _002_;
 wire _001_;
 wire _000_;
 wire _126_;
 wire _125_;
 wire _124_;
 wire _123_;
 wire _122_;
 wire _121_;
 wire _120_;
 wire _119_;
 wire _118_;
 wire _117_;
 wire _116_;
 wire _115_;
 wire _087_;
 wire _024_;
 wire _025_;
 wire _039_;
 wire _114_;
 wire _076_;
 wire _113_;
 wire _109_;
 wire _093_;
 wire _112_;
 wire _107_;
 wire _108_;
 wire _098_;
 wire _111_;
 wire _110_;
 wire _073_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _074_;
 wire _075_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire _105_;
 wire _106_;
 wire net185;
 wire net457;
 wire net348;
 wire net175;
 wire net176;
 wire net177;
 wire net179;
 wire net180;
 wire net184;
 wire net186;
 wire net187;
 wire net188;
 wire net191;
 wire net192;
 wire net193;
 wire net195;
 wire net197;
 wire net198;
 wire net206;
 wire net202;
 wire net201;
 wire net203;
 wire net204;
 wire net205;
 wire net208;
 wire net209;
 wire net210;
 wire net212;
 wire net213;
 wire net214;
 wire net215;
 wire net216;
 wire net217;
 wire net218;
 wire net219;
 wire net220;
 wire net221;
 wire net222;
 wire net224;
 wire net225;
 wire net226;
 wire net189;
 wire net190;
 wire net194;
 wire net196;
 wire net207;
 wire net211;
 wire net267;
 wire net277;
 wire net465;
 wire net281;
 wire net282;
 wire net446;
 wire net356;
 wire net383;
 wire net389;
 wire net390;
 wire net441;
 wire net447;

 sky130_fd_sc_hd__nor2_4 _127_ (.A(_073_),
    .B(_110_),
    .Y(_111_));
 sky130_fd_sc_hd__o21ai_0 _128_ (.A1(_098_),
    .A2(_108_),
    .B1(_107_),
    .Y(_112_));
 sky130_fd_sc_hd__a21oi_2 _129_ (.A1(_093_),
    .A2(_109_),
    .B1(_112_),
    .Y(_113_));
 sky130_fd_sc_hd__o21ai_4 _130_ (.A1(_076_),
    .A2(_110_),
    .B1(_113_),
    .Y(_114_));
 sky130_fd_sc_hd__a21o_4 _131_ (.A1(_039_),
    .A2(_111_),
    .B1(_114_),
    .X(\CO[15] ));
 sky130_fd_sc_hd__xnor3_1 _132_ (.A(_025_),
    .B(net221),
    .C(net218),
    .X(Y[0]));
 sky130_fd_sc_hd__maj3_2 _133_ (.A(_087_),
    .B(_024_),
    .C(_025_),
    .X(_115_));
 sky130_fd_sc_hd__nor2_1 _134_ (.A(BI),
    .B(\dpath.a_lt_b$in1_1_ ),
    .Y(_116_));
 sky130_fd_sc_hd__nand2_1 _135_ (.A(BI),
    .B(\dpath.a_lt_b$in1_1_ ),
    .Y(_117_));
 sky130_fd_sc_hd__nand3b_1 _136_ (.A_N(_116_),
    .B(_117_),
    .C(\dpath.a_lt_b$in0_1_ ),
    .Y(_118_));
 sky130_fd_sc_hd__xnor3_2 _137_ (.A(BI),
    .B(B[1]),
    .C(A[1]),
    .X(_119_));
 sky130_fd_sc_hd__xor2_2 _138_ (.A(net226),
    .B(_115_),
    .X(Y[1]));
 sky130_fd_sc_hd__o21ai_4 _139_ (.A1(_119_),
    .A2(_115_),
    .B1(_118_),
    .Y(_120_));
 sky130_fd_sc_hd__xor2_1 _140_ (.A(BI),
    .B(\dpath.a_lt_b$in1_2_ ),
    .X(_121_));
 sky130_fd_sc_hd__nand2_1 _141_ (.A(\dpath.a_lt_b$in0_2_ ),
    .B(_121_),
    .Y(_122_));
 sky130_fd_sc_hd__xnor3_2 _142_ (.A(BI),
    .B(B[2]),
    .C(A[2]),
    .X(_123_));
 sky130_fd_sc_hd__xnor2_4 _143_ (.A(net225),
    .B(net457),
    .Y(Y[2]));
 sky130_fd_sc_hd__or2_4 _144_ (.A(_123_),
    .B(_119_),
    .X(_124_));
 sky130_fd_sc_hd__nand4bb_4 _145_ (.A_N(_116_),
    .B_N(_123_),
    .C(_117_),
    .D(\dpath.a_lt_b$in0_1_ ),
    .Y(_125_));
 sky130_fd_sc_hd__o211ai_4 _146_ (.A1(net217),
    .A2(_124_),
    .B1(_125_),
    .C1(net216),
    .Y(_126_));
 sky130_fd_sc_hd__xor2_1 _147_ (.A(BI),
    .B(net131_243),
    .X(_000_));
 sky130_fd_sc_hd__nand2_1 _148_ (.A(\dpath.a_lt_b$in0_3_ ),
    .B(_000_),
    .Y(_001_));
 sky130_fd_sc_hd__xnor3_2 _149_ (.A(BI),
    .B(A[3]),
    .C(B[3]),
    .X(_002_));
 sky130_fd_sc_hd__xnor2_1 _150_ (.A(net198),
    .B(net224),
    .Y(Y[3]));
 sky130_fd_sc_hd__nor2_4 _151_ (.A(net282),
    .B(net224),
    .Y(_003_));
 sky130_fd_sc_hd__o21ai_2 _152_ (.A1(_122_),
    .A2(_002_),
    .B1(_001_),
    .Y(_004_));
 sky130_fd_sc_hd__a21oi_4 _153_ (.A1(_120_),
    .A2(_003_),
    .B1(_004_),
    .Y(_005_));
 sky130_fd_sc_hd__xor2_1 _154_ (.A(BI),
    .B(\dpath.a_lt_b$in1_4_ ),
    .X(_006_));
 sky130_fd_sc_hd__nand2_1 _155_ (.A(\dpath.a_lt_b$in0_4_ ),
    .B(_006_),
    .Y(_007_));
 sky130_fd_sc_hd__xnor3_2 _156_ (.A(BI),
    .B(A[4]),
    .C(B[4]),
    .X(_008_));
 sky130_fd_sc_hd__xor2_1 _157_ (.A(_008_),
    .B(net389),
    .X(Y[4]));
 sky130_fd_sc_hd__xor2_4 _158_ (.A(BI),
    .B(B[5]),
    .X(_009_));
 sky130_fd_sc_hd__nand2_4 _159_ (.A(\dpath.a_lt_b$in0_5_ ),
    .B(net390),
    .Y(_010_));
 sky130_fd_sc_hd__clkinv_1 _160_ (.A(CI),
    .Y(_025_));
 sky130_fd_sc_hd__xnor2_4 _161_ (.A(A[5]),
    .B(_009_),
    .Y(_011_));
 sky130_fd_sc_hd__or2_4 _162_ (.A(_002_),
    .B(_008_),
    .X(_012_));
 sky130_fd_sc_hd__o21ai_1 _163_ (.A1(_001_),
    .A2(_008_),
    .B1(_007_),
    .Y(_013_));
 sky130_fd_sc_hd__nor3_4 _164_ (.A(net217),
    .B(_124_),
    .C(net214),
    .Y(_014_));
 sky130_fd_sc_hd__a21oi_2 _165_ (.A1(net216),
    .A2(_125_),
    .B1(net214),
    .Y(_015_));
 sky130_fd_sc_hd__nor3_2 _166_ (.A(_013_),
    .B(net196),
    .C(net197),
    .Y(_016_));
 sky130_fd_sc_hd__xor2_2 _167_ (.A(net447),
    .B(_016_),
    .X(Y[5]));
 sky130_fd_sc_hd__nor2_4 _168_ (.A(_008_),
    .B(_011_),
    .Y(_017_));
 sky130_fd_sc_hd__nor4_1 _169_ (.A(_123_),
    .B(_002_),
    .C(_008_),
    .D(_011_),
    .Y(_018_));
 sky130_fd_sc_hd__o21ai_4 _170_ (.A1(_007_),
    .A2(_011_),
    .B1(_010_),
    .Y(_019_));
 sky130_fd_sc_hd__a221oi_2 _171_ (.A1(_004_),
    .A2(_017_),
    .B1(_018_),
    .B2(net281),
    .C1(_019_),
    .Y(_020_));
 sky130_fd_sc_hd__xor2_4 _172_ (.A(BI),
    .B(B[6]),
    .X(_021_));
 sky130_fd_sc_hd__nand2_1 _173_ (.A(net465),
    .B(net222),
    .Y(_022_));
 sky130_fd_sc_hd__clkinv_2 _174_ (.A(A[0]),
    .Y(_024_));
 sky130_fd_sc_hd__xnor2_4 _175_ (.A(A[6]),
    .B(_021_),
    .Y(_023_));
 sky130_fd_sc_hd__xor2_1 _176_ (.A(net180),
    .B(net213),
    .X(Y[6]));
 sky130_fd_sc_hd__nor2_1 _177_ (.A(_011_),
    .B(_023_),
    .Y(_026_));
 sky130_fd_sc_hd__nor3_4 _178_ (.A(net215),
    .B(_012_),
    .C(_023_),
    .Y(_027_));
 sky130_fd_sc_hd__o211ai_1 _179_ (.A1(\dpath.a_lt_b$in0_6_ ),
    .A2(net222),
    .B1(net390),
    .C1(\dpath.a_lt_b$in0_5_ ),
    .Y(_028_));
 sky130_fd_sc_hd__nand2_1 _180_ (.A(_022_),
    .B(_028_),
    .Y(_029_));
 sky130_fd_sc_hd__a221oi_4 _181_ (.A1(_013_),
    .A2(_026_),
    .B1(_027_),
    .B2(_126_),
    .C1(_029_),
    .Y(_030_));
 sky130_fd_sc_hd__xor2_2 _182_ (.A(BI),
    .B(B[7]),
    .X(_031_));
 sky130_fd_sc_hd__nand2_1 _183_ (.A(\dpath.a_lt_b$in0_7_ ),
    .B(net220),
    .Y(_032_));
 sky130_fd_sc_hd__xnor2_2 _184_ (.A(A[7]),
    .B(_031_),
    .Y(_033_));
 sky130_fd_sc_hd__xor2_2 _185_ (.A(net179),
    .B(net212),
    .X(Y[7]));
 sky130_fd_sc_hd__nor2_4 _186_ (.A(_023_),
    .B(_033_),
    .Y(_034_));
 sky130_fd_sc_hd__o211ai_2 _187_ (.A1(A[7]),
    .A2(net220),
    .B1(net222),
    .C1(net465),
    .Y(_035_));
 sky130_fd_sc_hd__nand2_2 _188_ (.A(_035_),
    .B(_032_),
    .Y(_036_));
 sky130_fd_sc_hd__a21oi_4 _189_ (.A1(_019_),
    .A2(_034_),
    .B1(_036_),
    .Y(_037_));
 sky130_fd_sc_hd__nand2_1 _190_ (.A(_017_),
    .B(_034_),
    .Y(_038_));
 sky130_fd_sc_hd__o21ai_4 _191_ (.A1(_038_),
    .A2(_005_),
    .B1(_037_),
    .Y(_039_));
 sky130_fd_sc_hd__xor2_1 _192_ (.A(BI),
    .B(B[8]),
    .X(_040_));
 sky130_fd_sc_hd__nand2_1 _193_ (.A(A[8]),
    .B(_040_),
    .Y(_041_));
 sky130_fd_sc_hd__xnor2_1 _194_ (.A(A[8]),
    .B(net219),
    .Y(_042_));
 sky130_fd_sc_hd__xnor2_4 _195_ (.A(net210),
    .B(net441),
    .Y(Y[8]));
 sky130_fd_sc_hd__nor2_1 _196_ (.A(net212),
    .B(net211),
    .Y(_043_));
 sky130_fd_sc_hd__a211oi_1 _197_ (.A1(_022_),
    .A2(_028_),
    .B1(net212),
    .C1(net211),
    .Y(_044_));
 sky130_fd_sc_hd__o211ai_1 _198_ (.A1(\dpath.a_lt_b$in0_8_ ),
    .A2(net219),
    .B1(net220),
    .C1(\dpath.a_lt_b$in0_7_ ),
    .Y(_045_));
 sky130_fd_sc_hd__nand2_1 _199_ (.A(_041_),
    .B(_045_),
    .Y(_046_));
 sky130_fd_sc_hd__nor2_1 _200_ (.A(_044_),
    .B(_046_),
    .Y(_047_));
 sky130_fd_sc_hd__nor4_1 _201_ (.A(_011_),
    .B(_023_),
    .C(net212),
    .D(net211),
    .Y(_048_));
 sky130_fd_sc_hd__o31ai_2 _202_ (.A1(_013_),
    .A2(_015_),
    .A3(_014_),
    .B1(_048_),
    .Y(_049_));
 sky130_fd_sc_hd__nand2_2 _203_ (.A(_049_),
    .B(_047_),
    .Y(_050_));
 sky130_fd_sc_hd__xor2_2 _204_ (.A(B[9]),
    .B(BI),
    .X(_051_));
 sky130_fd_sc_hd__nand2_1 _205_ (.A(\dpath.a_lt_b$in0_9_ ),
    .B(net348),
    .Y(_052_));
 sky130_fd_sc_hd__xnor2_2 _206_ (.A(A[9]),
    .B(_051_),
    .Y(_053_));
 sky130_fd_sc_hd__xnor2_1 _207_ (.A(_050_),
    .B(net209),
    .Y(Y[9]));
 sky130_fd_sc_hd__nor2_4 _208_ (.A(_042_),
    .B(net209),
    .Y(_054_));
 sky130_fd_sc_hd__a211oi_1 _209_ (.A1(_032_),
    .A2(_035_),
    .B1(net211),
    .C1(net209),
    .Y(_055_));
 sky130_fd_sc_hd__o21ai_1 _210_ (.A1(_041_),
    .A2(_053_),
    .B1(_052_),
    .Y(_056_));
 sky130_fd_sc_hd__nor2_1 _211_ (.A(_055_),
    .B(net192),
    .Y(_057_));
 sky130_fd_sc_hd__nand2_1 _212_ (.A(net194),
    .B(_054_),
    .Y(_058_));
 sky130_fd_sc_hd__o21ai_1 _213_ (.A1(_020_),
    .A2(_058_),
    .B1(_057_),
    .Y(_059_));
 sky130_fd_sc_hd__xor2_4 _214_ (.A(B[10]),
    .B(BI),
    .X(_060_));
 sky130_fd_sc_hd__nand2_1 _215_ (.A(A[10]),
    .B(_060_),
    .Y(_061_));
 sky130_fd_sc_hd__xnor2_2 _216_ (.A(A[10]),
    .B(_060_),
    .Y(_062_));
 sky130_fd_sc_hd__xnor2_1 _217_ (.A(_059_),
    .B(net208),
    .Y(Y[10]));
 sky130_fd_sc_hd__nor2_1 _218_ (.A(net209),
    .B(net208),
    .Y(_063_));
 sky130_fd_sc_hd__a211oi_1 _219_ (.A1(_041_),
    .A2(_045_),
    .B1(net209),
    .C1(net208),
    .Y(_064_));
 sky130_fd_sc_hd__o21ai_0 _220_ (.A1(_052_),
    .A2(net208),
    .B1(_061_),
    .Y(_065_));
 sky130_fd_sc_hd__nor2_1 _221_ (.A(_064_),
    .B(_065_),
    .Y(_066_));
 sky130_fd_sc_hd__nand2_1 _222_ (.A(_043_),
    .B(_063_),
    .Y(_067_));
 sky130_fd_sc_hd__o21ai_4 _223_ (.A1(net177),
    .A2(net277),
    .B1(_066_),
    .Y(_068_));
 sky130_fd_sc_hd__xor2_2 _224_ (.A(BI),
    .B(B[11]),
    .X(_069_));
 sky130_fd_sc_hd__nand2_1 _225_ (.A(\dpath.a_lt_b$in0_11_ ),
    .B(_069_),
    .Y(_070_));
 sky130_fd_sc_hd__xnor2_2 _226_ (.A(A[11]),
    .B(_069_),
    .Y(_071_));
 sky130_fd_sc_hd__xnor2_2 _227_ (.A(net206),
    .B(_068_),
    .Y(Y[11]));
 sky130_fd_sc_hd__nor2_4 _228_ (.A(_071_),
    .B(_062_),
    .Y(_072_));
 sky130_fd_sc_hd__nand2_2 _229_ (.A(_054_),
    .B(net189),
    .Y(_073_));
 sky130_fd_sc_hd__nand4_4 _230_ (.A(net195),
    .B(net194),
    .C(net193),
    .D(net188),
    .Y(_074_));
 sky130_fd_sc_hd__o21ai_1 _231_ (.A1(_061_),
    .A2(_071_),
    .B1(_070_),
    .Y(_075_));
 sky130_fd_sc_hd__a21oi_2 _232_ (.A1(_056_),
    .A2(_072_),
    .B1(_075_),
    .Y(_076_));
 sky130_fd_sc_hd__o221ai_4 _233_ (.A1(net176),
    .A2(net446),
    .B1(_074_),
    .B2(net389),
    .C1(net175),
    .Y(_077_));
 sky130_fd_sc_hd__xor2_1 _234_ (.A(BI),
    .B(B[12]),
    .X(_078_));
 sky130_fd_sc_hd__nand2_1 _235_ (.A(\dpath.a_lt_b$in0_12_ ),
    .B(_078_),
    .Y(_079_));
 sky130_fd_sc_hd__xnor2_1 _236_ (.A(A[12]),
    .B(_078_),
    .Y(_080_));
 sky130_fd_sc_hd__xnor2_2 _237_ (.A(net204),
    .B(_077_),
    .Y(Y[12]));
 sky130_fd_sc_hd__o21ai_0 _238_ (.A1(_070_),
    .A2(_080_),
    .B1(net205),
    .Y(_081_));
 sky130_fd_sc_hd__nor2_1 _239_ (.A(net207),
    .B(_080_),
    .Y(_082_));
 sky130_fd_sc_hd__nand2_1 _240_ (.A(net191),
    .B(net186),
    .Y(_083_));
 sky130_fd_sc_hd__o211ai_1 _241_ (.A1(_044_),
    .A2(_046_),
    .B1(net191),
    .C1(net186),
    .Y(_084_));
 sky130_fd_sc_hd__a21oi_1 _242_ (.A1(_065_),
    .A2(_082_),
    .B1(_081_),
    .Y(_085_));
 sky130_fd_sc_hd__xnor2_1 _243_ (.A(BI),
    .B(B[0]),
    .Y(_087_));
 sky130_fd_sc_hd__o211ai_2 _244_ (.A1(_083_),
    .A2(_049_),
    .B1(_084_),
    .C1(_085_),
    .Y(_086_));
 sky130_fd_sc_hd__xor2_2 _245_ (.A(BI),
    .B(B[13]),
    .X(_088_));
 sky130_fd_sc_hd__nand2_1 _246_ (.A(A[13]),
    .B(_088_),
    .Y(_089_));
 sky130_fd_sc_hd__xnor2_1 _247_ (.A(A[13]),
    .B(_088_),
    .Y(_090_));
 sky130_fd_sc_hd__xnor2_1 _248_ (.A(_086_),
    .B(net203),
    .Y(Y[13]));
 sky130_fd_sc_hd__nor2_1 _249_ (.A(_080_),
    .B(_090_),
    .Y(_091_));
 sky130_fd_sc_hd__nand2_1 _250_ (.A(net190),
    .B(net185),
    .Y(_092_));
 sky130_fd_sc_hd__o21ai_0 _251_ (.A1(_079_),
    .A2(_090_),
    .B1(_089_),
    .Y(_093_));
 sky130_fd_sc_hd__o211ai_1 _252_ (.A1(_055_),
    .A2(net192),
    .B1(net188),
    .C1(net185),
    .Y(_094_));
 sky130_fd_sc_hd__a21oi_1 _253_ (.A1(net187),
    .A2(net185),
    .B1(net184),
    .Y(_095_));
 sky130_fd_sc_hd__o311ai_1 _254_ (.A1(_020_),
    .A2(_058_),
    .A3(_092_),
    .B1(_094_),
    .C1(_095_),
    .Y(_096_));
 sky130_fd_sc_hd__xor2_1 _255_ (.A(BI),
    .B(B[14]),
    .X(_097_));
 sky130_fd_sc_hd__nand2_1 _256_ (.A(A[14]),
    .B(_097_),
    .Y(_098_));
 sky130_fd_sc_hd__xnor2_1 _257_ (.A(A[14]),
    .B(_097_),
    .Y(_099_));
 sky130_fd_sc_hd__xnor2_1 _258_ (.A(_096_),
    .B(net201),
    .Y(Y[14]));
 sky130_fd_sc_hd__nor2_1 _259_ (.A(_090_),
    .B(net202),
    .Y(_100_));
 sky130_fd_sc_hd__nand2_1 _260_ (.A(_082_),
    .B(_100_),
    .Y(_101_));
 sky130_fd_sc_hd__o21ai_0 _261_ (.A1(_089_),
    .A2(net202),
    .B1(_098_),
    .Y(_102_));
 sky130_fd_sc_hd__o211ai_1 _262_ (.A1(_064_),
    .A2(_065_),
    .B1(_082_),
    .C1(_100_),
    .Y(_103_));
 sky130_fd_sc_hd__a21oi_1 _263_ (.A1(_081_),
    .A2(_100_),
    .B1(_102_),
    .Y(_104_));
 sky130_fd_sc_hd__o311ai_4 _264_ (.A1(_101_),
    .A2(_067_),
    .A3(_030_),
    .B1(_103_),
    .C1(_104_),
    .Y(_105_));
 sky130_fd_sc_hd__xor2_2 _265_ (.A(BI),
    .B(B[15]),
    .X(_106_));
 sky130_fd_sc_hd__nand2_1 _266_ (.A(\dpath.a_lt_b$in0_15_ ),
    .B(_106_),
    .Y(_107_));
 sky130_fd_sc_hd__xnor2_2 _267_ (.A(A[15]),
    .B(_106_),
    .Y(_108_));
 sky130_fd_sc_hd__xnor2_2 _268_ (.A(_108_),
    .B(_105_),
    .Y(Y[15]));
 sky130_fd_sc_hd__nor2_1 _269_ (.A(_099_),
    .B(_108_),
    .Y(_109_));
 sky130_fd_sc_hd__nand2_1 _270_ (.A(_091_),
    .B(_109_),
    .Y(_110_));
 sky130_fd_sc_hd__a21o_4 clone268 (.A1(net356),
    .A2(_111_),
    .B1(_114_),
    .X(net_o_272));
 sky130_fd_sc_hd__buf_4 place175 (.A(_076_),
    .X(net175));
 sky130_fd_sc_hd__buf_6 place176 (.A(_073_),
    .X(net176));
 sky130_fd_sc_hd__buf_4 place177 (.A(_067_),
    .X(net177));
 sky130_fd_sc_hd__buf_4 place179 (.A(_030_),
    .X(net179));
 sky130_fd_sc_hd__buf_4 place180 (.A(_020_),
    .X(net180));
 sky130_fd_sc_hd__buf_4 place184 (.A(_093_),
    .X(net184));
 sky130_fd_sc_hd__buf_4 place185 (.A(_091_),
    .X(net185));
 sky130_fd_sc_hd__buf_4 place186 (.A(_082_),
    .X(net186));
 sky130_fd_sc_hd__buf_4 place187 (.A(_075_),
    .X(net187));
 sky130_fd_sc_hd__buf_6 place188 (.A(net189),
    .X(net188));
 sky130_fd_sc_hd__buf_6 place189 (.A(_072_),
    .X(net189));
 sky130_fd_sc_hd__buf_4 place190 (.A(_072_),
    .X(net190));
 sky130_fd_sc_hd__buf_4 place191 (.A(_063_),
    .X(net191));
 sky130_fd_sc_hd__buf_4 place192 (.A(_056_),
    .X(net192));
 sky130_fd_sc_hd__buf_4 place193 (.A(_054_),
    .X(net193));
 sky130_fd_sc_hd__buf_4 place194 (.A(_034_),
    .X(net194));
 sky130_fd_sc_hd__buf_4 place195 (.A(_017_),
    .X(net195));
 sky130_fd_sc_hd__buf_4 place196 (.A(_015_),
    .X(net196));
 sky130_fd_sc_hd__buf_4 place197 (.A(_014_),
    .X(net197));
 sky130_fd_sc_hd__buf_4 place198 (.A(net267),
    .X(net198));
 sky130_fd_sc_hd__buf_4 place201 (.A(net202),
    .X(net201));
 sky130_fd_sc_hd__buf_4 place202 (.A(_099_),
    .X(net202));
 sky130_fd_sc_hd__buf_4 place203 (.A(_090_),
    .X(net203));
 sky130_fd_sc_hd__buf_4 place204 (.A(_080_),
    .X(net204));
 sky130_fd_sc_hd__buf_4 place205 (.A(_079_),
    .X(net205));
 sky130_fd_sc_hd__buf_4 place206 (.A(_071_),
    .X(net206));
 sky130_fd_sc_hd__buf_4 place207 (.A(_071_),
    .X(net207));
 sky130_fd_sc_hd__buf_4 place208 (.A(_062_),
    .X(net208));
 sky130_fd_sc_hd__buf_4 place209 (.A(_053_),
    .X(net209));
 sky130_fd_sc_hd__buf_4 place210 (.A(net211),
    .X(net210));
 sky130_fd_sc_hd__buf_4 place211 (.A(_042_),
    .X(net211));
 sky130_fd_sc_hd__buf_4 place212 (.A(_033_),
    .X(net212));
 sky130_fd_sc_hd__buf_4 place213 (.A(_023_),
    .X(net213));
 sky130_fd_sc_hd__buf_12 place214 (.A(_012_),
    .X(net214));
 sky130_fd_sc_hd__buf_6 place215 (.A(_011_),
    .X(net215));
 sky130_fd_sc_hd__buf_4 place216 (.A(_122_),
    .X(net216));
 sky130_fd_sc_hd__buf_4 place217 (.A(_115_),
    .X(net217));
 sky130_fd_sc_hd__buf_6 place218 (.A(_087_),
    .X(net218));
 sky130_fd_sc_hd__buf_4 place219 (.A(_040_),
    .X(net219));
 sky130_fd_sc_hd__buf_4 place220 (.A(_031_),
    .X(net220));
 sky130_fd_sc_hd__buf_6 place221 (.A(_024_),
    .X(net221));
 sky130_fd_sc_hd__buf_6 place222 (.A(_021_),
    .X(net222));
 sky130_fd_sc_hd__buf_4 place224 (.A(_002_),
    .X(net224));
 sky130_fd_sc_hd__buf_4 place225 (.A(_123_),
    .X(net225));
 sky130_fd_sc_hd__buf_6 place226 (.A(_119_),
    .X(net226));
 sky130_fd_sc_hd__buf_4 rebuffer266 (.A(net383),
    .X(net267));
 sky130_fd_sc_hd__buf_6 rebuffer272 (.A(_030_),
    .X(net277));
 sky130_fd_sc_hd__buf_6 rebuffer276 (.A(_120_),
    .X(net281));
 sky130_fd_sc_hd__buf_6 rebuffer277 (.A(_123_),
    .X(net282));
 sky130_fd_sc_hd__buf_4 rebuffer343 (.A(_051_),
    .X(net348));
 sky130_fd_sc_hd__buf_12 rebuffer351 (.A(_039_),
    .X(net356));
 sky130_fd_sc_hd__buf_4 rebuffer378 (.A(_126_),
    .X(net383));
 sky130_fd_sc_hd__buf_6 rebuffer384 (.A(_005_),
    .X(net389));
 sky130_fd_sc_hd__buf_6 rebuffer385 (.A(_009_),
    .X(net390));
 sky130_fd_sc_hd__buf_8 rebuffer436 (.A(net356),
    .X(net441));
 sky130_fd_sc_hd__buf_6 rebuffer441 (.A(_037_),
    .X(net446));
 sky130_fd_sc_hd__buf_4 rebuffer442 (.A(_011_),
    .X(net447));
 sky130_fd_sc_hd__buf_8 rebuffer452 (.A(net281),
    .X(net457));
 sky130_fd_sc_hd__buf_4 rebuffer460 (.A(\dpath.a_lt_b$in0_6_ ),
    .X(net465));
endmodule

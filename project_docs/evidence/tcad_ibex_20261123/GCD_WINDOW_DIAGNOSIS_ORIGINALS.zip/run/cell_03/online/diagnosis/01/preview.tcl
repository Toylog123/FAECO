read_liberty "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib"
read_db "/home/toylog/faeco_tcad_sky_holdout_20261123/gcd/results/sky130hd/gcd/base/6_final.odb"
read_sdc "/home/toylog/faeco_tcad_sky_holdout_20261123/gcd/results/sky130hd/gcd/base/6_final.sdc"
if {[llength [all_clocks]] == 0} { error "No clocks in saved SDC" }
source "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/setRC.tcl"
set env(MIN_ROUTING_LAYER) met1
set env(MIN_CLK_ROUTING_LAYER) met3
set env(MAX_ROUTING_LAYER) met5
set env(ROUTING_LAYER_ADJUSTMENT) 0.25
source "/home/toylog/faeco_eda/orfs/flow/platforms/sky130hd/fastroute.tcl"

set inst [[ord::get_db_block] findInst "_092_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__mux2_4"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "sky130_fd_sc_hd__mux2_1"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "_092_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__mux2_1"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "_093_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__mux2_4"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "sky130_fd_sc_hd__mux2_1"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "_093_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__mux2_1"} {
    error "target instance/master mismatch"
}

set inst [[ord::get_db_block] findInst "_094_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__mux2_4"} {
    error "source instance/master mismatch"
}
set target [[ord::get_db] findMaster "sky130_fd_sc_hd__mux2_1"]
if {$target eq "NULL" || ![$inst swapMaster $target]} {
    error "could not swap the OpenDB master"
}
set inst [[ord::get_db_block] findInst "_094_"]
if {$inst eq "NULL" || [[$inst getMaster] getName] ne "sky130_fd_sc_hd__mux2_1"} {
    error "target instance/master mismatch"
}

check_placement -verbose

set nets [dict create]
foreach name [list "_092_" "_093_" "_094_"] {
    set inst [[ord::get_db_block] findInst $name]
    foreach pin [$inst getITerms] {
        set net [$pin getNet]
        if {$net ne "NULL" && [$net getSigType] ni {POWER GROUND}} {
            dict set nets [$net getName] $net
        }
    }
}

set cleared 0
dict for {name net} $nets {
    if {[$net getSigType] in {POWER GROUND}} { continue }
    puts "IBEX_TOUCHED_NET $name"
    set wire [$net getWire]
    if {$wire ne "NULL"} { odb::dbWire_destroy $wire; incr cleared }
}
puts "IBEX_CLEARED_SIGNAL_WIRES $cleared"
drt::check_drc -output_file "/home/toylog/faeco_tcad_sky_holdout_20261123/gcd_window_diagnosis_20261127_v1/cell_03/online/diagnosis/01/full_drc.rpt"
puts FAECO_PRE_DRT_DRC_COMPLETE
exit

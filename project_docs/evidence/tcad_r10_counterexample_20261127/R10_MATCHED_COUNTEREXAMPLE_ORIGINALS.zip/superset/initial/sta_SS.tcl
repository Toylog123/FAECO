read_liberty "/home/toylog/rseco_timing/vendor/OpenROAD-b511b6a/test/sky130hd/sky130_fd_sc_hd__ss_n40C_1v40.lib"
read_verilog "/home/toylog/faeco_tcad_lr_4designs_20261126_v1/sky130hd_aes/physical/initial/routed.v"
link_design aes_cipher_top
read_sdc "/home/toylog/faeco_tcad_sky_holdout_20261123/aes/ss_hold_targeted_v2b/6_final.sdc"
if {[llength [all_clocks]] == 0} { error "No clocks in saved SDC" }
read_spef "/home/toylog/faeco_tcad_lr_4designs_20261126_v1/sky130hd_aes/physical/initial/routed.spef"
puts "IBEX_SETUP_PS [expr {1e12 * [sta::worst_slack_cmd max]}]"
puts "IBEX_HOLD_PS [expr {1e12 * [sta::worst_slack_cmd min]}]"
puts "IBEX_TNS_PS [expr {1e12 * [sta::total_negative_slack_cmd max]}]"
puts "IBEX_HOLD_TNS_PS [expr {1e12 * [sta::total_negative_slack_cmd min]}]"
puts IBEX_MAX_SLEW_START
report_check_types -max_slew -violators -digits 9
puts IBEX_MAX_SLEW_END
puts IBEX_MAX_CAPACITANCE_START
report_check_types -max_capacitance -violators -digits 9
puts IBEX_MAX_CAPACITANCE_END
foreach port [all_inputs -no_clocks] { puts "IBEX_INPUT [get_name $port]" }
foreach port [all_outputs] { puts "IBEX_OUTPUT [get_name $port]" }
check_setup -verbose
report_parasitic_annotation
report_checks -path_delay max -group_path_count 1
report_checks -path_delay min -group_path_count 1

puts IBEX_SETUP_NEG_BEGIN
set paths [find_timing_paths -path_delay max -slack_max 0 -group_path_count 100000 -endpoint_path_count 1]
if {[llength $paths] >= 100000} { error "setup endpoint inventory hit the path report cap" }
foreach path $paths {
    if {[get_property $path slack] < 0} {
        puts "IBEX_SETUP_NEG [get_full_name [get_property $path endpoint]]"
    }
}
puts IBEX_SETUP_NEG_END

puts IBEX_STA_COMPLETE
exit
